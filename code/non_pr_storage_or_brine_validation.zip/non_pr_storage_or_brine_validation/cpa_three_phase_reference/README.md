# SRK-CPA three-phase reference-model check

This companion result uses Thermopack SRK-CPA for H2O/CO2/n-decane. Three finite-support branches represent the vapour, aqueous-liquid, and hydrocarbon-liquid states with a shared gauge. The retained independent calculation follows a composition path with the phase-count sequence 1, 2, 3, 2, 1 and compares it with an independently minimized CPA Gibbs reference.

It demonstrates transfer away from PR and into a reference model with association and three competing phases. It is not a saline system and contains no ions, aqueous reactions, or salt precipitation. The gas--brine folder provides the separate Pitzer/Henry saline example, with its own documented limitations.

The source programs are retained exactly as used in the local validation project. Their original relative imports expect that project's package layout; the summary and appearance path are directly inspectable here, while a clean rerun should be made from the packaged gas--brine driver or the original validation environment.
