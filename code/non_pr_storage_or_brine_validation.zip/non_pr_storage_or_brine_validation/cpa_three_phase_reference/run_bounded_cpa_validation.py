"""P3-13: three bounded CPA branches, shared gauge, generic-Np KKT."""
from pathlib import Path
import importlib.util,json,sys,time,copy,os
import numpy as np
import pandas as pd
import torch
import scipy.optimize
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import benchmark_common
def module(name):
    spec=importlib.util.spec_from_file_location('p3_'+name,ROOT/'scripts'/name);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=module('18_cpa_polar_vlle_mm.py');scale=module('38_p3_composition_scaling.py')
from acgpv2.bounded_study import geometry,BoundedNet,tensors,loss,restore
from acgpv2.bounded_curvature import BoundedCurvatureMassieuACGP
from acgpv2.massieu import farthest_point_indices
from acgpv2.p3_multiphase import MultiphaseKKT
OUT=ROOT/'results/p3/vlle';OUT.mkdir(parents=True,exist_ok=True)


def teacher_data():
    teacher=base.CPATeacher();frame=pd.read_csv(ROOT/'results/cpa_vlle_teacher_roots.csv');roots=[]
    for rid,rows in frame.groupby('root_id'):
        rows=rows.set_index('phase').loc[base.base.LABELS];x=rows[[f'x_{c}' for c in base.base.COMPONENTS]].to_numpy()
        T=float(rows.T_K.iloc[0]);P=float(rows.P_Pa.iloc[0]);states=[teacher.homogeneous(T,P,v,k) for k,v in enumerate(x)]
        eta=np.mean([r['eta'] for r in states],axis=0)
        roots.append(dict(id=int(rid),split=rows.split.iloc[0],T=T,P=P,x=x,states=states,eta=eta))
    for split in ['train','monitor','test']:
        for k,label in enumerate(base.base.LABELS):
            file=OUT/f'{split}_{label}.npz'
            if file.exists():continue
            rng=np.random.default_rng(430610+100*k+len(split));data=[];reject=[]
            for root in roots:
                if root['split']!=split:continue
                for j in range(48 if split=='train' else 24):
                    T=root['T'] if j==0 else root['T']+rng.uniform(-2,2)
                    P=root['P'] if j==0 else root['P']*np.exp(rng.uniform(-.045,.045))
                    x=root['x'][k] if j==0 else base.base.softmax2(base.base.logits(root['x'][k])+rng.normal(0,.15,2))
                    try:
                        s=teacher.homogeneous(T,P,x,k)
                        # Analytic TV derivatives at the teacher's phased TP
                        # density. Keep the original stable branch and cp.
                        r=scale.state_tv(teacher.eos,T,s['rho'],x)
                        ph=teacher.phases[k];r['cp']=float(teacher.eos.enthalpy(T,P,x,ph,dhdt=True)[1])
                        ss=np.array([1e-4,1,1,1]);ev=np.linalg.eigvalsh(r['H']*ss[:,None]*ss[None,:])
                        if ev.min()<=0 or r['cp']<=0:raise ValueError('unstable CPA support')
                        data.append(dict(**r,parent=root['id']))
                    except Exception as exc:reject.append(dict(parent=root['id'],child=j,error=str(exc)))
            np.savez_compressed(file,**{k:np.asarray([r[k] for r in data]) for k in data[0]});pd.DataFrame(reject).to_csv(OUT/f'{split}_{label}_rejections.csv',index=False)
    return roots


def train(roots,M=1024):
    files=[OUT/f'{label}_M{M}.npz' for label in base.base.LABELS]
    if all(p.exists() for p in files):return [restore(BoundedCurvatureMassieuACGP.load(p)) for p in files]
    tr=[dict(np.load(OUT/f'train_{p}.npz')) for p in base.base.LABELS];mo=[dict(np.load(OUT/f'monitor_{p}.npz')) for p in base.base.LABELS]
    gauge=torch.nn.Parameter(torch.zeros((),device='cuda',dtype=torch.float64));nets=[]
    for d in tr:
        g=geometry(d);nets.append(BoundedNet(d,g,farthest_point_indices(g['X'],min(M,len(d['T']))),gauge=gauge))
    ts=[tensors(d,'cuda') for d in tr];ms=[tensors(d,'cuda') for d in mo]
    tie=[r for r in roots if r['split']=='train'];tm=[r for r in roots if r['split']=='monitor']
    E=torch.tensor(np.array([r['eta'] for r in tie]),device='cuda');P=torch.tensor([r['P']/(base.base.R*r['T']) for r in tie],device='cuda')
    EM=torch.tensor(np.array([r['eta'] for r in tm]),device='cuda');PM=torch.tensor([r['P']/(base.base.R*r['T']) for r in tm],device='cuda')
    params=list({id(p):p for n in nets for p in n.parameters()}.values());opt=torch.optim.Adam(params,lr=.012);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,1600,eta_min=.001)
    rng=np.random.default_rng(43061);best=None;history=[]
    def interface(e,p):
        vals=torch.stack([n(e,order=1)[0] for n in nets]);return 3000*((vals-p)/p).square().mean()+30000*((vals-vals.mean(0))/p).square().mean()
    for step in range(1,1601):
        v=sum(loss(n,t,torch.tensor(rng.choice(len(t['T']),min(96,len(t['T'])),replace=False),device='cuda')) for n,t in zip(nets,ts))+interface(E,P)
        opt.zero_grad();v.backward();torch.nn.utils.clip_grad_norm_(params,30);opt.step();sched.step()
        if step%100==0:
            with torch.no_grad():score=float(sum(loss(n,t,torch.arange(min(256,len(t['T'])),device='cuda')) for n,t in zip(nets,ms))+interface(EM,PM))
            history.append(dict(step=step,training_loss=float(v.detach()),monitor_loss=score))
            if np.isfinite(score) and (best is None or score<best[0]):best=(score,[copy.deepcopy(n.state_dict()) for n in nets])
            if step%400==0:print('CPA bounded',step,score,flush=True)
    for n,state,d,file in zip(nets,best[1],tr,files):n.load_state_dict(state);n.export(d).save(file)
    pd.DataFrame(history).to_csv(OUT/'training.csv',index=False);return nets


def main():
    roots=teacher_data();nets=train(roots)
    from acgpv2.p3_cuda_graph import FrozenBounded
    frozen=[FrozenBounded(n) for n in nets]
    if os.environ.get('ACGP_CUDA_KERNEL')=='fused':
        from acgpv2.p3_fused_cuda import FusedBounded
        frozen=[FusedBounded(n) for n in frozen]
    solver=MultiphaseKKT(frozen);tr=[r for r in roots if r['split']=='train'];rows=[]
    rng=np.random.default_rng(943061)
    for r in roots:
        if r['split']!='test':continue
        j=np.argmin([((t['T']-r['T'])/60)**2+np.log(t['P']/r['P'])**2 for t in tr]);anchor=tr[j];guess=anchor['eta'].copy()
        # CPA formation-energy references make raw reduced chemical potentials
        # strongly temperature dependent. Transport a TRAINING anchor using
        # Gibbs-Duhem, not an uncorrected nearest-temperature chemical mu.
        hh=np.array([s['h'] for s in anchor['states']]);rr=np.array([s['rho'] for s in anchor['states']])
        tangent=-np.linalg.solve(anchor['x'],hh)
        delta0=-1/(base.base.R*r['T'])+1/(base.base.R*anchor['T'])
        rhs=(r['P']-anchor['P'])/(base.base.R*anchor['T']*rr);rhs[0]=np.log(r['P']/anchor['P'])
        guess[1:]+=tangent*delta0+np.linalg.solve(anchor['x'],rhs);guess[0]=-1/(base.base.R*r['T'])
        betas=rng.dirichlet(np.ones(3)*1.5,64);feeds=betas@r['x']
        predictions=solver.solve_many(np.full(64,r['T']),np.full(64,r['P']),feeds,guess)
        for case,(beta,out) in enumerate(zip(betas,predictions)):
            rho=np.array([s['rho'] for s in r['states']]);hh=np.array([s['h'] for s in r['states']]);rt=1/(beta/rho).sum();ht=beta@hh
            rows.append(dict(root=r['id'],T=r['T'],P=r['P'],case=case,success=out['success'],KKT_residual=out['residual'],condition=out['condition'],composition_L1=float(np.abs(out['x']-r['x']).sum(1).mean()),beta_max_abs=float(max(abs(out['beta']-beta))),rho_rel=float(abs(out['rho']-rt)/rt),h_rel=float(abs(out['h']-ht)/max(abs(ht),100)),**{f'S{k}':out['S'][k] for k in range(3)}))
        pd.DataFrame(rows).to_csv(OUT/'independent_three_phase_KKT.csv',index=False)
        print('CPA independent root',r['id'],'successes',sum(p['success'] for p in predictions),flush=True)
    # A changing-composition trajectory uses the SAME equations and branches.
    # Outside the three-phase tie triangle, its solutions are not certified by
    # the triple teacher alone; a full CPA stability reference is required.
    from acgpv2.p3_cpa_flash import gibbs_flash
    teacher=base.CPATeacher();r=next(r for r in roots if r['split']=='test');trajectory=[];path_outputs=[];last=None;teacher_previous=None
    gas=r['x'][0].copy();gas[[0,2]]*=.5;gas[1]=1-gas[0]-gas[2]
    edge=.5*(r['x'][0]+r['x'][2]);edge[0]*=.8;edge[1]=1-edge[0]-edge[2]
    directions=[gas,edge,np.ones(3)@r['x']/3,edge,gas]
    for stage,target in enumerate(directions):
        previous=directions[max(stage-1,0)]
        for fraction in np.linspace(0,1,25):
            z=(1-fraction)*previous+fraction*target
            if last is None:
                a=min(tr,key=lambda t:((t['T']-r['T'])/60)**2+np.log(t['P']/r['P'])**2);eg=a['eta'].copy();eg[1:]-=np.linalg.solve(a['x'],[s['h'] for s in a['states']])*(-1/(base.base.R*r['T'])+1/(base.base.R*a['T']));eg[0]=-1/(base.base.R*r['T']);eg,_=solver.coexistence_seed(r['T'],r['P'],eg)
                eg[1:]+=np.log(z/r['x'][0]);ss=np.array([1.,0.,0.])
            else:eg=last['eta'];ss=last['S']
            out=solver.solve_one(r['T'],r['P'],z,eg,ss);last=out
            path_outputs.append((z.copy(),out))
            reference=gibbs_flash(teacher,r['T'],r['P'],z,r,teacher_previous);teacher_previous=reference
            trajectory.append(dict(stage=stage,fraction=fraction,success=out['success'],residual=out['residual'],phases=int((out['beta']>1e-5).sum()),CPA_success=reference['success'],CPA_phases=reference['phases'],CPA_mass_residual=reference['mass_residual'],CPA_active_mu_residual=reference['active_mu_residual'],CPA_objective=reference['objective'],CPA_evaluations=reference['evaluations'],rho_rel=float(abs(out['rho']-reference['rho'])/reference['rho']),h_rel=float(abs(out['h']-reference['h'])/max(abs(reference['h']),100)),**{f'S{k}':out['S'][k] for k in range(3)},**{f'beta{k}':out['beta'][k] for k in range(3)},**{f'CPA_beta{k}':reference['beta'][k] for k in range(3)}))
            (OUT/'gibbs_last_multistart.json').write_text(json.dumps(reference['multistart_attempts'],indent=2))
        pd.DataFrame(trajectory).to_csv(OUT/'appearance_path.csv',index=False);print('CPA trajectory stage',stage,trajectory[-1],flush=True)
    pd.DataFrame(trajectory).to_csv(OUT/'appearance_path_before_bidirectional_continuation.csv',index=False)
    for index,(z,out) in enumerate(path_outputs):
        if out['success']:continue
        candidates=sorted([j for j,(_,v) in enumerate(path_outputs) if v['success']],key=lambda j:abs(j-index))
        for j in candidates[:4]:
            anchor=path_outputs[j][1]
            corrected=solver.solve_one(r['T'],r['P'],z,anchor['eta'],anchor['S'])
            if corrected['success']:
                path_outputs[index]=(z,corrected);row=trajectory[index]
                row.update(success=True,residual=corrected['residual'],phases=int((corrected['beta']>1e-5).sum()),recovered_by_bidirectional_continuation=True)
                for k in range(3):row[f'S{k}']=corrected['S'][k];row[f'beta{k}']=corrected['beta'][k]
                ref=gibbs_flash(teacher,r['T'],r['P'],z,r)
                row['rho_rel']=float(abs(corrected['rho']-ref['rho'])/ref['rho']);row['h_rel']=float(abs(corrected['h']-ref['h'])/max(abs(ref['h']),100))
                break
    pd.DataFrame(trajectory).to_csv(OUT/'appearance_path.csv',index=False)
    frame=pd.DataFrame(rows);counts=[int(pd.DataFrame(trajectory).query('stage==@s').phases.iloc[-1]) for s in range(5)]
    tf=pd.DataFrame(trajectory);teacher_counts=[int(tf.query('stage==@s').CPA_phases.iloc[-1]) for s in range(5)]
    path_ok=bool(counts==[1,2,3,2,1] and teacher_counts==counts and tf.success.all() and tf.CPA_success.all())
    summary=dict(teacher='Thermopack SRK-CPA H2O/CO2/NC10',three_bounded_branches=True,independent_phase_offsets=False,shared_gauges=[float(50*n.raw_gauge.detach()) for n in nets],test_states=len(rows),KKT_success=float(frame.success.mean()),composition_L1_mean=float(frame.composition_L1.mean()),beta_max_abs_mean=float(frame.beta_max_abs.mean()),rho_mean_rel=float(frame.rho_rel.mean()),h_mean_rel=float(frame.h_rel.mean()),path_phase_counts=counts,CPA_path_phase_counts=teacher_counts,path_states=len(tf),MM_path_solver_success=float(tf.success.mean()),CPA_path_solver_success=float(tf.CPA_success.mean()),path_required_1_2_3_2_1_met=counts==[1,2,3,2,1] and teacher_counts==counts and tf.success.all() and tf.CPA_success.all(),limitation='Outside-triangle CPA reference uses independent multistart constrained Gibbs minimization, not teacher lever-rule labels. SLSQP local minima and near-zero phase fractions require explicit convergence checks.')
    summary['path_required_1_2_3_2_1_met']=path_ok
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':main()
