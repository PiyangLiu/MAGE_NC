"""Three shared-gauge MM branches trained against a genuine polar CPA VLLE teacher."""
from pathlib import Path
import importlib.util,json,sys,time
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'vendor'))
from benchmark_common import RESULTS
from thermopack.cpa import cpa

spec=importlib.util.spec_from_file_location('pcsaft_reference',ROOT/'scripts'/'14_pcsaft_polar_vlle_mm.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)


class CPATeacher(base.PCSAFTTeacher):
    def __init__(self):
        self.eos=cpa(','.join(base.COMPONENTS),eos='SRK',mixing='vdW',alpha='Classic',parameter_reference='Default')
        self.phases=[self.eos.VAPPH,self.eos.LIQPH,self.eos.LIQPH]


def collect_cpa_triples(teacher):
    roots=[];warm=[]
    for T in base.T_GRID:
        for P in base.P_GRID:
            root=teacher.triple(T,P,warm[-2:])
            if root is not None:roots.append(root);warm.append(root['w'])
    if len(roots)<18:raise RuntimeError(f'Only {len(roots)} genuine CPA triple states were found')
    order=np.random.default_rng(base.SEED+200).permutation(len(roots));ntest=max(6,len(roots)//5);nmonitor=max(5,len(roots)//6)
    labels=np.full(len(roots),'train',object);labels[order[:ntest]]='test';labels[order[ntest:ntest+nmonitor]]='monitor'
    rows=[]
    for i,r in enumerate(roots):
        r['split']=labels[i];r['root_id']=i
        for k,s in enumerate(r['states']):
            rows.append({'root_id':i,'split':r['split'],'T_K':r['T'],'P_Pa':r['P'],'phase':base.LABELS[k],
                         'mu_residual_reduced':r['residual'],'min_phase_separation':r['separation'],'rho_molar':s['rho'],
                         'h_molar':s['h'],**{f'x_{base.COMPONENTS[j]}':s['x'][j] for j in range(3)},
                         **{f'mu_{base.COMPONENTS[j]}':s['mu'][j] for j in range(3)}})
    pd.DataFrame(rows).to_csv(RESULTS/'cpa_vlle_teacher_roots.csv',index=False)
    return roots


def main():
    start=time.perf_counter();teacher=CPATeacher();roots=collect_cpa_triples(teacher);rng=np.random.default_rng(base.SEED+201)
    train=base.local_data(teacher,roots,'train',rng,base.PERTURB_PER_ROOT)
    monitor=base.local_data(teacher,roots,'monitor',rng,max(18,base.PERTURB_PER_ROOT//2))
    test=base.local_data(teacher,roots,'test',rng,max(18,base.PERTURB_PER_ROOT//2))
    maxM=min(min(len(d['eta']) for d in train),max(base.M_VALUES));mvals=[m for m in base.M_VALUES if m<=maxM]
    if maxM not in mvals:mvals.append(maxM)
    orders=[base.farthest_point_indices(d['eta'],maxM) for d in train]
    trials=[];stored={}
    for M in mvals:
        for tau in base.TAUS:
            models,g=base.build_models(train,monitor,orders,M,tau);errs=base.evaluate_branches(models,monitor)
            score=float(np.mean([e['pressure_mean_rel']+e['density_mean_rel']+e['composition_mean_abs']+e['enthalpy_mean_rel'] for e in errs]))
            trials.append({'M':M,'tau':tau,'shared_gauge':g,'score':score,
                           **{f'{base.LABELS[k]}_{key}':val for k,e in enumerate(errs) for key,val in e.items()}})
            stored[(M,tau)]=(models,g)
    trial=pd.DataFrame(trials);trial.to_csv(RESULTS/'cpa_vlle_model_selection.csv',index=False)
    best=trial.loc[trial.score.idxmin()];M=int(best.M);tau=float(best.tau);models,shared=stored[(M,tau)]
    for label,m in zip(base.LABELS,models):m.save(RESULTS/f'cpa_vlle_{label}_mm.npz')

    homogeneous=base.evaluate_branches(models,test);predrows=[];feedrows=[];classrows=[]
    for r in roots:
        if r['split']!='test':continue
        mm=base.solve_mm_triple(models,r);Xt=r['x'];rho_t=np.asarray([s['rho'] for s in r['states']]);h_t=np.asarray([s['h'] for s in r['states']])
        for k in range(3):
            predrows.append({'root_id':r['root_id'],'T_K':r['T'],'P_Pa':r['P'],'phase':base.LABELS[k],
                             'solver_success':mm['success'],'pressure_residual_rel':mm['residual'],'nfev':mm['nfev'],
                             'minimum_teacher_phase_separation':r['separation'],
                             'composition_L1':float(np.abs(mm['X'][k]-Xt[k]).sum()),
                             'density_rel':float(abs(mm['rho'][k]-rho_t[k])/rho_t[k]),
                             'enthalpy_rel':float(abs(mm['h'][k]-h_t[k])/max(abs(h_t[k]),100.)),
                             **{f'x_teacher_{c}':Xt[k,j] for j,c in enumerate(base.COMPONENTS)},
                             **{f'x_mm_{c}':mm['X'][k,j] for j,c in enumerate(base.COMPONENTS)}})
        for case in range(40):
            bt=rng.dirichlet(np.full(3,1.5));z=bt@Xt;bh,mass=base.fractions(z,mm['X'])
            feedrows.append({'root_id':r['root_id'],'case':case,'phase_fraction_max_abs':float(np.max(abs(bh-bt))),
                             'mass_residual_inf':mass,**{f'beta_true_{k}':bt[k] for k in range(3)},
                             **{f'beta_mm_{k}':bh[k] for k in range(3)},**{f'z_{c}':z[j] for j,c in enumerate(base.COMPONENTS)}})
        for case in range(300):
            z=rng.dirichlet(np.ones(3));bt=np.linalg.solve(Xt.T,z);bp=np.linalg.solve(mm['X'].T,z)
            yt=bool(np.min(bt)>=-1e-9 and np.max(bt)<=1+1e-9);yp=bool(np.min(bp)>=-1e-9 and np.max(bp)<=1+1e-9)
            classrows.append({'root_id':r['root_id'],'true_three_phase':yt,'mm_three_phase':yp,'correct':yt==yp})
    pred=pd.DataFrame(predrows);feeds=pd.DataFrame(feedrows);clas=pd.DataFrame(classrows)
    pred.to_csv(RESULTS/'cpa_vlle_mm_phase_predictions.csv',index=False)
    feeds.to_csv(RESULTS/'cpa_vlle_mm_feed_predictions.csv',index=False)
    clas.to_csv(RESULTS/'cpa_vlle_mm_region_classification.csv',index=False)
    interactions={}
    for i in range(3):
        for j in range(i):interactions[f'{base.COMPONENTS[j]}-{base.COMPONENTS[i]}']=np.asarray(teacher.eos.get_kij(j+1,i+1),float).tolist()
    minsep=float(min(r['separation'] for r in roots))
    out={'status':'completed','teacher':'Thermopack 2.2.3 SRK-CPA, default documented parameters','system':base.COMPONENTS,
         'binary_interaction_parameters':interactions,'temperature_range_K':[float(base.T_GRID.min()),float(base.T_GRID.max())],
         'pressure_range_MPa':[float(base.P_GRID.min()/1e6),float(base.P_GRID.max()/1e6)],
         'genuine_three_phase_roots':len(roots),'minimum_phase_composition_separation':minsep,
         'duplicate_or_trivial_roots_accepted':0,'split_counts':pd.Series([r['split'] for r in roots]).value_counts().to_dict(),
         'selected_supports_per_branch':M,'selected_tau':tau,'single_shared_gauge':shared,
         'all_branch_gauges_identical':bool(max(m.gauge_offset for m in models)-min(m.gauge_offset for m in models)<1e-14),
         'positive_weights':True,'homogeneous_independent_test':{base.LABELS[k]:e for k,e in enumerate(homogeneous)},
         'triple_solver_success_fraction':float(pred.groupby('root_id').solver_success.first().mean()),
         'phase_composition_L1_mean':float(pred.composition_L1.mean()),'phase_composition_L1_max':float(pred.composition_L1.max()),
         'phase_density_mean_rel':float(pred.density_rel.mean()),'phase_enthalpy_mean_rel':float(pred.enthalpy_rel.mean()),
         'phase_fraction_MAE':float(np.mean(np.abs(feeds[[f'beta_mm_{k}' for k in range(3)]].to_numpy()-feeds[[f'beta_true_{k}' for k in range(3)]].to_numpy()))),
         'phase_fraction_max_abs':float(feeds.phase_fraction_max_abs.max()),
         'three_phase_region_classification_accuracy':float(clas.correct.mean()),
         'teacher_max_reduced_mu_residual':float(max(r['residual'] for r in roots)),
         'runtime_s':time.perf_counter()-start,
         'meaning':'All three polar CPA phase branches are trained MM potentials with one shared gauge; phase fractions are therefore not a lever-rule-only proxy.'}
    (RESULTS/'cpa_vlle_mm_summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))


if __name__=='__main__':main()
