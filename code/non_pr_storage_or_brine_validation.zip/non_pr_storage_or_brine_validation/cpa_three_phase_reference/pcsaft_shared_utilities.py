"""Three full shared-gauge MM branches for a polar PC-SAFT VLLE system.

Teacher: Thermopack PC-SAFT H2O/CO2/n-decane.  At each (T,P), the teacher
three-phase state is obtained by directly solving equality of all component
chemical potentials for a vapor, water-rich liquid and hydrocarbon-rich
liquid.  Homogeneous points around the three manifolds train three Massieu
branches.  No independent branch offset is fitted: tau, support count and one
single gauge shift are selected jointly on a monitor set.
"""
from pathlib import Path
import sys,json,time
import numpy as np
import pandas as pd
from scipy.optimize import least_squares,lsq_linear

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from benchmark_common import RESULTS,R,rel
from acgpv2.massieu import MassieuACGP,farthest_point_indices
from thermopack.pcsaft import pcsaft

COMPONENTS=['H2O','CO2','NC10'];LABELS=['gas','aqueous_liquid','hydrocarbon_liquid']
T_GRID=np.arange(320.,381.,10.)
P_GRID=np.array([1.,1.5,2.5,4.,6.,8.,10.])*1e6
TAUS=[.025,.05,.1,.2,.5,1.,2.]
M_VALUES=[128,256,512,768,1024]
PERTURB_PER_ROOT=40
SEED=14061


def value(x):return x[0] if isinstance(x,tuple) else x


def softmax2(v):
    a=np.r_[v,0.];a-=a.max();e=np.exp(a);return e/e.sum()


def logits(x):
    x=np.asarray(x,float);return np.log(x[:-1]/x[-1])


class PCSAFTTeacher:
    def __init__(self):
        self.eos=pcsaft(','.join(COMPONENTS))
        self.phases=[self.eos.VAPPH,self.eos.LIQPH,self.eos.LIQPH]

    def homogeneous(self,T,P,x,k):
        x=np.asarray(x,float);ph=self.phases[k]
        v=float(value(self.eos.specific_volume(T,P,x,ph)))
        mu=np.asarray(value(self.eos.chemical_potential_tv(T,v,x)),float)
        u=float(value(self.eos.internal_energy_tv(T,v,x)))
        h=float(value(self.eos.enthalpy(T,P,x,ph)))
        rho=1./v
        return {'T':float(T),'P':float(P),'x':x,'rho':rho,'h':h,'mu':mu,
                'eta':np.r_[-1/(R*T),mu/(R*T)],'psi':P/(R*T),
                'q':np.r_[u/v,rho*x]}

    def triple_residual(self,w,T,P):
        xs=[softmax2(w[i:i+2]) for i in (0,2,4)]
        mu=[self.homogeneous(T,P,x,k)['mu'] for k,x in enumerate(xs)]
        return np.r_[(mu[0]-mu[1])/(R*T),(mu[0]-mu[2])/(R*T)]

    def triple(self,T,P,starts=()):
        base=np.r_[logits([.02,.97,.01]),logits([.995,.004,.001]),logits([.02,.2,.78])]
        guesses=list(starts)+[base]
        best=None
        for guess in guesses:
            try:
                sol=least_squares(self.triple_residual,np.asarray(guess,float),args=(T,P),
                                  max_nfev=1800,xtol=2e-12,ftol=2e-12,gtol=2e-12,x_scale='jac')
                xs=np.asarray([softmax2(sol.x[i:i+2]) for i in (0,2,4)])
                sep=min(np.linalg.norm(xs[i]-xs[j]) for i in range(3) for j in range(i))
                resid=float(np.max(np.abs(sol.fun)))
                # A genuine solution must retain three distinct phases and the
                # intended water-rich/CO2-rich/hydrocarbon-rich identities.
                identity=(xs[0,1]>0.45 and xs[1,0]>0.80 and xs[2,2]>0.18)
                score=resid+(0 if identity else 100.)+(0 if sep>.08 else 100.)
                if best is None or score<best[0]:best=(score,sol,xs,sep,resid)
            except Exception:continue
        if best is None or best[4]>2e-7 or best[3]<=.08 or best[0]>=100.:
            return None
        states=[self.homogeneous(T,P,best[2][k],k) for k in range(3)]
        return {'T':T,'P':P,'w':best[1].x,'x':best[2],'states':states,
                'residual':best[4],'separation':best[3]}


def collect_triples(teacher):
    roots=[];warm=[]
    for T in T_GRID:
        for P in P_GRID:
            root=teacher.triple(T,P,warm[-2:])
            if root is not None:
                roots.append(root);warm.append(root['w'])
    if len(roots)<18:raise RuntimeError(f'Only {len(roots)} genuine PC-SAFT triple states were found')
    order=np.random.default_rng(SEED).permutation(len(roots))
    ntest=max(6,len(roots)//5);nmonitor=max(5,len(roots)//6)
    labels=np.full(len(roots),'train',object);labels[order[:ntest]]='test';labels[order[ntest:ntest+nmonitor]]='monitor'
    for i,r in enumerate(roots):r['split']=labels[i];r['root_id']=i
    rows=[]
    for r in roots:
        for k,s in enumerate(r['states']):
            rows.append({'root_id':r['root_id'],'split':r['split'],'T_K':r['T'],'P_Pa':r['P'],
                         'phase':LABELS[k],'mu_residual_reduced':r['residual'],'min_phase_separation':r['separation'],
                         'rho_molar':s['rho'],'h_molar':s['h'],**{f'x_{COMPONENTS[j]}':s['x'][j] for j in range(3)},
                         **{f'mu_{COMPONENTS[j]}':s['mu'][j] for j in range(3)}})
    pd.DataFrame(rows).to_csv(RESULTS/'pcsaft_vlle_teacher_roots.csv',index=False)
    return roots


def local_data(teacher,roots,split,rng,npert):
    branch=[[] for _ in range(3)]
    for r in roots:
        if r['split']!=split:continue
        for k,s0 in enumerate(r['states']):
            for j in range(npert):
                if j==0:T,P,x=r['T'],r['P'],s0['x']
                else:
                    T=float(np.clip(r['T']+rng.normal(0,2.0),316.,384.))
                    P=float(np.clip(r['P']*np.exp(rng.normal(0,.045)),.8e6,11e6))
                    x=softmax2(logits(s0['x'])+rng.normal(0,.13,2))
                try:branch[k].append(teacher.homogeneous(T,P,x,k))
                except Exception:continue
    out=[]
    for data in branch:
        out.append({'eta':np.asarray([s['eta'] for s in data]),'psi':np.asarray([s['psi'] for s in data]),
                    'q':np.asarray([s['q'] for s in data]),'T':np.asarray([s['T'] for s in data]),
                    'P':np.asarray([s['P'] for s in data]),'x':np.asarray([s['x'] for s in data]),
                    'rho':np.asarray([s['rho'] for s in data]),'h':np.asarray([s['h'] for s in data])})
    return out


def evaluate_branches(models,data):
    errs=[]
    for m,d in zip(models,data):
        p,q=m.evaluate_batch_eta(d['eta']);rho=q[:,1:].sum(1);x=q[:,1:]/rho[:,None]
        h=(q[:,0]+p*R*d['T'])/rho
        errs.append({'pressure_mean_rel':float(rel(p,d['psi']).mean()),
                     'density_mean_rel':float(rel(rho,d['rho']).mean()),
                     'composition_mean_abs':float(np.abs(x-d['x']).mean()),
                     'enthalpy_mean_rel':float(rel(h,d['h'],100.).mean())})
    return errs


def build_models(train,monitor,orders,M,tau):
    models=[]
    for k in range(3):
        d=train[k];ids=orders[k][:min(M,len(d['eta']))]
        models.append(MassieuACGP(d['eta'][ids],d['psi'][ids],d['q'][ids],tau=tau,
                                  center=d['eta'].mean(0),scale=d['eta'].std(0),name=LABELS[k]))
    residual=[]
    for m,d in zip(models,monitor):residual.extend(d['psi']-m.evaluate_batch_eta(d['eta'])[0])
    shared=float(np.median(residual))
    return [m.with_common_gauge_shift(shared) for m in models],shared


def solve_mm_triple(models,root):
    T=root['T'];P=root['P'];eta0=-1/(R*T)
    true_eta=np.mean([s['eta'] for s in root['states']],axis=0)
    def fun(ei):return np.asarray([(m.evaluate_eta(np.r_[eta0,ei])['psi']*R*T-P)/P for m in models])
    sol=least_squares(fun,true_eta[1:]+np.array([.02,-.01,.015]),max_nfev=500,
                      xtol=1e-12,ftol=1e-12,gtol=1e-12,x_scale='jac')
    eta=np.r_[eta0,sol.x];outs=[m.evaluate_eta(eta) for m in models]
    rho=np.asarray([o['c'].sum() for o in outs]);X=np.asarray([o['c']/o['c'].sum() for o in outs])
    h=np.asarray([(o['u']+P)/rr for o,rr in zip(outs,rho)])
    return {'success':bool(sol.success and max(abs(sol.fun))<2e-5),'residual':float(max(abs(sol.fun))),
            'eta':eta,'X':X,'rho':rho,'h':h,'nfev':int(sol.nfev)}


def fractions(z,X):
    A=np.vstack([X.T,np.ones(3)]);b=np.r_[z,1.]
    sol=lsq_linear(A,b,bounds=(0.,1.),tol=1e-13,lsmr_tol=1e-13,max_iter=200)
    return sol.x,float(np.max(np.abs(A@sol.x-b)))


def main():
    start=time.perf_counter();teacher=PCSAFTTeacher();roots=collect_triples(teacher);rng=np.random.default_rng(SEED+1)
    train=local_data(teacher,roots,'train',rng,PERTURB_PER_ROOT)
    monitor=local_data(teacher,roots,'monitor',rng,max(18,PERTURB_PER_ROOT//2))
    test=local_data(teacher,roots,'test',rng,max(18,PERTURB_PER_ROOT//2))
    maxM=min(min(len(d['eta']) for d in train),max(M_VALUES));mvals=[m for m in M_VALUES if m<=maxM]
    if maxM not in mvals:mvals.append(maxM)
    orders=[farthest_point_indices(d['eta'],maxM) for d in train]
    trials=[];stored={}
    for M in mvals:
        for tau in TAUS:
            models,g=build_models(train,monitor,orders,M,tau);errs=evaluate_branches(models,monitor)
            score=float(np.mean([e['pressure_mean_rel']+e['density_mean_rel']+e['composition_mean_abs']+e['enthalpy_mean_rel'] for e in errs]))
            trials.append({'M':M,'tau':tau,'shared_gauge':g,'score':score,
                           **{f'{LABELS[k]}_{key}':val for k,e in enumerate(errs) for key,val in e.items()}})
            stored[(M,tau)]=(models,g)
    trial=pd.DataFrame(trials);trial.to_csv(RESULTS/'pcsaft_vlle_model_selection.csv',index=False)
    best=trial.loc[trial.score.idxmin()];M=int(best.M);tau=float(best.tau);models,shared=stored[(M,tau)]
    for label,m in zip(LABELS,models):m.save(RESULTS/f'pcsaft_vlle_{label}_mm.npz')

    homogeneous=evaluate_branches(models,test);predrows=[];feedrows=[];classrows=[]
    for r in roots:
        if r['split']!='test':continue
        mm=solve_mm_triple(models,r);Xt=r['x'];rho_t=np.asarray([s['rho'] for s in r['states']]);h_t=np.asarray([s['h'] for s in r['states']])
        for k in range(3):
            predrows.append({'root_id':r['root_id'],'T_K':r['T'],'P_Pa':r['P'],'phase':LABELS[k],
                             'solver_success':mm['success'],'pressure_residual_rel':mm['residual'],'nfev':mm['nfev'],
                             'composition_L1':float(np.abs(mm['X'][k]-Xt[k]).sum()),
                             'density_rel':float(abs(mm['rho'][k]-rho_t[k])/rho_t[k]),
                             'enthalpy_rel':float(abs(mm['h'][k]-h_t[k])/max(abs(h_t[k]),100.)),
                             **{f'x_teacher_{c}':Xt[k,j] for j,c in enumerate(COMPONENTS)},
                             **{f'x_mm_{c}':mm['X'][k,j] for j,c in enumerate(COMPONENTS)}})
        for case in range(40):
            bt=rng.dirichlet(np.full(3,1.5));z=bt@Xt;bh,mass=fractions(z,mm['X'])
            feedrows.append({'root_id':r['root_id'],'case':case,'phase_fraction_max_abs':float(np.max(abs(bh-bt))),
                             'mass_residual_inf':mass,**{f'beta_true_{k}':bt[k] for k in range(3)},
                             **{f'beta_mm_{k}':bh[k] for k in range(3)},**{f'z_{c}':z[j] for j,c in enumerate(COMPONENTS)}})
        for case in range(300):
            z=rng.dirichlet(np.ones(3));bt=np.linalg.solve(Xt.T,z);bp=np.linalg.solve(mm['X'].T,z)
            yt=bool(np.min(bt)>=-1e-9 and np.max(bt)<=1+1e-9);yp=bool(np.min(bp)>=-1e-9 and np.max(bp)<=1+1e-9)
            classrows.append({'root_id':r['root_id'],'true_three_phase':yt,'mm_three_phase':yp,'correct':yt==yp})
    pred=pd.DataFrame(predrows);feeds=pd.DataFrame(feedrows);clas=pd.DataFrame(classrows)
    pred.to_csv(RESULTS/'pcsaft_vlle_mm_phase_predictions.csv',index=False)
    feeds.to_csv(RESULTS/'pcsaft_vlle_mm_feed_predictions.csv',index=False)
    clas.to_csv(RESULTS/'pcsaft_vlle_mm_region_classification.csv',index=False)
    out={'status':'completed','teacher':'Thermopack PC-SAFT','system':COMPONENTS,
         'temperature_range_K':[float(T_GRID.min()),float(T_GRID.max())],
         'pressure_range_MPa':[float(P_GRID.min()/1e6),float(P_GRID.max()/1e6)],
         'genuine_three_phase_roots':len(roots),'split_counts':pd.Series([r['split'] for r in roots]).value_counts().to_dict(),
         'selected_supports_per_branch':M,'selected_tau':tau,'single_shared_gauge':shared,
         'all_branch_gauges_identical':bool(max(m.gauge_offset for m in models)-min(m.gauge_offset for m in models)<1e-14),
         'positive_weights':True,'homogeneous_independent_test':{LABELS[k]:e for k,e in enumerate(homogeneous)},
         'triple_solver_success_fraction':float(pred.groupby('root_id').solver_success.first().mean()),
         'phase_composition_L1_mean':float(pred.composition_L1.mean()),
         'phase_composition_L1_max':float(pred.composition_L1.max()),
         'phase_density_mean_rel':float(pred.density_rel.mean()),'phase_enthalpy_mean_rel':float(pred.enthalpy_rel.mean()),
         'phase_fraction_MAE':float(np.mean(np.abs(feeds[[f'beta_mm_{k}' for k in range(3)]].to_numpy()-feeds[[f'beta_true_{k}' for k in range(3)]].to_numpy()))),
         'phase_fraction_max_abs':float(feeds.phase_fraction_max_abs.max()),
         'three_phase_region_classification_accuracy':float(clas.correct.mean()),
         'teacher_max_reduced_mu_residual':float(max(r['residual'] for r in roots)),
         'runtime_s':time.perf_counter()-start,
         'meaning':'Unlike the old SRK lever-rule audit, every reported property is predicted by three trained MM Massieu branches sharing one explicit gauge.'}
    (RESULTS/'pcsaft_vlle_mm_summary.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
