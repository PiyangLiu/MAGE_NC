#!/usr/bin/env python3
"""Minimal non-PR gas--brine generation-potential validation.

The teacher is the local extensive Gibbs model used for the gas--brine example.
It includes HEOS water/H2 reference fits, Pitzer NaCl activity data, and the
published H2 Henry/Setchenov/partial-volume correlations.  NaCl is represented
as a neutral conserved formula unit; this is intentionally not advertised as a
full electrolyte CPA or reactive geochemical EOS.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
import sys
sys.path.insert(0, str(HERE))
from acgpv2.p3_brine import BrineGibbs, make_reference, MW, R  # noqa: E402

REF = HERE / "reference_data"


def finite_difference_gradient(teacher, T, P, b, m):
    # A liquid state with n=[H2, H2O, NaCl] is used for the direct Gibbs check.
    n = np.array([b, 1.0 / MW, m], float)
    z = torch.tensor([[T, P, *n]], dtype=torch.float64)
    _, G, grad, _, _, eta, q = teacher.physical(z, "liquid")
    analytic = grad.detach().numpy()[0]
    fd = []
    for j, h in [(1, max(1.0, P * 1e-6)), (2, 1e-6), (3, 1e-5), (4, 1e-5)]:
        zp = z.clone(); zm = z.clone()
        zp[0, j] += h; zm[0, j] -= h
        gp = teacher.gibbs(zp, "liquid").detach().numpy()[0]
        gm = teacher.gibbs(zm, "liquid").detach().numpy()[0]
        fd.append((gp - gm) / (2.0 * h))
    fd = np.asarray(fd)
    ana = analytic[[1, 2, 3, 4]]
    rel = np.abs(fd - ana) / np.maximum(np.abs(ana), 1.0)
    H = teacher.state(T, P, b, m, "liquid")["H"][0]
    return {
        "analytic_gradient_P_nH2_nH2O_nNaCl": ana.tolist(),
        "finite_difference_gradient": fd.tolist(),
        "relative_error_each": rel.tolist(),
        "maximum_relative_error": float(rel.max()),
        "H_symmetric_error": float(np.max(np.abs(H - H.T))),
        "H_min_eigenvalue": float(np.linalg.eigvalsh(H).min()),
        "eta_finite": bool(np.isfinite(eta.detach().numpy()).all()),
        "q_finite": bool(np.isfinite(q.detach().numpy()).all()),
    }


def main():
    # Loading the frozen reference coefficients requires no external property
    # package; CoolProp/PHREEQC are needed only when regenerating this file.
    teacher = BrineGibbs(dict(np.load(REF / "gibbs_reference.npz")))
    derivative = finite_difference_gradient(teacher, 323.15, 1.0e7, 0.1, 1.0)
    coexistence = []
    for T, P, m in [(303.15, 1.0e7, 0.5), (323.15, 1.0e7, 1.0), (343.15, 2.0e7, 2.0)]:
        try:
            r = teacher.coexist(T, P, m)
            coexistence.append({"T_K": T, "P_Pa": P, "m_NaCl_mol_per_kg_water": m,
                                "chemical_potential_residual": r["residual"],
                                "liquid_density_mol_m3": float(r["liquid"]["rho"][0]),
                                "gas_density_mol_m3": float(r["gas"]["rho"][0]),
                                "liquid_H2_mole_fraction": float(r["liquid"]["x"][0, 0]),
                                "gas_H2_mole_fraction": float(r["gas"]["x"][0, 0])})
        except Exception as exc:
            coexistence.append({"T_K": T, "P_Pa": P, "m_NaCl_mol_per_kg_water": m,
                                "failed": True, "error": str(exc)})
    existing = json.loads((REF / "existing_mage_kkt_summary.json").read_text(encoding="utf-8"))
    result = {
        "status": "completed",
        "reference_potential": "single extensive Gibbs teacher",
        "system": ["H2", "H2O", "neutral NaCl formula unit"],
        "derivative_check": derivative,
        "coexistence_checks": coexistence,
        "existing_independent_MAGE_KKT_result": existing,
        "scope": {
            "included": ["pressure from Gibbs derivative", "chemical potentials", "internal energy", "state derivatives", "gas-brine coexistence", "finite-support KKT branch evaluation in retained result"],
            "not_claimed": ["ion-by-ion electrolyte CPA", "aqueous reaction network", "salt precipitation", "full multicomponent gas EOS", "independent calorimetric validation"],
            "reason": "the validated local teacher conserves NaCl as a neutral formula unit and uses a low-density H2 gas approximation; its purpose here is to demonstrate the calculation organization for a non-PR complex reference potential."
        }
    }
    (HERE / "brine_validation_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
