"""Smooth convex Massieu atoms with local quadratic and linear-tail growth."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from .psd_quadratic import PSDQuadraticMassieuACGP


@dataclass
class BoundedCurvatureMassieuACGP(PSDQuadraticMassieuACGP):
    radii: np.ndarray | None = None

    def __post_init__(self):
        super().__post_init__()
        if self.radii is None:
            raise ValueError("positive radii in sqrt(potential) units are required")
        self.radii = np.asarray(self.radii, float)
        if self.radii.shape != (self.n_atoms,) or not np.all(np.isfinite(self.radii)) or np.any(self.radii <= 0):
            raise ValueError("radii must be finite positive values, one per atom")

    def atom_terms(self, eta):
        X = (np.asarray(eta, float) - self.center) / self.scale
        dx = X[:, None, :] - self.atom_x[None, :, :]
        bd = np.einsum("mij,bmj->bmi", self.atom_Bx, dx)
        energy = np.maximum(np.einsum("bmi,bmi->bm", dx, bd), 0.)
        r2 = self.radii[None, :] ** 2
        s = np.sqrt(1. + energy / r2)
        # energy/(s+1) equals r^2*(s-1) without cancellation near contact.
        Q = self.atom_psi[None, :] + np.einsum("bmi,mi->bm", dx, self.atom_qx) + energy / (s + 1.)
        g = self.atom_qx[None, :, :] + bd / s[:, :, None]
        Hb = self.atom_Bx[None, :, :, :] / s[:, :, None, None]
        Hb -= np.einsum("bmi,bmj->bmij", bd, bd) / (r2 * s ** 3)[:, :, None, None]
        return Q, g, Hb, dx

    def evaluate_details(self, eta, chunk=128):
        """Return analytic properties plus occupations and local diagnostics.

        H_B and H_C, traces, radii and path diagnostics are in one *model*
        coordinate system. The mixture uses constant positive scale weights.
        """
        eta = np.atleast_2d(np.asarray(eta, float))
        collected = {}
        for start in range(0, len(eta), chunk):
            Q, ga, Hb, dx = self.atom_terms(eta[start:start + chunk])
            n = len(Q); p = np.zeros(n); g = np.zeros((n, self.dim)); HB = np.zeros((n, self.dim, self.dim)); HC = np.zeros_like(HB)
            occ = np.zeros_like(Q); chi_scales = []; neff_scales = []
            displacement_cov_over_tau = np.zeros_like(HB)
            dist2 = np.sum(dx * dx, axis=2)
            for alpha, tau, lw in zip(self.scale_weights, self.taus, self.log_weights):
                score = Q / tau + lw; shift = score.max(1, keepdims=True); ex = np.exp(score - shift); w = ex / ex.sum(1, keepdims=True)
                gg = np.einsum("bm,bmi->bi", w, ga)
                centered = ga - gg[:, None, :]
                hb = np.einsum("bm,bmij->bij", w, Hb)
                hc = np.einsum("bm,bmi,bmj->bij", w, centered, centered) / tau
                p += alpha * tau * (shift[:, 0] + np.log(ex.sum(1))); g += alpha * gg; HB += alpha * hb; HC += alpha * hc; occ += alpha * w
                order = np.argsort(dist2, axis=1); ordered_w = np.take_along_axis(w, order, axis=1)
                jj = np.argmax(np.cumsum(ordered_w, axis=1) >= .95, axis=1)
                r95sq = np.take_along_axis(dist2, order, axis=1)[np.arange(n), jj]
                chi_scales.append(np.linalg.eigvalsh(hb + hc)[:, -1] * r95sq / tau)
                neff_scales.append(1. / np.sum(w * w, axis=1))
                md = np.einsum("bm,bmi->bi", w, dx); cd = dx - md[:, None, :]
                displacement_cov_over_tau += alpha * np.einsum("bm,bmi,bmj->bij", w, cd, cd) / tau
            Hx = HB + HC
            order = np.argsort(dist2, axis=1); ordered_w = np.take_along_axis(occ, order, axis=1)
            jj = np.argmax(np.cumsum(ordered_w, axis=1) >= .95, axis=1)
            r95 = np.sqrt(np.take_along_axis(dist2, order, axis=1)[np.arange(n), jj])
            mean_d = np.einsum("bm,bmi->bi", occ, dx); centered_d = dx - mean_d[:, None, :]
            displacement_cov = np.einsum("bm,bmi,bmj->bij", occ, centered_d, centered_d)
            vals = {"psi": p + self.gauge, "q": g / self.scale, "H": Hx / (self.scale[:, None] * self.scale[None, :]),
                    "H_Bx": HB, "H_Cx": HC, "occupations": occ, "N_eff": 1. / np.sum(occ * occ, axis=1),
                    "N_eff_scales": np.stack(neff_scales, axis=1), "r_near": np.sqrt(dist2.min(1)), "r95": r95,
                    "chi95_scales": np.stack(chi_scales, axis=1), "displacement_cov": displacement_cov,
                    "displacement_cov_over_tau": displacement_cov_over_tau}
            for key, value in vals.items(): collected.setdefault(key, []).append(value)
        return {k: np.concatenate(v) for k, v in collected.items()}

    def evaluate_batch_eta_hessian(self, eta, chunk=128):
        eta = np.atleast_2d(np.asarray(eta, float))
        pp, qq, hh = [], [], []
        # Production property evaluation retains O(N*D^2) outputs, rather
        # than the O(N*M) occupation arrays required by diagnostic calls.
        for first in range(0, len(eta), chunk):
            d = self.evaluate_details(eta[first:first + chunk], chunk)
            pp.append(d["psi"]); qq.append(d["q"]); hh.append(d["H"])
        return np.concatenate(pp), np.concatenate(qq), np.concatenate(hh)

    def evaluate_batch_eta(self, eta, chunk=128):
        p, q, _ = self.evaluate_batch_eta_hessian(eta, chunk)
        return p, q

    def evaluate_eta(self, eta, return_hessian=False):
        d = self.evaluate_details(np.asarray(eta)[None, :])
        ans = {"psi": float(d["psi"][0]), "q": d["q"][0], "u": float(d["q"][0, 0]), "c": d["q"][0, 1:], "weights": d["occupations"][0]}
        if return_hessian: ans["H_eta"] = d["H"][0]
        return ans

    def save(self, path):
        np.savez_compressed(path, atom_eta=self.atom_eta, atom_psi=self.atom_psi, atom_q=self.atom_q,
                            atom_B=self.atom_B, taus=self.taus, log_weights=self.log_weights,
                            scale_weights=self.scale_weights, gauge=self.gauge, name=self.name,
                            center=self.center, scale=self.scale, radii=self.radii,
                            format_version=np.array([1]))

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as d:
            return cls(d["atom_eta"], d["atom_psi"], d["atom_q"], d["atom_B"], d["taus"],
                       d["log_weights"], d["scale_weights"], float(d["gauge"]), str(d["name"]),
                       d["center"], d["scale"], d["radii"])
