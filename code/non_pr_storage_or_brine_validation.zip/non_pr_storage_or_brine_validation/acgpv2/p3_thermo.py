"""TPz properties and implicit derivatives for equal-solver P3 comparisons.

Thermopack derivatives are analytic. HEOS composition derivatives use symmetric
homogeneous-phase differences, never finite differences of a flash. MM uses the
analytic implicit derivative of its own global-mu natural-map equations.
"""
from __future__ import annotations
import time
import numpy as np
from scipy.optimize import least_squares
from scipy.special import expit, logit
from .pr import R


def phase_fields(T, P, x, v, h, dv, dh, dx):
    rho = 1 / v
    dr = -dv / v**2
    c = rho * x
    dc = x[:, None] * dr + rho * dx
    u = rho * h - P
    du = dr * h + rho * dh - np.array([0., 1., 0.])
    return c, dc, u, du


class TeacherTPz:
    def __init__(self, backend, atlas=None):
        self.backend = backend
        self.calls = 0
        self.wall = 0.
        self.tie_recoveries = 0
        self.atlas = atlas
        if backend == 'HEOS':
            import CoolProp.CoolProp as CP
            self.CP = CP
            self.flash = CP.AbstractState('HEOS', 'Hydrogen&CarbonDioxide')
            self.phases = [CP.AbstractState('HEOS', 'Hydrogen&CarbonDioxide') for _ in range(2)]
            for a, phase in zip(self.phases, [CP.iphase_liquid, CP.iphase_gas]):
                a.specify_phase(phase)
        elif backend == 'GERG':
            from thermopack.multiparameter import multiparam
            self.eos = multiparam('H2,CO2', 'GERG2008')
        elif backend == 'PR':
            from thermopack.cubic import cubic
            self.eos = cubic('H2,CO2', 'PR')
        else:
            raise ValueError(backend)

    def homogeneous(self, T, P, x, phase, derivatives=True):
        x = np.array([x, 1-x], float)
        if self.backend != 'HEOS':
            m = self.eos
            flag = m.LIQPH if phase == 0 else m.VAPPH
            if derivatives:
                v, vt, vp, vn = m.specific_volume(T, P, x, flag, dvdt=True, dvdp=True, dvdn=True)
                h, ht, hp, hn = m.enthalpy(T, P, x, flag, dhdt=True, dhdp=True, dhdn=True)
                f, ft, fp, fn = m.thermo(T, P, x, flag, dlnfugdt=True, dlnfugdp=True, dlnfugdn=True)
                df = np.column_stack([ft, fp, np.array([1/x[0], -1/x[1]]) + fn[:, 0]-fn[:, 1]])
                return float(v), float(h), np.log(x)+f, np.array([vt, vp, vn[0]-vn[1]]), np.array([ht, hp, hn[0]-hn[1]]), df
            return float(m.specific_volume(T,P,x,flag)[0]), float(m.enthalpy(T,P,x,flag)[0]), np.log(x)+m.thermo(T,P,x,flag)[0], None, None, None
        a = self.phases[phase]
        CP = self.CP
        def at(t,p,xx):
            a.set_mole_fractions([xx, 1-xx])
            a.update(CP.PT_INPUTS, float(p), float(t))
            return np.r_[1/a.rhomolar(), a.hmolar(), [a.chemical_potential(i)/(R*t) for i in range(2)]]
        y = at(T,P,x[0])
        if not derivatives:
            return y[0], y[1], y[2:], None, None, None
        # Tight homogeneous differences avoid the discontinuous flash map.
        hz = [2e-5*T, max(1., 2e-5*P), min(x.min()*2e-4, 2e-6)]
        z = np.array([T,P,x[0]])
        cols = []
        for j, step in enumerate(hz):
            za=z.copy(); zb=z.copy(); za[j]+=step; zb[j]-=step
            cols.append((at(*za)-at(*zb))/(2*step))
        dy=np.column_stack(cols)
        return y[0], y[1], y[2:], dy[0], dy[1], dy[2:]

    def split(self,T,P,z):
        if self.backend != 'HEOS':
            m=self.eos; f=m.two_phase_tpflash(T,P,[z,1-z])
            if f.phase == m.TWOPH and 0 < f.betaV < 1:
                return float(f.betaV), float(f.x[0]), float(f.y[0]), None
            v = m.thermo(T,P,[z,1-z],m.MINGIBBSPH,ophase=True)
            tag = 1 if int(v[-1]) == m.VAPPH else 0
            return float(tag),z,z,tag
        try:
            a=self.flash; a.set_mole_fractions([z,1-z]); a.update(self.CP.PT_INPUTS,P,T)
            beta=a.Q()
            if 0 < beta < 1:
                return beta,float(a.mole_fractions_liquid()[0]),float(a.mole_fractions_vapor()[0]),None
            tag=1 if a.rhomolar()<8000 else 0
            return float(tag),z,z,tag
        except ValueError:
            # Recover the actual HEOS coexistence, not a surrogate tie line.
            if self.atlas is None:
                raise
            a=self.atlas
            j=np.argmin(((a['T']-T)/50)**2+(np.log(a['P']/P))**2)
            x0,y0=a['x'][j,0],a['y'][j,0]
            def fun(v):
                x,y=expit(v)
                try:
                    return self.homogeneous(T,P,x,0,False)[2]-self.homogeneous(T,P,y,1,False)[2]
                except ValueError:
                    return np.ones(2)*1e5
            sol=least_squares(fun,logit([x0,y0]),bounds=(-22,12),xtol=1e-11,ftol=1e-11,gtol=1e-11,max_nfev=100)
            x,y=expit(sol.x)
            if max(abs(fun(sol.x)))>2e-7 or y-x<1e-3:
                raise RuntimeError('HEOS recovery failed/non-separated root')
            self.tie_recoveries+=1
            if z <= x: return 0.,z,z,0
            if z >= y: return 1.,z,z,1
            return (z-x)/(y-x),x,y,None

    def one(self,T,P,z,derivatives=True):
        beta,x,y,tag=self.split(T,P,z)
        if tag is None:
            L=self.homogeneous(T,P,x,0,derivatives)
            V=self.homogeneous(T,P,y,1,derivatives)
            if derivatives:
                A=np.column_stack([L[5][:,2],-V[5][:,2]])
                dxy=np.linalg.solve(A,-(L[5][:,:2]-V[5][:,:2]))
                dx=np.r_[dxy[0],0.]; dy=np.r_[dxy[1],0.]
                db=(np.array([0.,0.,1.])-(1-beta)*dx-beta*dy)/(y-x)
            else: dx=dy=db=np.zeros(3)
        else:
            L=V=self.homogeneous(T,P,z,tag,derivatives)
            dx=dy=np.array([0.,0.,1.]);db=np.zeros(3)
        def phase(a,xx,dxx):
            v,h=a[:2]
            dv=a[3][:2].tolist()+[0.] if derivatives else np.zeros(3)
            dh=a[4][:2].tolist()+[0.] if derivatives else np.zeros(3)
            if derivatives:
                dv=np.array(dv)+a[3][2]*dxx;dh=np.array(dh)+a[4][2]*dxx
            c,dc,u,du=phase_fields(T,P,np.array([xx,1-xx]),v,h,np.asarray(dv),np.asarray(dh),np.vstack([dxx,-dxx]))
            return v,np.asarray(dv),c,dc,u,du
        vl,dvl,cL,dcL,uL,duL=phase(L,x,dx)
        vv,dvv,cV,dcV,uV,duV=phase(V,y,dy)
        v=(1-beta)*vl+beta*vv
        dv=(1-beta)*dvl+beta*dvv+db*(vv-vl)
        S=beta*vv/v
        dS=(db*vv+beta*dvv)/v-S*dv/v
        C=(1-S)*cL+S*cV;U=(1-S)*uL+S*uV
        dC=(1-S)*dcL+S*dcV+(cV-cL)[:,None]*dS
        dU=(1-S)*duL+S*duV+(uV-uL)*dS
        return dict(T=T,P=P,S=S,C=C,U=U,cL=cL,cV=cV,uL=uL,uV=uV,hL=uL+P,hV=uV+P,
                    dC=dC,dU=dU,dS=dS,dcL=dcL,dcV=dcV,dhL=duL+np.array([0.,1.,0.]),dhV=duV+np.array([0.,1.,0.]))

    def state(self,w,derivatives=True):
        start=time.perf_counter();T=w[:,0]*260;P=w[:,1]*4e6;z=expit(w[:,2])
        rows=[self.one(t,p,x,derivatives) for t,p,x in zip(T,P,z)]
        self.calls+=len(w);self.wall+=time.perf_counter()-start
        result={k:np.asarray([r[k] for r in rows]) for k in rows[0]}
        scale=np.column_stack([np.full(len(w),260.),np.full(len(w),4e6),z*(1-z)])
        for k in ['dC','dU','dS','dcL','dcV','dhL','dhV']:
            result[k]*=scale[:,None,:] if result[k].ndim==3 else scale
        result['dT']=np.tile([260.,0.,0.],(len(w),1));result['dP']=np.tile([0.,4e6,0.],(len(w),1))
        return result


class MMTPz:
    def __init__(self, solver,kkt_tolerance=1e-9):
        self.solver=solver;self.calls=0;self.wall=0.;self.cache_w=None;self.cache_st=None;self.last_solution=None
        self.kkt_tolerance=kkt_tolerance

    def state(self,w,derivatives=True):
        import torch
        if self.cache_w is not None and np.array_equal(w,self.cache_w):
            return self.cache_st
        start=time.perf_counter();s=self.solver;T=w[:,0]*260;P=w[:,1]*4e6;z=expit(w[:,2])
        initial=self.last_solution if self.cache_w is not None and self.cache_w.shape==w.shape and np.max(abs(w-self.cache_w))<.1 else None
        r=s.solve(T,P,np.column_stack([z,1-z]),initial=initial,tol=self.kkt_tolerance,chunk=512)
        if not r['success'].all(): raise RuntimeError(f"uncertified MM KKT: {(~r['success']).sum()} cells")
        parts=[]
        with torch.no_grad():
            for i in range(0,len(w),512):
                sl=slice(i,i+512);tt=torch.as_tensor(T[sl],device=s.device);pp=torch.as_tensor(P[sl],device=s.device)
                zz=torch.as_tensor(np.column_stack([z[sl],1-z[sl]]),device=s.device);ww=torch.as_tensor(r['w'][sl],device=s.device)
                f,J,st=s.residual(ww,tt,pp,zz)
                n=len(tt);S=st['S'];target=pp/(R*tt);C=st['C'];rho=st['rho'];zx=C/rho[:,None]
                e0=1/(R*tt**2);c0=((1-S[:,None])*st['HL'][:,1:,0]+S[:,None]*st['HV'][:,1:,0])*e0[:,None]
                B=torch.zeros((n,3,3),device=s.device,dtype=tt.dtype)
                B[:,0,0]=((1-S)*st['qL'][:,0]+S*st['qV'][:,0])*e0/target+(f[:,0]+1)/tt
                B[:,0,1]=-(f[:,0]+1)/pp
                B[:,1,0]=(c0[:,0]-zx[:,0]*c0.sum(1))/rho;B[:,1,2]=-1
                gap=(st['pV']-st['pL'])/target;interior=((S+gap)>0)&((S+gap)<1)
                B[:,2,0]=torch.where(interior,-(st['qV'][:,0]-st['qL'][:,0])*e0/target-gap/tt,0.)
                B[:,2,1]=torch.where(interior,gap/pp,0.)
                dw=torch.linalg.solve(J,-B);dS=dw[:,2,:]
                de=torch.zeros((n,3,3),device=s.device,dtype=tt.dtype);de[:,0,0]=e0;de[:,1:,:]=dw[:,:2,:]*s.L.scale[None,1:,None]
                row=dict(T=tt,P=pp,S=S,dS=dS)
                for tag in ['L','V']:
                    q=st['q'+tag];dq=st['H'+tag]@de
                    row['c'+tag]=q[:,1:];row['dc'+tag]=dq[:,1:,:];row['u'+tag]=q[:,0]
                    row['h'+tag]=q[:,0]+pp;row['dh'+tag]=dq[:,0,:]+torch.tensor([0.,1.,0.],device=s.device)
                row['C']=C;row['U']=(1-S)*st['qL'][:,0]+S*st['qV'][:,0]
                row['dC']=(1-S[:,None,None])*row['dcL']+S[:,None,None]*row['dcV']+(row['cV']-row['cL'])[:,:,None]*dS[:,None,:]
                row['dU']=(1-S[:,None])*(row['dhL']-torch.tensor([0.,1.,0.],device=s.device))+S[:,None]*(row['dhV']-torch.tensor([0.,1.,0.],device=s.device))+(row['uV']-row['uL'])[:,None]*dS
                parts.append({k:v.cpu().numpy() for k,v in row.items()})
        result={k:np.concatenate([r[k] for r in parts]) for k in parts[0]}
        scale=np.column_stack([np.full(len(w),260.),np.full(len(w),4e6),z*(1-z)])
        for k in ['dC','dU','dS','dcL','dcV','dhL','dhV']:
            result[k]*=scale[:,None,:] if result[k].ndim==3 else scale
        result['dT']=np.tile([260.,0.,0.],(len(w),1));result['dP']=np.tile([0.,4e6,0.],(len(w),1))
        self.calls+=len(w);self.wall+=time.perf_counter()-start
        self.cache_w=w.copy();self.cache_st=result;self.last_solution=r['w'].copy()
        return result
