"""Independent constrained Gibbs minimization of a polar CPA TPz mixture."""
import numpy as np
from scipy.optimize import minimize,least_squares
from scipy.special import softmax
from .pr import R


def gibbs_flash(teacher,T,P,z,tie,previous=None):
    z=np.asarray(z);mu_ref=np.mean([s['mu'] for s in tie['states']],axis=0)
    X=tie['x'];beta=np.linalg.lstsq(X.T,z,rcond=None)[0];beta=np.maximum(beta,1e-5);beta/=beta.sum()
    allocations=beta[:,None]*X;allocations*=z[None]/allocations.sum(0)[None]
    starts=[('tie',allocations)]
    if previous is not None:
        a=np.maximum(previous['amounts'],1e-12);a*=z[None]/a.sum(0)[None];starts.append(('previous',a))
    for k in range(3):
        a=np.full((3,3),1e-12);a[k]=z-2e-12;starts.append((f'phase{k}',a))
    cache={}
    def fg(v):
        key=v.tobytes()
        if key in cache:return cache[key]
        n=v.reshape(3,3);value=0.;gradient=[];states=[]
        for k in range(3):
            total=n[k].sum();x=np.maximum(n[k],1e-15);x/=x.sum();s=teacher.homogeneous(T,P,x,k)
            g=(s['mu']-mu_ref)/(R*T);value+=n[k]@g;gradient.extend(g);states.append(s)
        cache.clear();cache[key]=(value,np.array(gradient),states);return cache[key]
    A=np.tile(np.eye(3),(1,3))
    attempts=[];candidates=[]
    for name,a in starts:
        opt=minimize(lambda v:fg(v)[0],a.ravel(),jac=lambda v:fg(v)[1],bounds=[(1e-14,float(zi)) for _ in range(3) for zi in z],constraints=[dict(type='eq',fun=lambda v:A@v-z,jac=lambda v:A)],method='SLSQP',options=dict(ftol=1e-12,maxiter=400))
        mass=float(max(abs(A@opt.x-z)))
        attempts.append(dict(start=name,success=bool(opt.success),objective=float(opt.fun),mass_residual=mass,evaluations=int(opt.nfev),message=str(opt.message)))
        if np.isfinite(opt.fun) and mass<1e-8:candidates.append((opt.fun,opt))
    if not candidates:raise RuntimeError(f'No feasible CPA Gibbs multistart: {attempts}')
    _,opt=min(candidates,key=lambda item:item[0])
    n=opt.x.reshape(3,3);b=n.sum(1);xx=n/np.maximum(b[:,None],1e-30);states=fg(opt.x)[2]
    # Identical liquid phases are one physical phase, regardless of how a
    # constrained optimizer distributes their interchangeable phase labels.
    rho=np.array([s['rho'] for s in states]);h=np.array([s['h'] for s in states])
    active=np.where(b>1e-5)[0].tolist();unique=[]
    for k in active:
        # A requested liquid root can collapse to the gas root outside its
        # existence range. Identify physical states, not requested root labels.
        duplicate=next((j for j in unique if np.linalg.norm(xx[k]-xx[j])<1e-5 and abs(rho[k]/rho[j]-1)<1e-4),None)
        if duplicate is None:unique.append(k)
        else:b[duplicate]+=b[k];b[k]=0
    g=fg(opt.x)[1].reshape(3,3);equilibrium=max((float(np.max(abs(g[k]-g[unique[0]]))) for k in unique),default=0.)
    polish_evaluations=0
    if equilibrium>1e-6 and len(unique)>1:
        count=len(unique)
        seed=np.r_[np.log(xx[unique,:2]/xx[unique,2,None]).ravel(),np.log(b[unique[:-1]]/b[unique[-1]])]
        def stationary(w,fields=False):
            composition=softmax(np.column_stack([w[:2*count].reshape(count,2),np.zeros(count)]),axis=1)
            fraction=softmax(np.r_[w[2*count:],0.])
            jets=[teacher.homogeneous(T,P,x,k) for k,x in zip(unique,composition)]
            mu=np.array([s['mu']/(R*T) for s in jets]);feed=fraction@composition
            residual=np.r_[(mu[1:]-mu[0]).ravel(),(feed[:2]-z[:2])/np.maximum(z[:2],1e-8)]
            return (composition,fraction,jets,residual) if fields else residual
        polished=least_squares(stationary,seed,bounds=(-60,60),max_nfev=250,xtol=1e-13,ftol=1e-13,gtol=1e-13,x_scale='jac')
        cx,cb,jets,rr=stationary(polished.x,True);polish_evaluations=int(polished.nfev)
        if np.max(abs(rr))<1e-6:
            n=np.zeros((3,3));b=np.zeros(3)
            for k,x,bb,s in zip(unique,cx,cb,jets):
                xx[k]=x;b[k]=bb;n[k]=bb*x;rho[k]=s['rho'];h[k]=s['h']
            equilibrium=float(np.max(abs(rr[:3*(count-1)])))
        else:
            attempts.append(dict(start='stationarity_polish',success=False,residual=float(np.max(abs(rr))),evaluations=polish_evaluations))
    mass=float(np.max(abs(n.sum(0)-z)))
    return dict(success=bool(opt.success and mass<1e-8 and equilibrium<1e-5),message=opt.message,amounts=n,beta=b,x=xx,phases=len(unique),rho=float(1/(b/rho).sum()),h=float(b@h),objective=float(opt.fun),evaluations=sum(a['evaluations'] for a in attempts)+polish_evaluations,mass_residual=mass,active_mu_residual=equilibrium,multistart_attempts=attempts)
