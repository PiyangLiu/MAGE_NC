from __future__ import annotations
import numpy as np
from .pr import PREOS
from .helmholtz import massieu_teacher_from_c


def _stack_rows(rows,names):
    out={}
    for k in ['eta','psi','q','c','T','P','composition','Z']:
        if k in rows[0]:
            out[k]=np.asarray([r[k] for r in rows])
    out['names']=list(names)
    return out


def massieu_branch_dataset(names,phase,n=2500,T_range=(285.,355.),P_range=(.7e6,4e6),
                           composition_center=None,composition_sigma=.35,seed=1,
                           z_filter=None,kij=None):
    rng=np.random.default_rng(seed); eos=PREOS(names,kij=kij); nc=len(names)
    if composition_center is None: composition_center=np.ones(nc)/nc
    composition_center=np.asarray(composition_center,float); l0=np.log(composition_center)
    raw=[]
    attempts=0
    while len(raw)<n and attempts<20*n:
        attempts+=1
        T=float(rng.uniform(*T_range)); P=float(rng.uniform(*P_range))
        L=l0+rng.normal(0,composition_sigma,nc); L-=L.max(); x=np.exp(L); x/=x.sum()
        try:
            st=eos.state(T,P,x,phase)
        except Exception:
            continue
        Z=st['Z']
        if z_filter is not None and not z_filter(Z): continue
        raw.append((T,P,x,st['c'],Z))
    if not raw: raise RuntimeError('No valid PR states')
    T=np.array([r[0] for r in raw]); c=np.array([r[3] for r in raw])
    th=massieu_teacher_from_c(T,c,names,kij=kij)
    rows=[]
    for j,(tt,pp,x,cc,Z) in enumerate(raw):
        rows.append({'eta':th['eta'][j],'psi':th['psi'][j],'q':th['q'][j],'c':cc,
                     'T':tt,'P':pp,'composition':x,'Z':Z})
    return eos,_stack_rows(rows,names)


def binary_phase_datasets(T_range=(285.,355.),n_each=2600,seed=1):
    names=['CH4','nC4']; eos=PREOS(names); rng=np.random.default_rng(seed)
    rows={'liquid':[],'vapor':[]}
    # Purposefully cover different branch composition regions.
    while len(rows['liquid'])<n_each or len(rows['vapor'])<n_each:
        T=float(rng.uniform(*T_range)); P=float(rng.uniform(.65e6,4.2e6))
        if len(rows['liquid'])<n_each:
            x1=float(rng.uniform(.003,.48)); x=np.array([x1,1-x1])
            try:
                st=eos.state(T,P,x,'liquid')
                if st['Z']<.40: rows['liquid'].append((T,P,x,st['c'],st['Z']))
            except Exception: pass
        if len(rows['vapor'])<n_each:
            y1=float(rng.uniform(.01,.997)); y=np.array([y1,1-y1])
            try:
                st=eos.state(T,P,y,'vapor')
                if st['Z']>.42: rows['vapor'].append((T,P,y,st['c'],st['Z']))
            except Exception: pass
    out={}
    for phase in ['liquid','vapor']:
        raw=rows[phase]; T=np.array([r[0] for r in raw]); c=np.array([r[3] for r in raw])
        th=massieu_teacher_from_c(T,c,names)
        R=[]
        for j,(tt,pp,x,cc,Z) in enumerate(raw):
            R.append({'eta':th['eta'][j],'psi':th['psi'][j],'q':th['q'][j],'c':cc,
                      'T':tt,'P':pp,'composition':x,'Z':Z})
        out[phase]=_stack_rows(R,names)
    return eos,out


def ternary_phase_datasets(T_range=(300.,340.),n_each=3200,seed=3):
    names=['CH4','CO2','nC4']; eos=PREOS(names); rng=np.random.default_rng(seed)
    centers={'liquid':np.array([.12,.18,.70]),'vapor':np.array([.62,.28,.10])}
    out={}
    for phase in ['liquid','vapor']:
        raw=[]; l0=np.log(centers[phase])
        while len(raw)<n_each:
            T=float(rng.uniform(*T_range)); P=float(rng.uniform(1.2e6,3.4e6))
            L=l0+rng.normal(0,.42,3);L-=L.max();x=np.exp(L);x/=x.sum()
            try:
                st=eos.state(T,P,x,phase)
                if (phase=='liquid' and st['Z']<.40) or (phase=='vapor' and st['Z']>.42):
                    raw.append((T,P,x,st['c'],st['Z']))
            except Exception: pass
        T=np.array([r[0] for r in raw]); c=np.array([r[3] for r in raw])
        th=massieu_teacher_from_c(T,c,names)
        R=[]
        for j,(tt,pp,x,cc,Z) in enumerate(raw):
            R.append({'eta':th['eta'][j],'psi':th['psi'][j],'q':th['q'][j],'c':cc,
                      'T':tt,'P':pp,'composition':x,'Z':Z})
        out[phase]=_stack_rows(R,names)
    return eos,out


def split_data(D,n_train,n_val,seed=0):
    rng=np.random.default_rng(seed); n=len(D['eta']); ids=rng.permutation(n)
    a=ids[:n_train]; b=ids[n_train:n_train+n_val]; c=ids[n_train+n_val:]
    def take(ii):
        return {k:(v[ii] if isinstance(v,np.ndarray) and len(v)==n else v) for k,v in D.items()}
    return take(a),take(b),take(c)


def latent_composition_manifold(names,n=1800,latent_dim=2,T_range=(300.,340.),P_range=(1.4e6,2.6e6),seed=0):
    """PR vapor states whose compositions lie on a low-dimensional softmax manifold."""
    rng=np.random.default_rng(seed); nc=len(names); eos=PREOS(names)
    A=rng.normal(0,.42,(nc,latent_dim)); b=np.linspace(.7,-.7,nc)
    rows=[]
    while len(rows)<n:
        z=rng.uniform(-1,1,latent_dim)
        logits=b+A@z; logits-=logits.max(); x=np.exp(logits); x/=x.sum()
        T=float(rng.uniform(*T_range)); P=float(rng.uniform(*P_range))
        try:
            st=eos.state(T,P,x,'vapor')
            if st['Z']>.45: rows.append((T,P,x,st['c'],st['Z'],z))
        except Exception: pass
    T=np.array([r[0] for r in rows]); c=np.array([r[3] for r in rows])
    th=massieu_teacher_from_c(T,c,names)
    D={'eta':th['eta'],'psi':th['psi'],'q':th['q'],'c':c,'T':T,
       'P':np.array([r[1] for r in rows]),'composition':np.array([r[2] for r in rows]),
       'latent':np.array([r[5] for r in rows]),'names':list(names)}
    return eos,D
