"""Common vectorized fully implicit component/energy Darcy solver for P3."""
from __future__ import annotations
import time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import gmres, spilu, LinearOperator
from scipy.special import expit


class TPzDarcy:
    def __init__(self, ny, nx, K, thermo, pout, dx=.1, dy=.1):
        self.ny=ny;self.nx=nx;self.n=ny*nx;self.K=np.asarray(K).ravel();self.thermo=thermo
        self.dx=dx;self.dy=dy;self.vol=dx*dy;self.porosity=.22;self.thermal=.12;self.pout=pout
        grid=np.arange(self.n).reshape(ny,nx)
        self.left=np.r_[grid[:,:-1].ravel(),grid[:-1,:].ravel()]
        self.right=np.r_[grid[:,1:].ravel(),grid[1:,:].ravel()]
        self.ad=np.r_[np.full(ny*(nx-1),dy/dx),np.full((ny-1)*nx,dx/dy)]
        i=self.left;j=self.right
        self.trans=2*self.K[i]*self.K[j]/(self.K[i]+self.K[j])*self.ad
        self.inj=(ny//2)*nx;self.prod=self.inj+nx-1
        self.wells='inject';self.inlet=None

    def face(self,a,b,trans,ad):
        dp=a['P']-b['P'];left=dp>=0
        ds=a['dP'].shape[-1];n=len(dp)
        f=np.zeros((n,3));da=np.zeros((n,3,ds));db=da.copy()
        def choose(k):
            v1,v2=a[k],b[k]
            return np.where(left.reshape((-1,)+(1,)*(v1.ndim-1)),v1,v2)
        S=choose('S');dS=choose('dS')
        # Phase fraction is physical by certification, no additional clipping.
        for tag,vis in [('L',1e-4),('V',1.5e-5)]:
            kr=(1-S)**2 if tag=='L' else S*S;dkr=-2*(1-S) if tag=='L' else 2*S
            fac=trans/vis;v=fac*kr*dp
            va=fac[:,None]*kr[:,None]*a['dP'];vb=-fac[:,None]*kr[:,None]*b['dP']
            extra=(fac*dp*dkr)[:,None]*dS
            va+=extra*left[:,None];vb+=extra*(~left)[:,None]
            cc=choose('c'+tag);hh=choose('h'+tag)
            transported=np.column_stack([cc,hh]);der=np.concatenate([choose('dc'+tag),choose('dh'+tag)[:,None,:]],axis=1)
            f+=v[:,None]*transported
            da+=transported[:,:,None]*va[:,None,:]+(v*left)[:,None,None]*der
            db+=transported[:,:,None]*vb[:,None,:]+(v*(~left))[:,None,None]*der
        kth=ad*self.thermal
        f[:,2]+=kth*(a['T']-b['T']);da[:,2]+=kth[:,None]*a['dT'];db[:,2]-=kth[:,None]*b['dT']
        return f,da,db

    @staticmethod
    def take(st,ids,fixed=False):
        d={k:v[ids] for k,v in st.items()}
        if fixed:
            for k in d:
                if k.startswith('d'):d[k]=np.zeros_like(d[k])
        return d

    def residual(self,w,old,dt,jac=True):
        st=self.thermo.state(w,jac);n=self.n;i=self.left;j=self.right
        f,di,dj=self.face(self.take(st,i),self.take(st,j),self.trans,self.ad)
        div=np.zeros((n,3));np.add.at(div,i,f/self.vol);np.add.at(div,j,-f/self.vol)
        rs=np.r_[np.maximum(np.median(abs(old['C']),axis=0),1.),max(np.median(abs(old['U'])),1.)]
        acc=np.column_stack([st['C']-old['C'],st['U']-old['U']]);boundary=np.zeros(3)
        bi=[i,i,j,j];bj=[i,j,i,j];bv=[di,dj,-di,-dj]
        if self.wells=='inject':
            ff,unused,d=self.face(self.take(self.inlet,[0],True),self.take(st,[self.inj]),np.array([2*self.K[self.inj]*self.dy/self.dx]),np.array([2*self.dy/self.dx]))
            div[self.inj]-=ff[0]/self.vol;boundary-=ff[0]
            bi.append(np.array([self.inj]));bj.append(np.array([self.inj]));bv.append(-d)
        if self.wells in ('inject','withdraw'):
            pidx=self.prod if self.wells=='inject' else self.inj
            side=self.take(st,[pidx]);out=self.take(st,[pidx],True)
            out['P'][:]=self.pout
            # Zero reverse well flux, including heat. Withdrawal carries the
            # actual local enthalpy rather than a prescribed extraction heat.
            ff,d,unused=self.face(side,out,np.array([2*self.K[pidx]*self.dy/self.dx]),np.array([0.]))
            if side['P'][0]<=self.pout:ff[:]=0;d[:]=0
            div[pidx]+=ff[0]/self.vol;boundary+=ff[0]
            bi.append(np.array([pidx]));bj.append(np.array([pidx]));bv.append(d)
        r=(acc+dt/self.porosity*div)/rs
        meta=dict(state=st,balance=self.porosity*self.vol*acc.sum(0)+dt*boundary,inventory=self.porosity*self.vol*np.r_[old['C'].sum(0),old['U'].sum()],boundary=boundary,scale=rs)
        if not jac:return r.ravel(),None,meta
        B=np.concatenate(bv)*dt/(self.porosity*self.vol)/rs[None,:,None]
        ii=np.concatenate(bi);jj=np.concatenate(bj)
        diagonal=np.concatenate([st['dC'],st['dU'][:,None,:]],1)/rs[None,:,None]
        ii=np.r_[ii,np.arange(n)];jj=np.r_[jj,np.arange(n)];B=np.concatenate([B,diagonal])
        row=(3*ii[:,None,None]+np.arange(3)[None,:,None]+np.zeros((1,1,3),int)).ravel()
        col=(3*jj[:,None,None]+np.arange(3)[None,None,:]+np.zeros((1,3,1),int)).ravel()
        J=coo_matrix((B.ravel(),(row,col)),shape=(3*n,3*n)).tocsr()
        return r.ravel(),J,meta

    def solve(self,w,dt,tol=2e-7,max_iter=24):
        start=time.perf_counter();before=self.thermo.calls;tw=self.thermo.wall
        old=self.thermo.state(w,False);x=w.copy();backtracks=krylov=0
        for it in range(max_iter+1):
            r,J,meta=self.residual(x,old,dt,True);norm=max(abs(r))
            if norm<tol:break
            if it==max_iter:break
            ilu=spilu(J.tocsc(),drop_tol=2e-6,fill_factor=16.,diag_pivot_thresh=.01)
            M=LinearOperator(J.shape,matvec=ilu.solve);count=[0]
            def callback(v):count[0]+=1
            step,info=gmres(J,-r,M=M,rtol=2e-8,atol=0,restart=60,maxiter=200,callback=callback,callback_type='pr_norm')
            krylov+=count[0]
            if info or not np.isfinite(step).all():break
            step=step.reshape(-1,3);a=min(1.,.02/max(np.max(abs(step[:,0])),1e-30),.03/max(np.max(abs(step[:,1])),1e-30),.5/max(np.max(abs(step[:,2])),1e-30))
            improved=False
            for ls in range(15):
                trial=x+a*step
                try:
                    rt=self.residual(trial,old,dt,False)[0]
                    if np.isfinite(rt).all() and np.dot(rt,rt)<=(1-1e-4*a)*np.dot(r,r):
                        x=trial;improved=True;break
                except (ValueError,RuntimeError,np.linalg.LinAlgError):pass
                a*=.5;backtracks+=1
            if not improved:break
        r,J,meta=self.residual(x,old,dt,False);norm=float(max(abs(r)))
        rescue_evaluations=0
        if norm>=tol:
            from scipy.optimize import least_squares
            cache={}
            def rescue_state(v):
                if 'v' not in cache or not np.array_equal(v,cache['v']):
                    rr,jj,mm=self.residual(v.reshape(w.shape),old,dt,True)
                    cache.update(v=v.copy(),r=rr,J=jj)
                return cache
            try:
                trial=least_squares(lambda v:rescue_state(v)['r'],x.ravel(),
                    jac=lambda v:rescue_state(v)['J'],method='trf',tr_solver='lsmr',
                    x_scale='jac',max_nfev=60,ftol=1e-12,xtol=1e-12,gtol=1e-12)
                rescue_evaluations=trial.nfev
                rr,_,mm=self.residual(trial.x.reshape(w.shape),old,dt,False)
                if np.max(abs(rr))<norm:x=trial.x.reshape(w.shape);r=rr;meta=mm;norm=float(max(abs(r)))
            except (ValueError,RuntimeError,np.linalg.LinAlgError):pass
        bal=meta['balance'];inv=meta['inventory']
        rec=dict(accepted=norm<tol,iterations=it,residual=norm,backtracks=backtracks,krylov=krylov,rescue_evaluations=rescue_evaluations,
                 thermo_states=self.thermo.calls-before,thermo_wall_s=self.thermo.wall-tw,wall_s=time.perf_counter()-start,
                 mass_balance_max_rel=float(max(abs(bal[:2])/np.maximum(abs(inv[:2]),1))),energy_balance_rel=float(abs(bal[2])/max(abs(inv[2]),1)))
        return x,meta,rec
