"""Self-consistent extensive Gibbs teacher: HEOS references + Pitzer + Henry.

This is a neutral NaCl formula-unit model, not a complete electrolyte/CPA EOS.
Ion activity and water activity obey Gibbs-Duhem by construction. Salt caloric
reference is explicit and has no independent experimental validation.
"""
from pathlib import Path
import numpy as np
import torch
from numpy.polynomial import polynomial as poly
from .pr import R
MW=.018015268


def polynomial(c,x):
    y=torch.zeros_like(x)
    for a in reversed(c):y=y*x+a
    return y


def make_reference(path,activity_path):
    import CoolProp.CoolProp as CP
    import pandas as pd
    from phreeqpython import PhreeqPython
    path=Path(path)
    if path.exists():return dict(np.load(path))
    temperatures=np.linspace(290,430,29);water=CP.AbstractState('HEOS','Water');hydrogen=CP.AbstractState('HEOS','Hydrogen')
    refs=[]
    for T in temperatures:
        water.specify_phase(CP.iphase_liquid);water.update(CP.PT_INPUTS,1e5,T)
        gw=water.gibbsmolar();v=1/water.rhomolar();kap=water.isothermal_compressibility()
        hydrogen.update(CP.PT_INPUTS,1e5,T);gh=hydrogen.gibbsmolar()
        ps=CP.PropsSI('P','T',T,'Q',0,'Water');gs=CP.PropsSI('Gmolar','T',T,'Q',1,'Water')
        refs.append([gw,v,kap,gh,gs-R*T*np.log(ps/1e5),ps])
    x=(temperatures-360)/70;refs=np.array(refs)
    coefficients={key:poly.polyfit(x,refs[:,i],9) for i,key in enumerate(['gw','vw','kw','gh','gvw','ps'])}
    pp=PhreeqPython(database='pitzer.dat');activities=[];fitrows=[]
    for T in np.linspace(290,430,15):
        values=[]
        for m in np.geomspace(.005,5.5,32):
            s=pp.add_solution({'temp':T-273.15,'units':'mol/kgw','Na':m,'Cl':m,'pH':7})
            na=s.activity('Na+',units='mol');cl=s.activity('Cl-',units='mol');rho=s.density;s.forget()
            # Fit the pair excess chemical potential, then integrate it. This
            # avoids separately interpolating incompatible water/ion activity.
            values.append(np.log(na*cl/m**2));activities.append(dict(T=T,m=m,aNa=na,aCl=cl,density=rho))
        m=np.geomspace(.005,5.5,32)
        basis=np.column_stack([np.sqrt(m),m,m**1.5,m*m,m**2.5,m**3])
        coeff=np.linalg.lstsq(basis,np.array(values),rcond=None)[0];fitrows.append(coeff)
    coefficients['salt']=np.array([poly.polyfit((np.linspace(290,430,15)-360)/70,np.array(fitrows)[:,j],5) for j in range(6)])
    np.savez_compressed(path,**coefficients);pd.DataFrame(activities).to_csv(activity_path,index=False)
    return coefficients


class BrineGibbs:
    def __init__(self,coeff):
        self.c={k:torch.as_tensor(v,dtype=torch.float64) for k,v in coeff.items()}

    def refs(self,T):
        x=(T-360)/70
        return {k:polynomial(v,x) for k,v in self.c.items() if k!='salt'}

    @staticmethod
    def henry(T):
        t=T/273.15-1
        lnH=np.log(1e6)+4.6449+3.3252*t-10.901*t*t+8.0526*t**3
        ks=.2898-1.4330*t+3.9584*t*t-3.1666*t**3
        vh=(19.615-7.640*t+33.425*t*t)*1e-6
        return lnH,ks,vh

    def salt_free(self,T,m):
        x=(T-360)/70;F=2*m*(torch.log(m)-1)
        for j,coeff in enumerate(self.c['salt']):
            power=(j+1)*.5
            F=F+polynomial(coeff,x)*m**(power+1)/(power+1)
        return F

    def gibbs(self,Z,phase):
        T,P=Z[:,0],Z[:,1];n=Z[:,2:];a=self.refs(T);dp=P-1e5
        if phase=='gas':
            nh,nw=n[:,0],n[:,1];total=nh+nw
            # Low-density first virial thermal background from HEOS H2.
            # Both gas and liquid use exactly the same chemical references.
            B=1.55e-5
            gh=a['gh']+R*T*torch.log(P/1e5)+B*dp
            gw=a['gvw']+R*T*torch.log(P/1e5)
            return nh*gh+nw*gw+R*T*(nh*torch.log(nh/total)+nw*torch.log(nw/total))
        nh,nw,ns=n[:,0],n[:,1],n[:,2];W=MW*nw;m=ns/W;b=nh/W
        lnH,ks,vh=self.henry(T)
        gw=a['gw']+a['vw']*(dp-.5*a['kw']*dp*dp)
        gh=a['gh']+R*T*(lnH-np.log(1e5))+vh*(P-a['ps'])
        salt_reference=1.7e-5*dp-(-80.)*(T*torch.log(T/298.15)-T+298.15)
        return nw*gw+nh*gh+R*T*nh*(torch.log(b)-1+ks*m)+R*T*W*self.salt_free(T,m)+ns*salt_reference

    def physical(self,Z,phase,create_graph=False):
        z=Z.clone().detach().requires_grad_(True);G=self.gibbs(z,phase)
        grad=torch.autograd.grad(G.sum(),z,create_graph=True)[0];V=grad[:,1]
        U=G-z[:,0]*grad[:,0]-z[:,1]*V
        eta=torch.cat([-1/(R*z[:,0,None]),grad[:,2:]/(R*z[:,0,None])],1)
        q=torch.cat([U[:,None],z[:,2:]],1)/V[:,None]
        if phase=='gas':q=q.clone();q[:,-1]=0;eta=eta.clone();eta[:,-1]=0
        return z,G,grad,V,U,eta,q

    def state(self,T,P,b,m,phase='liquid'):
        # Independent coordinates remove extensivity's null direction.
        T=np.atleast_1d(T);P=np.broadcast_to(P,T.shape);b=np.broadcast_to(b,T.shape);m=np.broadcast_to(m,T.shape)
        n=np.column_stack([b,np.full(len(T),1/MW),m]) if phase=='liquid' else np.column_stack([np.ones(len(T)),b,np.zeros(len(T))])
        Z=torch.tensor(np.column_stack([T,P,n]),dtype=torch.float64)
        z,G,grad,V,U,eta,q=self.physical(Z,phase)
        active=[0,1,2,4] if phase=='liquid' else [0,1,3]
        keep=list(range(4)) if phase=='liquid' else [0,1,2]
        Je=torch.stack([torch.autograd.grad(eta[:,i].sum(),z,retain_graph=True)[0][:,active] for i in keep],1)
        Jq=torch.stack([torch.autograd.grad(q[:,i].sum(),z,retain_graph=True)[0][:,active] for i in keep],1)
        H=torch.linalg.solve(Je.transpose(1,2),Jq.transpose(1,2)).transpose(1,2)
        H=(H+H.transpose(1,2))/2
        if phase=='gas':
            full=torch.zeros((len(T),4,4),dtype=torch.float64);full[:,:3,:3]=H;H=full
        H=H.detach().numpy();q=q.detach().numpy();eta=eta.detach().numpy();vol=V.detach().numpy();rho=q[:,1:].sum(1)
        psi=P/(R*T);h=(q[:,0]+P)/rho
        from .bounded_study import response
        idx=list(range(4)) if phase=='liquid' else [0,1,2]
        rr=response(torch.tensor(psi),torch.tensor(q[:,idx]),torch.tensor(H[:,idx][:,:,idx]),torch.tensor(T),torch.tensor([1e-4]+[1.]*(len(idx)-1)))
        return dict(T=T,P=P,eta=eta,psi=psi,q=q,H=H,rho=rho,h=h,cp=rr['cp'].numpy(),x=q[:,1:]/rho[:,None],volume=vol)

    def coexist(self,T,P,m):
        from scipy.optimize import least_squares
        from scipy.special import expit,logit
        a=self.refs(torch.tensor([T],dtype=torch.float64));lnH,ks,vh=self.henry(torch.tensor([T],dtype=torch.float64))
        guess=float(P/np.exp(lnH+ks*m+vh*(P-a['ps'])/(R*T)));yw=float(a['ps']/P)
        def f(w):
            b=np.exp(w[0]);y=expit(w[1]);Z=torch.tensor([[T,P,b,1/MW,m],[T,P,1.,y/(1-y),0.]],dtype=torch.float64)
            l=self.physical(Z[:1],'liquid')[5].detach().numpy()[0];v=self.physical(Z[1:],'gas')[5].detach().numpy()[0]
            return l[1:3]-v[1:3]
        s=least_squares(f,[np.log(guess),logit(np.clip(yw,1e-8,.9))],xtol=1e-12,ftol=1e-12,gtol=1e-12)
        if max(abs(s.fun))>1e-7:raise ValueError('gas-brine shared chemical potential solve failed')
        b=np.exp(s.x[0]);y=expit(s.x[1]);l=self.state(T,P,b,m);v=self.state(T,P,y/(1-y),0.,'gas')
        eta=l['eta'][0].copy();v['eta'][:,3]=eta[3]
        return dict(T=T,P=P,m=m,b=b,ywater=y,eta=eta,liquid=l,gas=v,residual=float(max(abs(s.fun))))
