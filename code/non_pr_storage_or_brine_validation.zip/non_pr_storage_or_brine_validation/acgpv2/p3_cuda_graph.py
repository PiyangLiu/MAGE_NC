"""Frozen inference constants and CUDA graph replay, without changing the EOS."""
import torch


class FrozenBounded(torch.nn.Module):
    def __init__(self,net,graphs=True):
        super().__init__();self.net=net;self.dim=net.dim;self.graphs=graphs;self._cache={}
        for k in ['scale','center','atom_x','target_p','qa','taus']:
            self.register_buffer(k,getattr(net,k).detach().clone())
        with torch.no_grad():
            B,r=net.parameters_atoms()
            for k,v in dict(B=B,r=r,lw=torch.log_softmax(net.raw_lw,1),alpha=torch.softmax(net.raw_alpha,0),gauge=50*net.raw_gauge).items():self.register_buffer(k,v.detach().clone())

    def kernel(self,E,order=2):
        dx=((E-self.center)/self.scale)[:,None,:]-self.atom_x
        bd=torch.einsum('mij,bmj->bmi',self.B,dx);v=(dx*bd).sum(2).clamp_min(0);s=torch.sqrt(1+v/self.r[None,:]**2)
        Q=self.target_p+torch.einsum('bmi,mi->bm',dx,self.qa)+v/(s+1);ga=self.qa+bd/s[:,:,None]
        Hb=(self.B[None]/s[:,:,None,None]-torch.einsum('bmi,bmj->bmij',bd,bd)/(self.r[None,:]**2*s**3)[:,:,None,None]) if order==2 else None
        p=torch.zeros(len(E),device=E.device,dtype=E.dtype);q=torch.zeros((len(E),self.dim),device=E.device,dtype=E.dtype);H=torch.zeros((len(E),self.dim,self.dim),device=E.device,dtype=E.dtype) if order==2 else None
        for a,t,lw in zip(self.alpha,self.taus,self.lw):
            score=Q/t+lw;w=torch.softmax(score,1);qq=torch.einsum('bm,bmi->bi',w,ga)
            p+=a*t*torch.logsumexp(score,1);q+=a*qq
            if order==2:
                gc=ga-qq[:,None];H+=a*(torch.einsum('bm,bmij->bij',w,Hb)+torch.einsum('bm,bmi,bmj->bij',w,gc,gc)/t)
        return p+self.gauge,q/self.scale,H/(self.scale[None,:,None]*self.scale[None,None,:]) if order==2 else None

    def forward(self,E,order=2):
        if torch.is_grad_enabled():raise RuntimeError('Frozen CUDA inference is only valid under torch.no_grad(); train the underlying model separately.')
        if not self.graphs or E.device.type!='cuda':return self.kernel(E,order)
        key=(len(E),order)
        if key not in self._cache:
            static=E.detach().clone();stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                for _ in range(3):self.kernel(static,order)
            torch.cuda.current_stream().wait_stream(stream);torch.cuda.synchronize()
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):output=self.kernel(static,order)
            self._cache[key]=(static,graph,output)
        static,graph,output=self._cache[key];static.copy_(E);graph.replay()
        return output
