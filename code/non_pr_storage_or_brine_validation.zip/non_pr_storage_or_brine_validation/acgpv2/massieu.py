from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from .pr import R

@dataclass
class ErrorStats:
    mean_psi: float
    max_psi: float
    mean_q: float
    max_q: float

class MassieuACGP:
    """Convex ACGP in joint Massieu natural variables.

    Natural coordinates:
        eta0 = -1/(R T)
        etai = mu_i/(R T)
        Phi  = p/(R T)

    Teacher gradients:
        dPhi/deta0 = u   [J/m3]
        dPhi/detai = c_i [mol/m3]

    Internally the eta coordinates are affinely scaled. Convexity is preserved
    under this invertible affine coordinate transform.
    """
    def __init__(self, eta, psi, q, tau=1.0, log_weights=None,
                 center=None, scale=None, name='phase', gauge_offset=0.0):
        self.atom_eta=np.asarray(eta,float)
        self.atom_psi=np.asarray(psi,float)
        self.atom_q=np.asarray(q,float)
        if self.atom_eta.ndim!=2 or self.atom_q.shape!=self.atom_eta.shape:
            raise ValueError('eta and q must have same shape (M,D)')
        if self.atom_psi.shape!=(len(self.atom_eta),):
            raise ValueError('psi must have shape (M,)')
        self.tau=float(tau); self.name=str(name); self.gauge_offset=float(gauge_offset)
        if self.tau<=0: raise ValueError('tau must be positive')
        self.center=self.atom_eta.mean(0) if center is None else np.asarray(center,float)
        self.scale=self.atom_eta.std(0) if scale is None else np.asarray(scale,float)
        self.scale=np.where(np.abs(self.scale)<1e-14,1.0,self.scale)
        self.atom_x=(self.atom_eta-self.center)/self.scale
        self.atom_qx=self.atom_q*self.scale[None,:]
        M=len(self.atom_eta)
        # Keep the physical weighted log-sum-exp exactly invariant.  For
        # numerical conditioning we store weights with mean one and transfer
        # the removed common factor to the explicit potential gauge.
        lw=np.zeros(M) if log_weights is None else np.asarray(log_weights,float).copy()
        if lw.shape != (M,) or not np.all(np.isfinite(lw)):
            raise ValueError('log_weights must be a finite vector of length M')
        a=lw.max(); logsum=a+np.log(np.exp(lw-a).sum())
        self.log_weights=lw-(logsum-np.log(M))  # mean weight = 1
        self.gauge_offset += self.tau*(logsum-np.log(M))
        self.intercept=self.atom_psi-np.einsum('ij,ij->i',self.atom_qx,self.atom_x)

    @property
    def n_atoms(self): return len(self.atom_psi)
    @property
    def dim(self): return self.atom_eta.shape[1]
    @property
    def n_components(self): return self.dim-1

    def evaluate_eta(self, eta, return_hessian=False):
        x=(np.asarray(eta,float)-self.center)/self.scale
        L=self.atom_qx@x+self.intercept
        s=L/self.tau+self.log_weights
        m=np.max(s); e=np.exp(s-m); w=e/e.sum()
        psi=self.tau*(m+np.log(e.sum()))+self.gauge_offset
        gx=w@self.atom_qx
        q=gx/self.scale
        out={'psi':float(psi),'q':q,'u':float(q[0]),'c':q[1:],'weights':w}
        if return_hessian:
            second=(self.atom_qx.T*w)@self.atom_qx
            Hx=(second-np.outer(gx,gx))/self.tau
            H=Hx/(self.scale[:,None]*self.scale[None,:])
            H=.5*(H+H.T)
            out['H_eta']=H
        return out

    def evaluate_batch_eta(self, eta_batch):
        X=(np.asarray(eta_batch,float)-self.center)/self.scale
        L=X@self.atom_qx.T+self.intercept[None,:]
        s=L/self.tau+self.log_weights[None,:]
        m=s.max(1,keepdims=True); e=np.exp(s-m); w=e/e.sum(1,keepdims=True)
        psi=self.tau*(m[:,0]+np.log(e.sum(1)))+self.gauge_offset
        gx=w@self.atom_qx
        q=gx/self.scale[None,:]
        return psi,q

    def evaluate_batch_eta_hessian(self, eta_batch, chunk=256):
        """Evaluate potential, gradient and exact Hessian in bounded memory."""
        eta_batch=np.asarray(eta_batch,float)
        ps=[];qs=[];hs=[]
        for first in range(0,len(eta_batch),int(chunk)):
            X=(eta_batch[first:first+int(chunk)]-self.center)/self.scale
            L=X@self.atom_qx.T+self.intercept[None,:]
            score=L/self.tau+self.log_weights[None,:]
            shift=score.max(1,keepdims=True);ex=np.exp(score-shift);w=ex/ex.sum(1,keepdims=True)
            psi=self.tau*(shift[:,0]+np.log(ex.sum(1)))+self.gauge_offset
            q=w@self.atom_q
            second=np.einsum('bm,mi,mj->bij',w,self.atom_q,self.atom_q,optimize=True)
            H=(second-np.einsum('bi,bj->bij',q,q))/self.tau
            ps.append(psi);qs.append(q);hs.append(.5*(H+H.transpose(0,2,1)))
        return np.concatenate(ps),np.vstack(qs),np.concatenate(hs)

    def with_common_gauge_shift(self, shift):
        return MassieuACGP(self.atom_eta,self.atom_psi,self.atom_q,self.tau,
                           self.log_weights,self.center,self.scale,self.name,
                           self.gauge_offset+float(shift))

    with_common_potential_shift = with_common_gauge_shift

    def save(self,path):
        np.savez_compressed(path,atom_eta=self.atom_eta,atom_psi=self.atom_psi,
                            atom_q=self.atom_q,tau=np.array([self.tau]),
                            log_weights=self.log_weights,center=self.center,
                            scale=self.scale,gauge_offset=np.array([self.gauge_offset]),
                            name=np.array([self.name]))

    @classmethod
    def load(cls,path):
        d=np.load(path,allow_pickle=False)
        return cls(d['atom_eta'],d['atom_psi'],d['atom_q'],float(d['tau'][0]),
                   d['log_weights'] if 'log_weights' in d else None,
                   d['center'] if 'center' in d else None,d['scale'] if 'scale' in d else None,
                   str(d['name'][0]) if 'name' in d else 'phase',
                   float(d['gauge_offset'][0]) if 'gauge_offset' in d else 0.0)

    def evaluate_T_mu(self,T,mu,return_hessian=False):
        eta=np.r_[-1/(R*T),np.asarray(mu,float)/(R*T)]
        return self.evaluate_eta(eta,return_hessian=return_hessian)

    def isothermal_view(self,T):
        return IsothermalMassieuView(self,T)

class IsothermalMassieuView:
    """Old-ACGP-compatible view at fixed T using etai=mu_i/(RT)."""
    def __init__(self,branch,T): self.branch=branch; self.T=float(T); self.eta0=-1/(R*self.T)
    @property
    def n_atoms(self): return self.branch.n_atoms
    def evaluate(self, etai, return_hessian=False):
        out=self.branch.evaluate_eta(np.r_[self.eta0,np.asarray(etai,float)],return_hessian=return_hessian)
        ans={'psi':out['psi'],'c':out['c'],'weights':out['weights'],'u':out['u']}
        if return_hessian:
            ans['hessian']=out['H_eta'][1:,1:]
        return ans
    def pressure(self,etai): return self.evaluate(etai)['psi']*R*self.T

def farthest_point_indices(X,m):
    X=np.asarray(X,float); m=min(int(m),len(X))
    lo=X.min(0); hi=X.max(0); Z=(X-lo)/(hi-lo+1e-15)
    center=Z.mean(0); first=int(np.argmax(np.sum((Z-center)**2,1)))
    ids=[first]; d=np.sum((Z-Z[first])**2,1)
    for _ in range(1,m):
        j=int(np.argmax(d)); ids.append(j); d=np.minimum(d,np.sum((Z-Z[j])**2,1))
    return np.asarray(ids,int)

def error_components(model,data):
    ph,qh=model.evaluate_batch_eta(data['eta'])
    ep=np.abs(ph-data['psi'])/(np.abs(data['psi'])+1e-12)
    eu=np.abs(qh[:,0]-data['q'][:,0])/(np.abs(data['q'][:,0])+1e-8)
    ec=np.linalg.norm(qh[:,1:]-data['q'][:,1:],axis=1)/(np.linalg.norm(data['q'][:,1:],axis=1)+1e-12)
    return ep,eu,ec

def relative_errors(model,data):
    ep,eu,ec=error_components(model,data)
    # Backward-compatible combined derivative score that does not let the
    # energy-density magnitude numerically swamp concentration errors.
    return ep,0.25*eu+0.75*ec

def gradient_aware_greedy(data,M,tau=1.0,w_psi=.25,w_q=1.0,seed_extrema=True):
    eta=np.asarray(data['eta']); psi=np.asarray(data['psi']); q=np.asarray(data['q'])
    if seed_extrema:
        ids=[]
        for j in range(eta.shape[1]):
            ids += [int(np.argmin(eta[:,j])),int(np.argmax(eta[:,j]))]
        ids=list(dict.fromkeys(ids))
    else:
        ids=[int(np.argmax(np.sum((eta-eta.mean(0))**2,1)))]
    while len(ids)<min(M,len(eta)):
        b=MassieuACGP(eta[ids],psi[ids],q[ids],tau=tau,
                      center=eta.mean(0),scale=eta.std(0))
        ep,eu,ec=error_components(b,data)
        score=w_q*(0.75*ec+0.25*eu)+w_psi*ep; score[ids]=-np.inf
        ids.append(int(np.argmax(score)))
    return np.asarray(ids,int)

def adaptive_build(train,monitor,tau_candidates=(.25,.5,1.,2.,4.),
                   target_mean_psi=.005,target_mean_q=.03,
                   max_atoms=512,batch_add=8):
    """Validation-controlled construction. Returns best feasible or best score."""
    trials=[]
    for tau in tau_candidates:
        M=min(16,len(train['eta']))
        best=None
        while True:
            ids=gradient_aware_greedy(train,M,tau=tau)
            b=MassieuACGP(train['eta'][ids],train['psi'][ids],train['q'][ids],tau=tau,
                          center=train['eta'].mean(0),scale=train['eta'].std(0))
            ep,eu,ec=error_components(b,monitor)
            eq=0.25*eu+0.75*ec
            rec={'tau':tau,'M':len(ids),'mean_psi':float(ep.mean()),'max_psi':float(ep.max()),
                 'mean_q':float(eq.mean()),'max_q':float(eq.max()),'mean_u':float(eu.mean()),'mean_c':float(ec.mean()),'model':b,'ids':ids}
            best=rec
            if ep.mean()<=target_mean_psi and eq.mean()<=target_mean_q: break
            if M>=max_atoms or M>=len(train['eta']): break
            M=min(M+batch_add,max_atoms,len(train['eta']))
        trials.append(best)
    feasible=[r for r in trials if r['mean_psi']<=target_mean_psi and r['mean_q']<=target_mean_q]
    if feasible:
        return min(feasible,key=lambda r:(r['M'],r['mean_q'])),trials
    return min(trials,key=lambda r:r['mean_q']+r['mean_psi']),trials
