from __future__ import annotations
import numpy as np
from dataclasses import dataclass


def _logsumexp(a,axis=-1):
    m=np.max(a,axis=axis,keepdims=True)
    return np.squeeze(m,axis=axis)+np.log(np.sum(np.exp(a-m),axis=axis))


@dataclass
class MultiscaleMassieuACGP:
    """Positive-weight convex combination of fixed-temperature LSE scales.

    Every scale is a convex log-sum-exp of the same physical tangent planes.
    The scale coefficients are constant, positive and sum to one, hence the
    combined potential remains convex.  There is exactly one explicit gauge.
    """
    atom_eta: np.ndarray
    atom_psi: np.ndarray
    atom_q: np.ndarray
    taus: np.ndarray
    log_weights: np.ndarray
    scale_weights: np.ndarray
    gauge: float=0.0
    name: str='C2-MM-ACGP'

    def __post_init__(self):
        self.atom_eta=np.asarray(self.atom_eta,float);self.atom_psi=np.asarray(self.atom_psi,float)
        self.atom_q=np.asarray(self.atom_q,float);self.taus=np.asarray(self.taus,float)
        self.log_weights=np.asarray(self.log_weights,float);self.scale_weights=np.asarray(self.scale_weights,float)
        M,D=self.atom_eta.shape
        if self.atom_q.shape!=(M,D) or self.atom_psi.shape!=(M,):raise ValueError('atom arrays have inconsistent shapes')
        if self.log_weights.shape!=(len(self.taus),M):raise ValueError('log_weights must have shape (K,M)')
        if np.any(self.taus<=0) or np.any(self.scale_weights<=0):raise ValueError('taus and scale weights must be positive')
        self.scale_weights=self.scale_weights/self.scale_weights.sum()
        # Normalization prevents hidden independent constant offsets.
        self.log_weights=self.log_weights-_logsumexp(self.log_weights,axis=1)[:,None]
        self.intercepts=self.atom_psi-np.einsum('ij,ij->i',self.atom_q,self.atom_eta)

    @property
    def n_atoms(self):return len(self.atom_psi)
    @property
    def dim(self):return self.atom_eta.shape[1]

    def evaluate_eta(self,eta,return_hessian=False):
        eta=np.asarray(eta,float);planes=self.atom_q@eta+self.intercepts
        psi=0.;q=np.zeros(self.dim);H=np.zeros((self.dim,self.dim));occup=[]
        for a,t,lw in zip(self.scale_weights,self.taus,self.log_weights):
            s=planes/t+lw;m=s.max();e=np.exp(s-m);w=e/e.sum();g=w@self.atom_q
            psi+=a*t*(m+np.log(e.sum()));q+=a*g;occup.append(w)
            if return_hessian:
                second=(self.atom_q.T*w)@self.atom_q
                H+=a*(second-np.outer(g,g))/t
        out={'psi':float(psi+self.gauge),'q':q,'u':float(q[0]),'c':q[1:],'scale_occupations':occup}
        if return_hessian:out['H_eta']=.5*(H+H.T)
        return out

    def evaluate_batch_eta(self,eta,chunk=256):
        eta=np.asarray(eta,float);pp=[];qq=[]
        for j in range(0,len(eta),chunk):
            E=eta[j:j+chunk];planes=E@self.atom_q.T+self.intercepts
            p=np.zeros(len(E));q=np.zeros((len(E),self.dim))
            for a,t,lw in zip(self.scale_weights,self.taus,self.log_weights):
                s=planes/t+lw;m=s.max(1,keepdims=True);ex=np.exp(s-m);w=ex/ex.sum(1,keepdims=True)
                p+=a*t*(m[:,0]+np.log(ex.sum(1)));q+=a*(w@self.atom_q)
            pp.append(p+self.gauge);qq.append(q)
        return np.concatenate(pp),np.vstack(qq)

    def evaluate_batch_eta_hessian(self,eta,chunk=256):
        eta=np.asarray(eta,float);pp=[];qq=[];hh=[]
        for j in range(0,len(eta),chunk):
            E=eta[j:j+chunk];planes=E@self.atom_q.T+self.intercepts
            p=np.zeros(len(E));q=np.zeros((len(E),self.dim));H=np.zeros((len(E),self.dim,self.dim))
            for a,t,lw in zip(self.scale_weights,self.taus,self.log_weights):
                s=planes/t+lw;m=s.max(1,keepdims=True);ex=np.exp(s-m);w=ex/ex.sum(1,keepdims=True)
                g=w@self.atom_q
                second=np.einsum('bm,mi,mj->bij',w,self.atom_q,self.atom_q,optimize=True)
                p+=a*t*(m[:,0]+np.log(ex.sum(1)));q+=a*g
                H+=a*(second-np.einsum('bi,bj->bij',g,g))/t
            pp.append(p+self.gauge);qq.append(q);hh.append(.5*(H+H.transpose(0,2,1)))
        return np.concatenate(pp),np.vstack(qq),np.concatenate(hh)

    def save(self,path):
        np.savez_compressed(path,atom_eta=self.atom_eta,atom_psi=self.atom_psi,atom_q=self.atom_q,
                            taus=self.taus,log_weights=self.log_weights,scale_weights=self.scale_weights,
                            gauge=np.array([self.gauge]),name=np.array([self.name]))

    @classmethod
    def load(cls,path):
        d=np.load(path,allow_pickle=False)
        return cls(d['atom_eta'],d['atom_psi'],d['atom_q'],d['taus'],d['log_weights'],d['scale_weights'],
                   float(d['gauge'][0]),str(d['name'][0]))
