from __future__ import annotations
import time
import numpy as np
from scipy.optimize import least_squares
from .pr import R
from .helmholtz import massieu_teacher_from_c
from .equilibrium import massieu_phase_state, natural_map


def pr_equilibrium_massieu(eos,T,P,z):
    """Traditional PR equilibrium state plus thermodynamically consistent Massieu coordinates."""
    z=np.asarray(z,float); r=eos.flash(T,P,z)
    if not r['success']: raise RuntimeError('PR flash failed')
    if r['phase']=='liquid':
        q=eos.state(T,P,z,'liquid'); th=massieu_teacher_from_c([T],[q['c']],eos.names)
        return {'P':P,'z':z,'S':0.,'cL':q['c'],'cV':q['c'],'C':q['c'],'etai':th['eta'][0,1:],
                'phase':'liquid','eos_evals':r['eos_evals']}
    if r['phase']=='vapor':
        q=eos.state(T,P,z,'vapor'); th=massieu_teacher_from_c([T],[q['c']],eos.names)
        return {'P':P,'z':z,'S':1.,'cL':q['c'],'cV':q['c'],'C':q['c'],'etai':th['eta'][0,1:],
                'phase':'vapor','eos_evals':r['eos_evals']}
    L=eos.state(T,P,r['x'],'liquid'); V=eos.state(T,P,r['y'],'vapor')
    CL=L['c'].sum(); CV=V['c'].sum(); beta=r['beta']
    Vl=(1-beta)/CL; Vv=beta/CV; S=Vv/(Vl+Vv)
    C=(1-S)*L['c']+S*V['c']
    thL=massieu_teacher_from_c([T],[L['c']],eos.names); thV=massieu_teacher_from_c([T],[V['c']],eos.names)
    etai=.5*(thL['eta'][0,1:]+thV['eta'][0,1:])
    return {'P':P,'z':z,'S':float(S),'cL':L['c'],'cV':V['c'],'C':C,'etai':etai,
            'phase':'two-phase','eos_evals':r['eos_evals']}

def relative_permeabilities(S):
    S=np.clip(float(S),0.,1.); return (1-S)**2,S**2

def phase_flux(state,PL,PR,dist,k,etaL,etaV):
    # benchmark uses monotone left-to-right pressure; left upwind.
    dP=PL-PR; krL,krV=relative_permeabilities(state['S'])
    uL=k*krL/etaL*dP/dist; uV=k*krV/etaV*dP/dist
    return state['cL']*uL+state['cV']*uV

def solve_binary_isobaric_step(old_states,inlet,T,bL,bV,phi,dx,dt,u_total,P_target,x0=None):
    """Global etai/S solve, no local flash or TPD."""
    N=len(old_states); Cold=np.array([q['C'] for q in old_states]); zold=np.array([q['z'][0] for q in old_states])
    if x0 is None:
        E=np.array([q['etai'] for q in old_states]); S=np.array([q['S'] for q in old_states]); x0=np.r_[E[:,0],E[:,1],S]
    scale=max(phi/dt,1e-12); Pscale=2e6; counter={'residual_calls':0,'local_flash_calls':0,'TPD_calls':0,'phase_switches':0}
    Fin=u_total*((1-inlet['S'])*inlet['cL']+inlet['S']*inlet['cV'])
    def residual(w):
        counter['residual_calls']+=1; et=np.column_stack([w[:N],w[N:2*N]]); S=w[2*N:]
        st=[massieu_phase_state(T,et[j],S[j],bL,bV) for j in range(N)]
        faces=[Fin]+[u_total*((1-q['S'])*q['cL']+q['S']*q['cV']) for q in st]
        r=[]
        for j,q in enumerate(st):
            mass=phi*(q['C']-Cold[j])/dt+(faces[j+1]-faces[j])/dx
            # only one independent composition conservation + pressure + complementarity
            r.append((mass[0]-q['z'][0]*mass.sum())/(np.mean(Cold[:,0])*phi/dt+1e-9))
            r.append((q['Pthermo']-P_target)/Pscale)
            r.append(natural_map(q['S'],q['pV'],q['pL'],Pscale))
        return np.asarray(r)
    lo=np.r_[np.full(2*N,-20.),np.zeros(N)]; hi=np.r_[np.full(2*N,20.),np.ones(N)]
    sol=least_squares(residual,x0,bounds=(lo,hi),max_nfev=250,xtol=1e-9,ftol=1e-9,gtol=1e-9,x_scale='jac')
    et=np.column_stack([sol.x[:N],sol.x[N:2*N]]);S=sol.x[2*N:]
    st=[massieu_phase_state(T,et[j],S[j],bL,bV) for j in range(N)]
    return st,sol,counter

def solve_ternary_pressure_step(old_states,inlet,T,bL,bV,phi,dx,dt,k,etaL,etaV,Pin,Pout,x0=None):
    """Pressure-coupled ternary compressible Darcy step using global Massieu etai,S,P."""
    N=len(old_states); Cold=np.array([q['C'] for q in old_states]); scale=np.maximum(np.mean(phi*Cold/dt,axis=0),1e-8); Pscale=2e6
    counter={'residual_calls':0,'local_flash_calls':0,'TPD_calls':0,'phase_switches':0,'branch_evaluations':0}
    if x0 is None:
        E=np.array([q['etai'] for q in old_states]); S=np.array([q['S'] for q in old_states]); P=np.array([q['P'] for q in old_states]); x0=np.r_[E[:,0],E[:,1],E[:,2],S,P/1e6]
    def residual(w):
        counter['residual_calls']+=1; E=np.column_stack([w[:N],w[N:2*N],w[2*N:3*N]]);S=w[3*N:4*N];P=w[4*N:]*1e6
        st=[massieu_phase_state(T,E[j],S[j],bL,bV) for j in range(N)]; counter['branch_evaluations']+=2*N
        faces=[phase_flux(inlet,Pin,P[0],dx/2,k,etaL,etaV)]
        faces += [phase_flux(st[j],P[j],P[j+1],dx,k,etaL,etaV) for j in range(N-1)]
        faces += [phase_flux(st[-1],P[-1],Pout,dx/2,k,etaL,etaV)]
        r=[]
        for j,q in enumerate(st): r.extend((phi*(q['C']-Cold[j])/dt+(faces[j+1]-faces[j])/dx)/scale)
        for j,q in enumerate(st):
            r.append((P[j]-q['Pthermo'])/Pscale);r.append(natural_map(q['S'],q['pV'],q['pL'],Pscale))
        return np.asarray(r)
    lo=np.r_[np.full(3*N,-30.),np.zeros(N),np.full(N,.8*Pout/1e6)];hi=np.r_[np.full(3*N,30.),np.ones(N),np.full(N,1.1*Pin/1e6)]
    t0=time.perf_counter();sol=least_squares(residual,x0,bounds=(lo,hi),max_nfev=180,xtol=1e-8,ftol=1e-8,gtol=1e-8,x_scale='jac');elapsed=time.perf_counter()-t0
    E=np.column_stack([sol.x[:N],sol.x[N:2*N],sol.x[2*N:3*N]]);S=sol.x[3*N:4*N];P=sol.x[4*N:]*1e6
    st=[]
    for j in range(N):
        q=massieu_phase_state(T,E[j],S[j],bL,bV);q['P']=P[j];st.append(q)
    return st,sol,counter,elapsed

def _softmax_z(u):
    a=np.r_[np.asarray(u,float),0.];a-=a.max();e=np.exp(a);return e/e.sum()

def _logits_z(z):
    z=np.asarray(z,float);return np.log(z[:-1]/z[-1])

def solve_traditional_pr_pressure_step(old_states,inlet,eos,T,phi,dx,dt,k,etaL,etaV,Pin,Pout,x0=None):
    """Traditional P,z global variables with local PR flash inside every residual call."""
    N=len(old_states);nc=len(old_states[0]['z']);Cold=np.array([q['C'] for q in old_states]);scale=np.maximum(np.mean(phi*Cold/dt,axis=0),1e-8)
    counter={'residual_calls':0,'local_flash_calls':0,'PR_EOS_evaluations':0}
    if x0 is None:
        P=np.array([q['P'] for q in old_states]);U=np.array([_logits_z(q['z']) for q in old_states]);x0=np.r_[P/1e6,U.ravel()]
    lo=np.r_[np.full(N,.8*Pout/1e6),np.full((nc-1)*N,-6.)];hi=np.r_[np.full(N,1.1*Pin/1e6),np.full((nc-1)*N,6.)]
    def residual(w):
        counter['residual_calls']+=1;P=w[:N]*1e6;U=w[N:].reshape(N,nc-1);st=[]
        try:
            for j in range(N):
                q=pr_equilibrium_massieu(eos,T,P[j],_softmax_z(U[j]));st.append(q);counter['local_flash_calls']+=1;counter['PR_EOS_evaluations']+=q['eos_evals']
        except Exception:return np.ones(nc*N)*1e4
        faces=[phase_flux(inlet,Pin,P[0],dx/2,k,etaL,etaV)]
        faces += [phase_flux(st[j],P[j],P[j+1],dx,k,etaL,etaV) for j in range(N-1)]
        faces += [phase_flux(st[-1],P[-1],Pout,dx/2,k,etaL,etaV)]
        r=[]
        for j,q in enumerate(st):r.extend((phi*(q['C']-Cold[j])/dt+(faces[j+1]-faces[j])/dx)/scale)
        return np.asarray(r)
    t0=time.perf_counter();sol=least_squares(residual,x0,bounds=(lo,hi),max_nfev=100,xtol=1e-9,ftol=1e-9,gtol=1e-9,x_scale='jac');elapsed=time.perf_counter()-t0
    P=sol.x[:N]*1e6;U=sol.x[N:].reshape(N,nc-1);st=[pr_equilibrium_massieu(eos,T,P[j],_softmax_z(U[j])) for j in range(N)]
    return st,sol,counter,elapsed
