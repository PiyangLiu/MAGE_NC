"""Positive additive projected bounded-curvature convex generating potential.

Each ridge is a rank-one projected bounded atom. Contact affine terms are
global; all nonlinear coefficients and radii are positive. No property head
or input-dependent blending is present.
"""
import numpy as np
import torch
from scipy.optimize import nnls


class ProjectedBoundedNet(torch.nn.Module):
    def __init__(self,data,geometry,M,seed=38061,device='cuda'):
        super().__init__();self.dim=data['eta'].shape[1];self.structure='response'
        rng=np.random.default_rng(seed);s=geometry['scale'];X=geometry['X']
        hx=data['H']*s[None,:,None]*s[None,None,:]
        # Thermodynamic Hessian eigendirections retain energy/composition
        # coupling; random ANOVA pair projections supply competing coverage.
        directions=[];positions=[];coefficients=[]
        for j in range(M):
            i=int(rng.integers(len(X)));e,U=np.linalg.eigh(hx[i]);k=j%self.dim
            u=U[:,k]
            if j%3==2:
                u=np.zeros(self.dim);pair=rng.choice(self.dim,2,replace=False);u[pair]=rng.normal(size=2);u/=np.linalg.norm(u)
            directions.append(u);positions.append(float(X[i]@u));coefficients.append(max(float(u@hx[i]@u)*self.dim/M,1e-5))
        for k,v in dict(center=geometry['center'],scale=s,U=np.asarray(directions),b=np.asarray(positions)).items():
            self.register_buffer(k,torch.as_tensor(v,device=device,dtype=torch.float64))
        self.raw_lw=torch.nn.Parameter(torch.tensor(np.log(coefficients),device=device))
        self.raw_radius=torch.nn.Parameter(torch.zeros(M,device=device,dtype=torch.float64))
        self.affine_q=torch.nn.Parameter(torch.tensor(np.mean(data['q'],axis=0)*s,device=device))
        self.height=torch.nn.Parameter(torch.tensor(float(np.mean(data['psi'])),device=device))
        self.ids=np.arange(M)

    def forward(self,E,order=2):
        X=(E-self.center)/self.scale;v=X@self.U.T-self.b
        r=torch.exp(torch.clamp(self.raw_radius,-4,4));a=torch.exp(torch.clamp(self.raw_lw,-20,20))
        z=v/r;f=torch.sqrt(1+z*z)
        p=self.height+X@self.affine_q+((f-1)*a*r*r).sum(1)
        q=self.affine_q+((a*v/f)@self.U)
        H=torch.einsum('bm,mi,mj->bij',a/f**3,self.U,self.U) if order==2 else None
        return p,q/self.scale,(H/(self.scale[None,:,None]*self.scale[None,None,:]) if order==2 else None)

    def hvp(self,E,v):
        X=(E-self.center)/self.scale;z=(X@self.U.T-self.b)/torch.exp(torch.clamp(self.raw_radius,-4,4))
        a=torch.exp(torch.clamp(self.raw_lw,-20,20))/(1+z*z)**1.5
        uv=(v/self.scale)@self.U.T
        return ((a*uv)@self.U)/self.scale

    def save(self,path):
        np.savez_compressed(path,**{k:v.detach().cpu().numpy() for k,v in self.state_dict().items()})


def bounded_hvp(net,E,v):
    """Exact atom HVP without allocating the batch-by-atom Hessian tensor."""
    dx=((E-net.center)/net.scale)[:,None,:]-net.atom_x
    B,r=net.parameters_atoms();bd=torch.einsum('mij,bmj->bmi',B,dx)
    en=(dx*bd).sum(2).clamp_min(0);s=torch.sqrt(1+en/r[None,:]**2)
    Q=net.target_p+torch.einsum('bmi,mi->bm',dx,net.qa)+en/(s+1)
    ga=net.qa+bd/s[:,:,None];vn=v/net.scale
    bv=torch.einsum('mij,bj->bmi',B,vn)
    hv=bv/s[:,:,None]-bd*((bd*vn[:,None,:]).sum(2)/(r[None,:]**2*s**3))[:,:,None]
    out=torch.zeros_like(v)
    for a,t,lw in zip(torch.softmax(net.raw_alpha,0),net.taus,torch.log_softmax(net.raw_lw,1)):
        w=torch.softmax(Q/t+lw,1);q=torch.einsum('bm,bmi->bi',w,ga);gc=ga-q[:,None,:]
        out+=a*(torch.einsum('bm,bmi->bi',w,hv)+torch.einsum('bm,bmi,bm->bi',w,gc,(gc*vn[:,None,:]).sum(2))/t)
    return out/net.scale


class ThermalPartitionNet(torch.nn.Module):
    """Additive rank-two grand-canonical atoms with positive concentrations.

    Phi = sum_i sum_k exp(logw_ik + energy_ik*eta0 + etai).
    The ideal thermal reference is generated from the same EOS, then positive
    weights are optimized on mixture data. This model omits explicit cross-
    composition interactions, so its failure is a representation diagnostic.
    """
    def __init__(self, eos, data, g, M, device='cuda'):
        super().__init__();self.dim=data['eta'].shape[1];self.structure='response'
        nc=self.dim-1;K=max(8,M//nc);self.ids=np.arange(nc*K)
        energies=[];logs=[];Tgrid=np.linspace(445,555,41);eref=-1/(8.31446261815324*500)
        f=[];u=[];cv=[]
        for T in Tgrid:
            n=np.ones(nc)
            mu=eos.chemical_potential_tv(T,1.,n,property_flag='I')[0]
            _,un=eos.internal_energy_tv(T,1.,n,dedn=True,property_flag='I')
            up=eos.internal_energy_tv(T+.01,1.,n,dedn=True,property_flag='I')[1]
            um=eos.internal_energy_tv(T-.01,1.,n,dedn=True,property_flag='I')[1]
            f.append(-mu/(8.31446261815324*T));u.append(un);cv.append((up-um)/.02)
        f=np.array(f);u=np.array(u);cv=np.array(cv);etas=-1/(8.31446261815324*Tgrid)
        for i in range(nc):
            fref=f[20,i];uref=u[20,i];sigma=np.sqrt(8.31446261815324*500**2*cv[20,i])
            energy=np.linspace(uref-6*sigma,uref+8*sigma,K)
            A=np.exp((etas-eref)[:,None]*energy[None,:]);Z=np.exp(f[:,i]-fref)
            AA=np.concatenate([A,A*energy[None,:]/1e4,A*energy[None,:]**2/1e8])
            target=np.r_[Z,Z*u[:,i]/1e4,Z*(u[:,i]**2+8.31446261815324*Tgrid*Tgrid*cv[:,i])/1e8]
            weights=nnls(AA,target,maxiter=20000)[0]
            energies.append(energy);logs.append(np.log(np.maximum(weights,1e-25))-energy*eref+fref)
        self.register_buffer('energy',torch.as_tensor(np.asarray(energies),device=device,dtype=torch.float64))
        self.raw_lw=torch.nn.Parameter(torch.as_tensor(np.asarray(logs),device=device,dtype=torch.float64))
        for k,v in dict(center=g['center'],scale=g['scale']).items():self.register_buffer(k,torch.as_tensor(v,device=device,dtype=torch.float64))

    def forward(self,E,order=2):
        v=torch.exp(self.raw_lw[None]+E[:,0,None,None]*self.energy[None]+E[:,1:,None])
        c=v.sum(2);u=(v*self.energy).sum((1,2));p=c.sum(1);q=torch.cat([u[:,None],c],1)
        if order!=2:return p,q,None
        H=torch.zeros((len(E),self.dim,self.dim),device=E.device,dtype=E.dtype)
        H[:,0,0]=(v*self.energy**2).sum((1,2));H[:,0,1:]=(v*self.energy).sum(2);H[:,1:,0]=H[:,0,1:]
        H[:,1:,1:]=torch.diag_embed(c)
        return p,q,H

    def hvp(self,E,v):
        occ=torch.exp(self.raw_lw[None]+E[:,0,None,None]*self.energy[None]+E[:,1:,None])
        dot=v[:,0,None,None]*self.energy[None]+v[:,1:,None]
        out=torch.cat([(occ*dot*self.energy).sum((1,2))[:,None],(occ*dot).sum(2)],1)
        return out

    def save(self,path):
        np.savez_compressed(path,**{k:v.detach().cpu().numpy() for k,v in self.state_dict().items()})

    @classmethod
    def load(cls,path,device='cuda'):
        d=dict(np.load(path));net=cls.__new__(cls);torch.nn.Module.__init__(net)
        net.dim=d['energy'].shape[0]+1;net.structure='response';net.ids=np.arange(d['energy'].size)
        for k in ['energy','center','scale']:net.register_buffer(k,torch.tensor(d[k],device=device,dtype=torch.float64))
        net.raw_lw=torch.nn.Parameter(torch.tensor(d['raw_lw'],device=device,dtype=torch.float64));return net


class PairPartitionNet(ThermalPartitionNet):
    """Positive rank-three grand partition clusters, including pair interactions.

    Each cluster contains vacuum, two single occupations and a double
    occupation. Its log partition is convex and its species derivatives are
    nonnegative. No signed residual is added to a convex background.
    """
    def __init__(self,eos,data,g,M,device='cuda'):
        super().__init__(eos,data,g,M,device)
        nc=self.dim-1
        pairs=np.array([(i,j) for i in range(nc) for j in range(i,nc)])
        self.register_buffer('pairs',torch.tensor(pairs,device=device,dtype=torch.long))
        self.raw_cap=torch.nn.Parameter(torch.full((len(pairs),),np.log(10000.),device=device,dtype=torch.float64))
        self.raw_pair=torch.nn.Parameter(torch.zeros(len(pairs),device=device,dtype=torch.float64))
        self.ids=np.arange(self.energy.numel()+4*len(pairs))

    def forward(self,E,order=2):
        nc=self.dim-1
        occ=torch.exp(self.raw_lw[None]+E[:,0,None,None]*self.energy[None]+E[:,1:,None])
        Z=occ.sum(2);U=(occ*self.energy).sum(2);UU=(occ*self.energy**2).sum(2)
        cap=self.raw_cap.clamp(5,20).exp();kappa=self.raw_pair.clamp(-12,12).exp()
        ii,jj=self.pairs[:,0],self.pairs[:,1];different=(ii!=jj).to(E.dtype)
        a=Z[:,ii]/cap;b=Z[:,jj]/cap;zero=torch.zeros_like(a)
        # Each interaction lives only in (eta0, etai, etaj), including i=j.
        qa=torch.stack([U[:,ii]/cap,a,zero],2);qb=torch.stack([U[:,jj]/cap,zero,b],2)
        single=a+b*different;qs=qa+qb*different[None,:,None]
        c=kappa*a*b;qc=kappa[None,:,None]*(qa*b[:,:,None]+qb*a[:,:,None]);den=1+single+c
        qi=cap[None,:,None]*(qs+qc)/den[:,:,None]
        indices=torch.stack([torch.zeros_like(ii),ii+1,jj+1],1)
        q=torch.zeros((len(E),self.dim),device=E.device,dtype=E.dtype)
        q=q.scatter_add(1,indices.reshape(1,-1).expand(len(E),-1),qi.reshape(len(E),-1))/nc
        p=(cap*torch.log1p(single+c)).sum(1)/nc;H=None
        if order==2:
            ha=torch.zeros((len(E),len(ii),3,3),device=E.device,dtype=E.dtype);hb=torch.zeros_like(ha)
            ha[:,:,0,0]=UU[:,ii]/cap;ha[:,:,0,1]=ha[:,:,1,0]=U[:,ii]/cap;ha[:,:,1,1]=a
            hb[:,:,0,0]=UU[:,jj]/cap;hb[:,:,0,2]=hb[:,:,2,0]=U[:,jj]/cap;hb[:,:,2,2]=b
            hs=ha+hb*different[None,:,None,None]
            hc=kappa[None,:,None,None]*(ha*b[:,:,None,None]+hb*a[:,:,None,None]+qa[:,:,:,None]*qb[:,:,None,:]+qb[:,:,:,None]*qa[:,:,None,:])
            local=cap[None,:,None,None]*(hs+hc)/den[:,:,None,None]-qi[:,:,:,None]*qi[:,:,None,:]/cap[None,:,None,None]
            flat_indices=(indices[:,:,None]*self.dim+indices[:,None,:]).reshape(1,-1)
            H=torch.zeros((len(E),self.dim*self.dim),device=E.device,dtype=E.dtype)
            H=H.scatter_add(1,flat_indices.expand(len(E),-1),local.reshape(len(E),-1)).reshape(len(E),self.dim,self.dim)/nc
        return p,q,H

    def hvp(self,E,v):
        nc=self.dim-1
        occ=torch.exp(self.raw_lw[None]+E[:,0,None,None]*self.energy[None]+E[:,1:,None])
        Z=occ.sum(2);U=(occ*self.energy).sum(2);UU=(occ*self.energy**2).sum(2)
        cap=self.raw_cap.clamp(5,20).exp();kk=self.raw_pair.clamp(-12,12).exp()
        i,j=self.pairs[:,0],self.pairs[:,1];different=(i!=j).to(E.dtype)
        a=Z[:,i]/cap;b=Z[:,j]/cap;zero=torch.zeros_like(a);v0=v[:,0,None];vi=v[:,i+1];vj=v[:,j+1]
        qa=torch.stack([U[:,i]/cap,a,zero],2);qb=torch.stack([U[:,j]/cap,zero,b],2)
        ha=torch.stack([(UU[:,i]*v0+U[:,i]*vi)/cap,(U[:,i]*v0+Z[:,i]*vi)/cap,zero],2)
        hb=torch.stack([(UU[:,j]*v0+U[:,j]*vj)/cap,zero,(U[:,j]*v0+Z[:,j]*vj)/cap],2)
        vn=torch.stack([v0.expand_as(vi),vi,vj],2)
        den=1+a+b*different+kk*a*b
        qi=cap[None,:,None]*(qa+qb*different[None,:,None]+kk[None,:,None]*(qa*b[:,:,None]+qb*a[:,:,None]))/den[:,:,None]
        da=(qa*vn).sum(2);db=(qb*vn).sum(2)
        hc=kk[None,:,None]*(ha*b[:,:,None]+hb*a[:,:,None]+qa*db[:,:,None]+qb*da[:,:,None])
        hv=cap[None,:,None]*(ha+hb*different[None,:,None]+hc)/den[:,:,None]-qi*(qi*vn).sum(2)[:,:,None]/cap[None,:,None]
        indices=torch.stack([torch.zeros_like(i),i+1,j+1],1)
        out=torch.zeros_like(v)
        return out.scatter_add(1,indices.reshape(1,-1).expand(len(E),-1),hv.reshape(len(E),-1))/nc

    @classmethod
    def load(cls,path,device='cuda'):
        d=dict(np.load(path));net=cls.__new__(cls);torch.nn.Module.__init__(net)
        net.dim=d['energy'].shape[0]+1;net.structure='response';net.ids=np.arange(d['energy'].size+4*len(d['pairs']))
        for k in ['energy','center','scale','pairs']:net.register_buffer(k,torch.tensor(d[k],device=device,dtype=torch.long if k=='pairs' else torch.float64))
        for k in ['raw_lw','raw_cap','raw_pair']:setattr(net,k,torch.nn.Parameter(torch.tensor(d[k],device=device,dtype=torch.float64)))
        return net
