from __future__ import annotations

from dataclasses import dataclass
import time
import numpy as np
from scipy.optimize import least_squares
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import LinearOperator, gmres, spilu

from .massieu import MassieuACGP, farthest_point_indices
from .c2 import MultiscaleMassieuACGP
from .pr import R


ETA_SCALE=np.array([5.0e-4,1.0,1.0])


def load_compact_shared_branches(liquid_path,vapor_path,n_atoms=256):
    """Reduce legacy physical branches without adding phase-specific gauges."""
    out=[]
    for path,name in ((liquid_path,'liquid'),(vapor_path,'vapor')):
        d=np.load(path,allow_pickle=False);eta=d['eta'];ids=farthest_point_indices(eta,min(n_atoms,len(eta)))
        out.append(MassieuACGP(eta[ids],d['psi'][ids],d['q'][ids],float(d['tau'][0]),
                               log_weights=None,center=eta.mean(0),scale=eta.std(0),name=name,
                               gauge_offset=0.0))
    return tuple(out)


def load_multiscale_shared_branches(liquid_path,vapor_path,n_atoms=256,
                                    taus=(0.1,1.0,8.0),scale_weights=(0.15,0.20,0.65)):
    """Construct two convex multiscale branches with one common zero gauge."""
    out=[]
    for path,name in ((liquid_path,'liquid'),(vapor_path,'vapor')):
        d=np.load(path,allow_pickle=False);eta=d['eta'];ids=farthest_point_indices(eta,min(n_atoms,len(eta)))
        out.append(MultiscaleMassieuACGP(eta[ids],d['psi'][ids],d['q'][ids],np.asarray(taus),
                                         np.zeros((len(taus),len(ids))),np.asarray(scale_weights),0.0,name))
    return tuple(out)


def load_full_shared_branches(liquid_path,vapor_path):
    """Load every legacy atom while preserving the common weight gauge.

    The P0 liquid and vapor files were generated as a paired data set and use
    the same constant log weight.  Passing those weights through the physical
    Massieu constructor normalizes both branches in exactly the same way, so
    no phase-specific pressure shift is introduced.
    """
    out=[]
    for path,name in ((liquid_path,'liquid'),(vapor_path,'vapor')):
        d=np.load(path,allow_pickle=False)
        out.append(MassieuACGP(d['eta'],d['psi'],d['q'],float(d['tau'][0]),
                               d['log_weights'] if 'log_weights' in d else None,
                               center=d['eta'].mean(0),scale=d['eta'].std(0),
                               name=name,gauge_offset=0.0))
    if not np.isclose(out[0].gauge_offset,out[1].gauge_offset,rtol=0.,atol=1e-12):
        raise ValueError('liquid and vapor legacy branches do not share one gauge')
    return tuple(out)


def equilibrium_state(branch_l,branch_v,T,P,S=0.5,guess=None):
    """Solve the two shared-gauge phase-pressure equations at fixed T and P."""
    eta0=-1.0/(R*T);target=P/(R*T)
    lo=np.maximum(branch_l.atom_eta.min(0),branch_v.atom_eta.min(0))[1:]
    hi=np.minimum(branch_l.atom_eta.max(0),branch_v.atom_eta.max(0))[1:]
    starts=[]
    if guess is not None:starts.append(np.asarray(guess,float))
    center_l=getattr(branch_l,'center',branch_l.atom_eta.mean(0))
    center_v=getattr(branch_v,'center',branch_v.atom_eta.mean(0))
    starts.extend([.5*(lo+hi),center_l[1:],center_v[1:]])
    best=None
    for x0 in starts:
        def fun(ei):
            eta=np.r_[eta0,ei]
            return np.array([(branch_l.evaluate_eta(eta)['psi']-target)/target,
                             (branch_v.evaluate_eta(eta)['psi']-target)/target])
        sol=least_squares(fun,np.clip(x0,lo,hi),bounds=(lo,hi),max_nfev=300,
                          xtol=1e-12,ftol=1e-12,gtol=1e-12,x_scale='jac')
        score=float(np.max(np.abs(sol.fun)))
        if best is None or score<best[0]:best=(score,sol)
    if best is None or best[0]>2e-3:
        raise RuntimeError(f'compact shared-gauge VLE initialization failed: residual={best[0] if best else np.inf:g}')
    return np.r_[np.r_[eta0,best[1].x]/ETA_SCALE,S]


def equilibrium_composition(branch_l,branch_v,T,x_liquid,S=0.5,guess=None):
    """Solve coexistence at fixed temperature and liquid H2 mole fraction."""
    eta0=-1.0/(R*T)
    lo=np.minimum(branch_l.atom_eta.min(0),branch_v.atom_eta.min(0))[1:]-.35
    hi=np.maximum(branch_l.atom_eta.max(0),branch_v.atom_eta.max(0))[1:]+.35
    starts=[]
    if guess is not None:starts.append(np.asarray(guess,float))
    c=branch_l.atom_q[:,1:];xa=c[:,0]/np.maximum(c.sum(1),1e-30)
    span0=max(float(np.ptp(branch_l.atom_eta[:,0])),1e-12)
    j=int(np.argmin(20.*np.abs(branch_l.atom_eta[:,0]-eta0)/span0+
                    np.abs(xa-x_liquid)/max(float(np.ptp(xa)),1e-3)))
    starts.append(branch_l.atom_eta[j,1:])
    starts.extend([.5*(lo+hi),branch_l.atom_eta.mean(0)[1:],branch_v.atom_eta.mean(0)[1:]])
    pscale=max(float(np.median(np.abs(np.r_[branch_l.atom_psi,branch_v.atom_psi]))),1.)
    best=None
    for x0 in starts:
        def fun(ei):
            eta=np.r_[eta0,ei]
            a=branch_l.evaluate_eta(eta);b=branch_v.evaluate_eta(eta)
            xl=a['c'][0]/max(float(np.sum(a['c'])),1e-30)
            return np.array([xl-x_liquid,(a['psi']-b['psi'])/pscale])
        sol=least_squares(fun,np.clip(x0,lo,hi),bounds=(lo,hi),max_nfev=400,
                          xtol=1e-12,ftol=1e-12,gtol=1e-12,x_scale='jac')
        score=float(np.max(np.abs(sol.fun)))
        if best is None or score<best[0]:best=(score,sol)
    if best is None or best[0]>2e-3:
        raise RuntimeError(f'shared-gauge composition initialization failed: residual={best[0] if best else np.inf:g}')
    return np.r_[np.r_[eta0,best[1].x]/ETA_SCALE,S]


def natural_map_value_derivative(S,pv,pl,dpv,dpl,pscale=3.0e6,gamma=1.0,tol=1e-10):
    """Natural residual and one Clarke derivative selected by the active set."""
    F=(pv-pl)/pscale;dF=(dpv-dpl)/pscale;sigma=S+gamma*F
    if sigma<=tol:
        row=np.array([0.,0.,0.,1.]);return S,row,'gas_absent'
    if sigma>=1.-tol:
        row=np.array([0.,0.,0.,1.]);return S-1.,row,'liquid_absent'
    row=-gamma*dF.copy();row[3]=0.
    return -gamma*F,row,'two_phase'


@dataclass
class NewtonResult:
    success: bool
    x: np.ndarray
    residual_inf: float
    newton_iterations: int
    krylov_iterations: int
    line_search_backtracks: int
    active_transitions: int
    active_counts: dict
    wall_s: float
    preconditioner: str


class AnalyticMassieuDarcy2D:
    """Fully implicit two-component/energy Darcy residual and analytic Jacobian."""
    def __init__(self,ny,nx,branch_l,branch_v,initial,inlet,permeability,
                 porosity=.22,dx=.1,dy=.1,p_out=1.7e6,thermal_k=.12,
                 mu_l=1e-4,mu_v=1.5e-5):
        self.ny=int(ny);self.nx=int(nx);self.n=self.ny*self.nx
        self.L=branch_l;self.V=branch_v;self.phi=float(porosity);self.dx=float(dx);self.dy=float(dy)
        self.vol=self.dx*self.dy;self.p_out=float(p_out);self.thermal_k=float(thermal_k)
        self.mu={'L':float(mu_l),'V':float(mu_v)}
        self.K=np.asarray(permeability,float).reshape(self.ny,self.nx)
        self.inlet_w=np.asarray(inlet,float);self.inlet=self.state(self.inlet_w[None,:],False)
        self.initial_w=np.tile(np.asarray(initial,float),(self.n,1))
        self.inj=(self.ny//2)*self.nx;self.prod=(self.ny//2)*self.nx+self.nx-1
        eta=np.vstack([self.L.atom_eta,self.V.atom_eta]);margin=np.array([2e-6,.35,.35])
        self.lower=np.r_[(eta.min(0)-margin)/ETA_SCALE,0.]
        self.upper=np.r_[(eta.max(0)+margin)/ETA_SCALE,1.]

    @staticmethod
    def _kr(S,tag):
        raw=float(S);S=float(np.clip(raw,0.,1.))
        if raw<=0. or raw>=1.:d=0.
        else:d=-2*(1-S) if tag=='L' else 2*S
        return ((1-S)**2,d) if tag=='L' else (S*S,d)

    def state(self,w,derivatives=True):
        w=np.asarray(w,float).reshape(-1,4);eta=w[:,:3]*ETA_SCALE;S=w[:,3]
        if derivatives:
            psiL,qL,HL=self.L.evaluate_batch_eta_hessian(eta);psiV,qV,HV=self.V.evaluate_batch_eta_hessian(eta)
        else:
            psiL,qL=self.L.evaluate_batch_eta(eta);psiV,qV=self.V.evaluate_batch_eta(eta)
            HL=HV=np.zeros((len(w),3,3))
        T=-1.0/(R*eta[:,0]);dT=np.zeros((len(w),4));dT[:,0]=ETA_SCALE[0]/(R*eta[:,0]**2)
        def phase(psi,q,H):
            dq=np.zeros((len(w),3,4));dq[:,:,:3]=H*ETA_SCALE[None,None,:]
            p=-psi/eta[:,0]
            dpeta=-q/eta[:,0,None];dpeta[:,0]+=psi/eta[:,0]**2
            dp=np.zeros((len(w),4));dp[:,:3]=dpeta*ETA_SCALE
            c=q[:,1:];dc=dq[:,1:,:];u=q[:,0];du=dq[:,0,:];h=u+p;dh=du+dp
            return p,dp,c,dc,u,du,h,dh
        pL,dpL,cL,dcL,uL,duL,hL,dhL=phase(psiL,qL,HL)
        pV,dpV,cV,dcV,uV,duV,hV,dhV=phase(psiV,qV,HV)
        C=(1-S[:,None])*cL+S[:,None]*cV;U=(1-S)*uL+S*uV
        dC=(1-S[:,None,None])*dcL+S[:,None,None]*dcV;dC[:,:,3]=cV-cL
        dU=(1-S[:,None])*duL+S[:,None]*duV;dU[:,3]=uV-uL
        return {'w':w,'eta':eta,'S':S,'T':T,'dT':dT,'pL':pL,'pV':pV,'dpL':dpL,'dpV':dpV,
                'cL':cL,'cV':cV,'dcL':dcL,'dcV':dcV,'uL':uL,'uV':uV,'duL':duL,'duV':duV,
                'hL':hL,'hV':hV,'dhL':dhL,'dhV':dhV,'C':C,'U':U,'dC':dC,'dU':dU}

    @staticmethod
    def _side(st,i,tag,fixed=False):
        z=np.zeros(4);zc=np.zeros((2,4))
        return {'p':float(st['p'+tag][i]),'dp':z if fixed else st['dp'+tag][i],
                'c':st['c'+tag][i],'dc':zc if fixed else st['dc'+tag][i],
                'h':float(st['h'+tag][i]),'dh':z if fixed else st['dh'+tag][i],
                'S':float(st['S'][i]),'dS':z if fixed else np.array([0.,0.,0.,1.]),
                'T':float(st['T'][i]),'dT':z if fixed else st['dT'][i]}

    def _face(self,left,right,kface,area,dist):
        flux=np.zeros(3);dl=np.zeros((3,4));dr=np.zeros((3,4));trans=kface*area/dist
        for tag in ('L','V'):
            a=left[tag];b=right[tag];dp=a['p']-b['p'];up=a if dp>=0 else b;up_left=dp>=0
            mob,dmob_dS=self._kr(up['S'],tag);fac=trans/self.mu[tag]
            dvl=fac*mob*a['dp'];dvr=-fac*mob*b['dp']
            if up_left:dvl+=fac*dp*dmob_dS*a['dS']
            else:dvr+=fac*dp*dmob_dS*b['dS']
            vel=fac*mob*dp
            flux[:2]+=vel*up['c'];flux[2]+=vel*up['h']
            dl[:2]+=np.outer(up['c'],dvl);dr[:2]+=np.outer(up['c'],dvr)
            dl[2]+=up['h']*dvl;dr[2]+=up['h']*dvr
            if up_left:
                dl[:2]+=vel*up['dc'];dl[2]+=vel*up['dh']
            else:
                dr[:2]+=vel*up['dc'];dr[2]+=vel*up['dh']
        kth=area*self.thermal_k/dist;flux[2]+=kth*(left['L']['T']-right['L']['T'])
        dl[2]+=kth*left['L']['dT'];dr[2]-=kth*right['L']['dT']
        return flux,dl,dr

    def _cell_sides(self,st,i,fixed=False):
        return {tag:self._side(st,i,tag,fixed) for tag in ('L','V')}

    def _outlet(self,st,i,k,area,dist):
        flux=np.zeros(3);df=np.zeros((3,4));trans=k*area/dist
        for tag in ('L','V'):
            a=self._side(st,i,tag);dp=a['p']-self.p_out
            if dp<=0:continue
            mob,dmob=self._kr(a['S'],tag);fac=trans/self.mu[tag];vel=fac*mob*dp
            dv=fac*(mob*a['dp']+dp*dmob*a['dS'])
            flux[:2]+=vel*a['c'];flux[2]+=vel*a['h']
            df[:2]+=np.outer(a['c'],dv)+vel*a['dc'];df[2]+=a['h']*dv+vel*a['dh']
        return flux,df

    @staticmethod
    def _harmonic(a,b):return 2*a*b/(a+b+1e-300)

    def residual_jacobian(self,w,old_state,dt,assemble_jacobian=True):
        w=np.asarray(w,float).reshape(self.n,4);st=self.state(w,assemble_jacobian)
        oldC=old_state['C'];oldU=old_state['U'];cscale=np.maximum(np.median(np.abs(oldC),axis=0),1.)
        uscale=max(float(np.median(np.abs(oldU))),1.);scale=np.r_[cscale,uscale]
        div=np.zeros((self.n,3));blocks={}
        def addblock(i,j,a):
            if not assemble_jacobian:return
            key=(i,j);blocks[key]=blocks.get(key,np.zeros((4,4)))+a
        def interior(i,j,area,dist):
            y1,x1=divmod(i,self.nx);y2,x2=divmod(j,self.nx)
            k=self._harmonic(self.K[y1,x1],self.K[y2,x2])
            f,di,dj=self._face(self._cell_sides(st,i),self._cell_sides(st,j),k,area,dist)
            div[i]+=f/self.vol;div[j]-=f/self.vol
            a=np.zeros((4,4));a[:3]=di/self.vol;a[:3]/=scale[:,None]
            b=np.zeros((4,4));b[:3]=dj/self.vol;b[:3]/=scale[:,None]
            fac=dt/self.phi
            addblock(i,i,fac*a);addblock(i,j,fac*b);addblock(j,i,-fac*a);addblock(j,j,-fac*b)
        for y in range(self.ny):
            for x in range(self.nx-1):interior(y*self.nx+x,y*self.nx+x+1,self.dy,self.dx)
        for y in range(self.ny-1):
            for x in range(self.nx):interior(y*self.nx+x,(y+1)*self.nx+x,self.dx,self.dy)
        fin,dummy,dcell=self._face(self._cell_sides(self.inlet,0,True),self._cell_sides(st,self.inj),
                                   self.K.flat[self.inj],self.dy,self.dx/2)
        div[self.inj]-=fin/self.vol
        a=np.zeros((4,4));a[:3]=-dcell/self.vol;a[:3]/=scale[:,None];addblock(self.inj,self.inj,dt/self.phi*a)
        fout,dout=self._outlet(st,self.prod,self.K.flat[self.prod],self.dy,self.dx/2)
        div[self.prod]+=fout/self.vol
        a=np.zeros((4,4));a[:3]=dout/self.vol;a[:3]/=scale[:,None];addblock(self.prod,self.prod,dt/self.phi*a)
        r=np.empty((self.n,4));r[:,:2]=(st['C']-oldC+dt/self.phi*div[:,:2])/cscale
        r[:,2]=(st['U']-oldU+dt/self.phi*div[:,2])/uscale
        active=[]
        for i in range(self.n):
            val,row,label=natural_map_value_derivative(st['S'][i],st['pV'][i],st['pL'][i],st['dpV'][i],st['dpL'][i])
            r[i,3]=val;active.append(label)
            if assemble_jacobian:
                acc=np.zeros((4,4));acc[:2]=st['dC'][i]/cscale[:,None];acc[2]=st['dU'][i]/uscale;acc[3]=row
                addblock(i,i,acc)
        if not assemble_jacobian:return r.ravel(),None,{'active':active,'scale':scale},st,None
        rr=[];cc=[];vv=[]
        for (bi,bj),B in blocks.items():
            ii,jj=np.nonzero(np.abs(B)>0)
            rr.extend((4*bi+ii).tolist());cc.extend((4*bj+jj).tolist());vv.extend(B[ii,jj].tolist())
        J=coo_matrix((vv,(rr,cc)),shape=(4*self.n,4*self.n)).tocsr()
        diag=np.empty((self.n,4,4))
        for i in range(self.n):diag[i]=blocks[(i,i)]
        return r.ravel(),J,{'active':active,'scale':scale},st,diag

    @staticmethod
    def block_preconditioner(diag):
        inv=np.empty_like(diag)
        for i,B in enumerate(diag):
            try:inv[i]=np.linalg.inv(B)
            except np.linalg.LinAlgError:
                s=max(np.linalg.norm(B,np.inf),1.);inv[i]=np.linalg.pinv(B+1e-14*s*np.eye(4),rcond=1e-15)
        return LinearOperator((4*len(diag),4*len(diag)),matvec=lambda x:np.einsum('nij,nj->ni',inv,x.reshape(-1,4)).ravel())

    @classmethod
    def cpr_preconditioner(cls,J,diag,row_scale=None):
        """Multiplicative CPR: global pressure proxy, then local 4x4 blocks."""
        n=len(diag);block=cls.block_preconditioner(diag)
        weights=np.ones(2) if row_scale is None else np.asarray(row_scale,float)[:2]
        pressure=(weights[0]*J[0::4,0::4]+weights[1]*J[1::4,0::4]).tocsc()
        d=np.asarray(np.abs(pressure).sum(axis=1)).ravel()
        shift=max(float(np.median(d[d>0])) if np.any(d>0) else 1.,1.)*1e-12
        try:
            ilu=spilu(pressure+shift*coo_matrix((np.ones(n),(np.arange(n),np.arange(n))),shape=(n,n)).tocsc(),
                      drop_tol=1e-7,fill_factor=12.,permc_spec='COLAMD')
        except Exception:
            return block,'cell-block Jacobi (CPR fallback)'

        def apply(rhs):
            rhs=np.asarray(rhs,float);rp=weights[0]*rhs[0::4]+weights[1]*rhs[1::4]
            yp=ilu.solve(rp);first=np.zeros_like(rhs);first[0::4]=yp
            return first+block.matvec(rhs-J@first)
        return LinearOperator(J.shape,matvec=apply),'CPR pressure + cell-block'

    @classmethod
    def full_ilu_preconditioner(cls,J,diag):
        """Strong sparse block-coupling fallback for difficult phase events."""
        try:
            ilu=spilu(J.tocsc(),drop_tol=2e-6,fill_factor=16.,permc_spec='COLAMD',diag_pivot_thresh=.01)
            return LinearOperator(J.shape,matvec=ilu.solve),'full sparse ILU + block physics'
        except Exception:
            return cls.cpr_preconditioner(J,diag)

    def solve_step(self,old_w,dt,max_newton=12,tol=2e-7,use_preconditioner=True):
        start=time.perf_counter();old_w=np.asarray(old_w,float).reshape(self.n,4);old_state=self.state(old_w,False)
        x=old_w.copy();krylov=backtracks=transitions=0;previous_active=None
        for it in range(max_newton+1):
            r,J,meta,st,diag=self.residual_jacobian(x,old_state,dt,True);norm=float(np.max(np.abs(r)))
            merit=.5*float(np.dot(r,r))
            active=np.asarray(meta['active'])
            if previous_active is not None:transitions+=int(np.sum(active!=previous_active))
            previous_active=active.copy()
            if norm<tol:
                counts={k:int(np.sum(active==k)) for k in ('gas_absent','two_phase','liquid_absent')}
                label=('full sparse ILU + block physics' if use_preconditioner=='ilu' else ('CPR pressure + cell-block' if use_preconditioner=='cpr' else
                       ('cell-block Jacobi' if use_preconditioner else 'none'))
                )
                return NewtonResult(True,x,norm,it,krylov,backtracks,transitions,counts,time.perf_counter()-start,label)
            if it==max_newton:break
            if use_preconditioner=='ilu':M,label=self.full_ilu_preconditioner(J,diag)
            elif use_preconditioner=='cpr':M,label=self.cpr_preconditioner(J,diag,meta['scale'])
            elif use_preconditioner:M,label=self.block_preconditioner(diag),'cell-block Jacobi'
            else:M,label=None,'none'
            counter=[0]
            def callback(_):counter[0]+=1
            step,info=gmres(J,-r,M=M,rtol=2e-8,atol=0.,restart=60,maxiter=250,callback=callback,callback_type='pr_norm')
            krylov+=counter[0]
            if info!=0 or not np.all(np.isfinite(step)):break
            step=step.reshape(self.n,4);alpha=1.
            # The active-set row fixes a vanished phase exactly at S=0 or 1.
            # Krylov roundoff can nevertheless leave a tiny outward direction;
            # without this projection the fraction-to-boundary rule collapses
            # the entire Newton step to 1e-8.
            btol=1e-8
            for j in range(3):
                step[(x[:,j]<=self.lower[j]+btol)&(step[:,j]<0),j]=0.
                step[(x[:,j]>=self.upper[j]-btol)&(step[:,j]>0),j]=0.
            # Saturation is governed by the semismooth natural map.  Applying
            # a second hard bound to S prevents the active-set crossing that
            # is required when a phase appears or disappears.
            for j in range(3):
                pos=step[:,j]>0;neg=step[:,j]<0
                if np.any(pos):alpha=min(alpha,float(.995*np.min((self.upper[j]-x[pos,j])/step[pos,j])))
                if np.any(neg):alpha=min(alpha,float(.995*np.min((self.lower[j]-x[neg,j])/step[neg,j])))
            alpha=max(min(alpha,1.),1e-8);accepted=False
            for ls in range(14):
                trial=x+alpha*step;rt=self.residual_jacobian(trial,old_state,dt,False)[0]
                if .5*float(np.dot(rt,rt))<=(1-1e-4*alpha)*merit:
                    x=trial
                    x[:,:3]=np.clip(x[:,:3],self.lower[:3],self.upper[:3])
                    backtracks+=ls;accepted=True;break
                alpha*=.5
            if not accepted:break
        active=np.asarray(previous_active if previous_active is not None else [])
        counts={k:int(np.sum(active==k)) for k in ('gas_absent','two_phase','liquid_absent')}
        return NewtonResult(False,x,float(norm),min(it,max_newton),krylov,backtracks,transitions,counts,
                            time.perf_counter()-start,label if 'label' in locals() else 'none')

    def run_adaptive(self,nsteps=2,dt0=.2,max_cuts=8):
        w=self.initial_w.copy();dt=float(dt0);rows=[];cuts=0
        for step in range(1,nsteps+1):
            trial_dt=dt
            while True:
                result=self.solve_step(w,trial_dt)
                if result.success:break
                trial_dt*=.5;cuts+=1
                if cuts>max_cuts:break
            rows.append({'step':step,'accepted':result.success,'dt':trial_dt,'newton_iterations':result.newton_iterations,
                         'krylov_iterations':result.krylov_iterations,'line_search_backtracks':result.line_search_backtracks,
                         'active_transitions':result.active_transitions,'residual_inf':result.residual_inf,
                         'wall_s':result.wall_s,'cuts_cumulative':cuts,**result.active_counts})
            if not result.success:break
            w=result.x
            if result.newton_iterations<=4:dt=min(1.5*trial_dt,2*dt0)
            elif result.newton_iterations>=9:dt=.7*trial_dt
            else:dt=trial_dt
        return w,rows,cuts
