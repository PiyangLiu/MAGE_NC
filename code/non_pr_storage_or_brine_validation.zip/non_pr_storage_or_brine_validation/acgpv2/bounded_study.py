"""General-Nc bounded Massieu training and fixed-(p,x) responses.

All branches use physical contact values and a single explicit gauge parameter.
No evaluation-point dependent weights, temperature interpolation or cp head.
"""
from __future__ import annotations
import copy
import numpy as np
import torch
from scipy.spatial import cKDTree
from .bounded_curvature import BoundedCurvatureMassieuACGP
from .pr import R


def response(p, q, H, T, scale):
    nc=q.shape[1]-1; rho=q[:,1:].sum(1); x=q[:,1:]/rho[:,None]
    hx=H*scale[None,:,None]*scale[None,None,:]; qx=q*scale
    e0=1/(R*T*scale[0]); A=torch.zeros((len(T),nc+1,nc+1),device=T.device,dtype=T.dtype)
    A[:,:nc,:nc]=hx[:,1:,1:]/rho[:,None,None]
    A[:,:nc,nc]=-x*scale[None,1:]; A[:,nc,:nc]=qx[:,1:]/rho[:,None]
    rhs=torch.cat([-hx[:,1:,0]*e0[:,None]/rho[:,None],((-p-qx[:,0]*e0)/rho)[:,None]],1)
    sol=torch.linalg.solve(A,rhs.unsqueeze(-1)).squeeze(-1)
    du=(hx[:,0,0]*e0+(hx[:,0,1:]*sol[:,:nc]).sum(1))/scale[0]
    h=(q[:,0]+p*R*T)/rho; cp=du/(rho*T)-h*sol[:,nc]/T; alpha=-sol[:,nc]/T
    v=x*scale[None,1:]; invv=torch.linalg.solve(hx[:,1:,1:],v.unsqueeze(-1)).squeeze(-1)
    kappa=1/(R*T*rho*rho*(v*invv).sum(1))
    invh=torch.linalg.solve(hx[:,1:,1:],hx[:,1:,0,None]).squeeze(-1)
    cv=(hx[:,0,0]-(hx[:,0,1:]*invh).sum(1))/(rho*R*T*T*scale[0]**2)
    jt=(T*alpha-1)/(rho*cp)
    return dict(cp=cp,alpha=alpha,kappa=kappa,cv=cv,jt=jt,tangent=sol,condition=torch.linalg.cond(A))


def training_cp(p,q,H,T,scale):
    """Same fixed-(p,x) heat capacity via a single Schur-complement solve.

    Training needs cp, not a tangent condition number or the other responses.
    Avoiding three extra solves/SVDs leaves the objective unchanged.
    """
    rho=q[:,1:].sum(1);x=q[:,1:]/rho[:,None]
    hs=H*scale[None,:,None]*scale[None,None,:];v=x*scale[None,1:]
    rhs=torch.stack([v,hs[:,1:,0]],2)
    solved=torch.linalg.solve(hs[:,1:,1:],rhs)
    a=(v*solved[:,:,0]).sum(1)
    b=(v*solved[:,:,1]).sum(1)/scale[0]
    schur=(hs[:,0,0]-(hs[:,0,1:]*solved[:,:,1]).sum(1))/scale[0]**2
    h=(q[:,0]+p*R*T)/rho
    return (schur+(h-b)**2/a)/(rho*R*T*T)


def geometry(d):
    E=d['eta']; center=E.mean(0); scale=E.std(0); X=(E-center)/scale
    hx=d['H']*scale[None,:,None]*scale[None,None,:]
    eig,U=np.linalg.eigh(hx); floor=np.maximum(eig[:,-1,None]*1e-10,1e-9)
    negative=eig[:,0]<-1e-7*np.maximum(eig[:,-1],1)
    if negative.any():raise ValueError('unstable/nonconvex teacher states must not be projected into training')
    eig=np.maximum(eig,floor); hx=np.einsum('nik,nk,njk->nij',U,eig,U)
    distances,nn=cKDTree(X).query(X,k=min(33,len(X)))
    radii=[]; shrink=[]
    for i in range(len(E)):
        neigh=nn[i,1:]; dx=X[neigh]-X[i]
        ih=(U[i]/np.sqrt(eig[i]))@U[i].T
        defect=np.linalg.eigvalsh(np.einsum('ij,njk,kl->nil',ih,hx[neigh]-hx[i],ih))
        good=np.max(np.abs(defect),1)<.25; local=dx[good] if good.any() else dx[:1]
        radii.append(max(np.sqrt(np.median(np.einsum('ni,ij,nj->n',local,hx[i],local))),.2))
        diag=np.einsum('ik,nij,jk->nk',U[i],hx[neigh],U[i])
        shrink.append(np.clip(1/(1+np.median(np.abs(diag-eig[i])/eig[i],0)),.5,.98))
    vol=np.maximum(distances[:,-1],1e-6)**E.shape[1]; weights=np.clip(vol/vol.mean(),.1,10)
    return dict(center=center,scale=scale,X=X,eigen=eig,U=U,radii=np.asarray(radii),shrink=np.asarray(shrink),weights=weights)


class BoundedNet(torch.nn.Module):
    def __init__(self,d,g,ids,device='cuda',taus=(1.,4.,16.),structure='response',gauge=None):
        super().__init__();self.ids=np.asarray(ids);self.dim=d['eta'].shape[1];self.structure=structure
        values=dict(center=g['center'],scale=g['scale'],atom_x=g['X'][ids],target_p=d['psi'][ids],qa=d['q'][ids]*g['scale'],U=g['U'][ids],eigen=g['eigen'][ids],rbase=g['radii'][ids],taus=np.asarray(taus))
        if structure in ('bounded_only','quadratic'):values['rbase']=np.full(len(ids),np.median(g['radii']))
        for k,v in values.items():self.register_buffer(k,torch.tensor(v,device=device,dtype=torch.float64))
        sh=np.clip(g['shrink'][ids],1e-5,1-1e-5)
        self.raw_shrink=torch.nn.Parameter(torch.tensor(np.log(sh/(1-sh)),device=device))
        self.raw_radius=torch.nn.Parameter(torch.zeros(len(ids),device=device,dtype=torch.float64))
        self.raw_lw=torch.nn.Parameter(torch.tensor(np.tile(np.log(g['weights'][ids]),(len(taus),1)),device=device))
        self.raw_alpha=torch.nn.Parameter(torch.zeros(len(taus),device=device,dtype=torch.float64))
        self.raw_gauge=gauge if gauge is not None else torch.nn.Parameter(torch.zeros((),device=device,dtype=torch.float64))
        # No independent branch offsets or contact corrections are permitted.
        if structure in ('quadratic','bounded_only','local_radius'):self.raw_shrink.requires_grad_(False)
        if structure in ('quadratic','bounded_only'):self.raw_radius.requires_grad_(False)

    def parameters_atoms(self):
        sh=torch.ones_like(self.eigen) if self.structure in ('quadratic','bounded_only','local_radius') else torch.sigmoid(self.raw_shrink).clamp_min(1e-5)
        B=torch.einsum('mik,mk,mjk->mij',self.U,self.eigen*sh,self.U)
        r=self.rbase*torch.exp(.8*torch.tanh(self.raw_radius))
        return B,r

    def forward(self,E,order=2):
        dx=((E-self.center)/self.scale)[:,None,:]-self.atom_x
        B,r=self.parameters_atoms();bd=torch.einsum('mij,bmj->bmi',B,dx);v=(dx*bd).sum(2).clamp_min(0)
        if self.structure=='quadratic':
            Q=self.target_p+torch.einsum('bmi,mi->bm',dx,self.qa)+.5*v
            ga=self.qa+bd;Hb=B[None].expand(len(E),-1,-1,-1) if order==2 else None
        else:
            s=torch.sqrt(1+v/r[None,:]**2);Q=self.target_p+torch.einsum('bmi,mi->bm',dx,self.qa)+v/(s+1)
            ga=self.qa+bd/s[:,:,None]
            Hb=(B[None]/s[:,:,None,None]-torch.einsum('bmi,bmj->bmij',bd,bd)/(r[None,:]**2*s**3)[:,:,None,None]) if order==2 else None
        p=torch.zeros(len(E),device=E.device,dtype=E.dtype);q=torch.zeros((len(E),self.dim),device=E.device,dtype=E.dtype);H=torch.zeros((len(E),self.dim,self.dim),device=E.device,dtype=E.dtype)
        for a,t,lw in zip(torch.softmax(self.raw_alpha,0),self.taus,torch.log_softmax(self.raw_lw,1)):
            score=Q/t+lw;w=torch.softmax(score,1);qq=torch.einsum('bm,bmi->bi',w,ga)
            p=p+a*t*torch.logsumexp(score,1);q=q+a*qq
            if order==2:
                gc=ga-qq[:,None]
                H=H+a*(torch.einsum('bm,bmij->bij',w,Hb)+torch.einsum('bm,bmi,bmj->bij',w,gc,gc)/t)
        return p+50*self.raw_gauge,q/self.scale,(H/(self.scale[None,:,None]*self.scale[None,None,:]) if order==2 else None)

    def export(self,d):
        from .psd_quadratic import PSDQuadraticMassieuACGP
        B,r=self.parameters_atoms();arr=lambda t:t.detach().cpu().numpy();s=arr(self.scale)
        args=(d['eta'][self.ids],d['psi'][self.ids],d['q'][self.ids],arr(B)/(s[None,:,None]*s[None,None,:]),arr(self.taus),arr(torch.log_softmax(self.raw_lw,1)),arr(torch.softmax(self.raw_alpha,0)),float(50*self.raw_gauge.detach()),self.structure,arr(self.center),s)
        return PSDQuadraticMassieuACGP(*args) if self.structure=='quadratic' else BoundedCurvatureMassieuACGP(*args,radii=arr(r))


def tensors(d,device):return {k:torch.tensor(d[k],device=device,dtype=torch.float64) for k in ('eta','psi','q','H','T','cp')}


def loss(net,t,ids,sobolev=True):
    p,q,H=net(t['eta'][ids]);pt=t['psi'][ids];qt=t['q'][ids]
    ps=pt.abs().clamp_min(10);qs=qt.abs().mean(0).clamp_min(1)
    lp=((p-pt)/ps).square().mean();lq=((q-qt)/qs).square().mean()
    v=400*lp+80*lq
    if sobolev:
        hx=H*net.scale[None,:,None]*net.scale[None,None,:];ht=t['H'][ids]*net.scale[None,:,None]*net.scale[None,None,:]
        eigen,U=torch.linalg.eigh(ht);ih=U@torch.diag_embed(eigen.clamp_min(1e-8).rsqrt())@U.transpose(1,2)
        diff=ih@(hx-ht)@ih
        lh=torch.nn.functional.smooth_l1_loss(diff,torch.zeros_like(diff))
        cp=training_cp(p,q,H,t['T'][ids],net.scale);ce=(cp-t['cp'][ids])/t['cp'][ids].abs().clamp_min(5)
        v=v+12*lh+25*ce.square().mean()+3*torch.topk(ce.square(),max(1,len(ids)//5)).values.mean()
    return v+1e-6*net.raw_lw.square().mean()


def fit(nets,train,monitor,steps=1600,seed=31061,ties=None,tie_monitor=None):
    device=nets[0].scale.device;ts=[tensors(d,device) for d in train];ms=[tensors(d,device) for d in monitor]
    params=list({id(p):p for n in nets for p in n.parameters() if p.requires_grad}.values())
    opt=torch.optim.Adam(params,lr=.015);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,steps,eta_min=.0015)
    rng=np.random.default_rng(seed);best=None;history=[]
    ti=tensors(ties,device) if ties is not None else None;tm=tensors(tie_monitor,device) if tie_monitor is not None else None
    def interface(t,ii):
        a,qa,ha=nets[0](t['eta'][ii]);b,qb,hb=nets[1](t['eta'][ii]);pt=t['psi'][ii]
        return 3000*(((a-pt)/pt).square().mean()+((b-pt)/pt).square().mean())+30000*((a-b)/pt).square().mean()
    for step in range(1,steps+1):
        v=0
        for net,t in zip(nets,ts):
            ii=torch.tensor(rng.choice(len(t['T']),min(128,len(t['T'])),replace=False),device=device)
            v=v+loss(net,t,ii,net.structure=='response')
        if ti is not None:
            ii=torch.tensor(rng.choice(len(ti['T']),min(96,len(ti['T'])),replace=False),device=device);v=v+interface(ti,ii)
        opt.zero_grad();v.backward();torch.nn.utils.clip_grad_norm_(params,30);opt.step();sched.step()
        if step%100==0 or step==steps:
            with torch.no_grad():
                vm=sum(loss(n,t,torch.arange(min(256,len(t['T'])),device=device),n.structure=='response') for n,t in zip(nets,ms))
                if tm is not None:vm=vm+interface(tm,torch.arange(len(tm['T']),device=device))
                score=float(vm)
            history.append(dict(step=step,train_loss=float(v.detach()),monitor_loss=score))
            if np.isfinite(score) and (best is None or score<best[0]):best=(score,[copy.deepcopy(n.state_dict()) for n in nets],step)
            if step%400==0:print(dict(step=step,M=len(nets[0].ids),monitor_loss=score),flush=True)
    if best is None:raise RuntimeError('no finite monitor checkpoint')
    for n,state in zip(nets,best[1]):n.load_state_dict(state)
    return history


def evaluate(net,d,chunk=256):
    device=net.scale.device;pp=[];qq=[];hh=[];rr={}
    with torch.no_grad():
        for i in range(0,len(d['T']),chunk):
            E=torch.tensor(d['eta'][i:i+chunk],device=device,dtype=net.scale.dtype);T=torch.tensor(d['T'][i:i+chunk],device=device,dtype=net.scale.dtype)
            p,q,H=net(E);res=response(p,q,H,T,net.scale)
            pp.append(p.cpu().numpy());qq.append(q.cpu().numpy());hh.append(H.cpu().numpy())
            for k,v in res.items():rr.setdefault(k,[]).append(v.cpu().numpy())
    return np.concatenate(pp),np.concatenate(qq),np.concatenate(hh),{k:np.concatenate(v) for k,v in rr.items()}


def restore(model,device='cuda'):
    d=dict(eta=model.atom_eta,psi=model.atom_psi,q=model.atom_q);s=model.scale
    hx=model.atom_B*s[None,:,None]*s[None,None,:];eig,U=np.linalg.eigh(hx)
    # Infer exact matrices without projecting onto a different teacher basis.
    g=dict(center=model.center,scale=s,X=(d['eta']-model.center)/s,eigen=eig*2,U=U,radii=model.radii,shrink=np.full(eig.shape,.5),weights=np.ones(model.n_atoms))
    n=BoundedNet(d,g,np.arange(model.n_atoms),device,model.taus)
    with torch.no_grad():
        n.raw_lw.copy_(torch.tensor(model.log_weights,device=device));n.raw_alpha.copy_(torch.tensor(np.log(model.scale_weights),device=device));n.raw_gauge.fill_(model.gauge/50)
    return n
