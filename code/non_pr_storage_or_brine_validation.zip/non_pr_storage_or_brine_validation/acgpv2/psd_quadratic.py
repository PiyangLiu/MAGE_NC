"""Convex Massieu ACGP with positive-semidefinite quadratic atoms.

For an atom centered at ``eta_m`` the local model is

    Q_m = psi_m + q_m^T (eta-eta_m)
          + 1/2 (eta-eta_m)^T B_m (eta-eta_m),  B_m >= 0.

The log-sum-exp of these atoms has an analytic PSD Hessian consisting of
the weighted atom Hessians plus a positive covariance term.  This module is
the inference-side counterpart of the Torch trainer used in the benchmarks.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np


def _logsumexp(a, axis=-1):
    m = np.max(a, axis=axis, keepdims=True)
    return np.squeeze(m, axis=axis) + np.log(np.sum(np.exp(a - m), axis=axis))


@dataclass
class PSDQuadraticMassieuACGP:
    atom_eta: np.ndarray
    atom_psi: np.ndarray
    atom_q: np.ndarray
    atom_B: np.ndarray
    taus: np.ndarray
    log_weights: np.ndarray
    scale_weights: np.ndarray
    gauge: float = 0.0
    name: str = "PSD-quadratic-MM-ACGP"
    center: np.ndarray | None = None
    scale: np.ndarray | None = None

    def __post_init__(self):
        self.atom_eta = np.asarray(self.atom_eta, float)
        self.atom_psi = np.asarray(self.atom_psi, float)
        self.atom_q = np.asarray(self.atom_q, float)
        self.atom_B = np.asarray(self.atom_B, float)
        self.taus = np.asarray(self.taus, float)
        self.log_weights = np.asarray(self.log_weights, float)
        self.scale_weights = np.asarray(self.scale_weights, float)
        m, d = self.atom_eta.shape
        if self.atom_psi.shape != (m,) or self.atom_q.shape != (m, d):
            raise ValueError("inconsistent atom shapes")
        if self.atom_B.shape != (m, d, d):
            raise ValueError("atom_B must have shape (M,D,D)")
        if self.log_weights.shape != (len(self.taus), m):
            raise ValueError("log_weights must have shape (K,M)")
        if np.any(self.taus <= 0) or np.any(self.scale_weights <= 0):
            raise ValueError("taus and scale weights must be positive")
        self.scale_weights = self.scale_weights / self.scale_weights.sum()
        self.log_weights = self.log_weights - _logsumexp(self.log_weights, axis=1)[:, None]
        self.center = self.atom_eta.mean(0) if self.center is None else np.asarray(self.center, float)
        self.scale = self.atom_eta.std(0) if self.scale is None else np.asarray(self.scale, float)
        self.scale = np.where(np.abs(self.scale) < 1e-14, 1.0, self.scale)
        self.atom_x = (self.atom_eta - self.center) / self.scale
        self.atom_qx = self.atom_q * self.scale[None, :]
        self.atom_Bx = self.atom_B * self.scale[None, :, None] * self.scale[None, None, :]
        self.atom_Bx = 0.5 * (self.atom_Bx + self.atom_Bx.transpose(0, 2, 1))
        self.intercepts = self.atom_psi - np.einsum("ij,ij->i", self.atom_qx, self.atom_x)
        self._validate_psd()

    def _validate_psd(self):
        ev = np.linalg.eigvalsh(self.atom_Bx)
        if np.min(ev) < -1e-7 * max(1.0, np.max(np.abs(ev))):
            raise ValueError("atom_B contains a materially non-PSD matrix")

    @property
    def n_atoms(self):
        return len(self.atom_psi)

    @property
    def dim(self):
        return self.atom_eta.shape[1]

    def evaluate_eta(self, eta, return_hessian=False):
        e = np.asarray(eta, float)
        x = (e - self.center) / self.scale
        dx = x[None, :] - self.atom_x
        gx_atom = self.atom_qx + np.einsum("mij,mj->mi", self.atom_Bx, dx)
        quad = self.atom_psi + np.einsum("mi,mi->m", self.atom_qx, dx)
        quad += 0.5 * np.einsum("mi,mij,mj->m", dx, self.atom_Bx, dx)
        vals = []
        qx = np.zeros(self.dim)
        hx = np.zeros((self.dim, self.dim))
        occupations = []
        for a, tau, lw in zip(self.scale_weights, self.taus, self.log_weights):
            score = quad / tau + lw
            shift = np.max(score)
            ex = np.exp(score - shift)
            w = ex / ex.sum()
            g = w @ gx_atom
            second = np.einsum("m,mij->ij", w, self.atom_Bx)
            cov = (gx_atom.T * w) @ gx_atom - np.outer(g, g)
            vals.append(a * tau * (shift + np.log(ex.sum())))
            qx += a * g
            hx += a * (second + cov / tau)
            occupations.append(w)
        out = {"psi": float(np.sum(vals) + self.gauge), "q": qx / self.scale,
               "u": float(qx[0] / self.scale[0]), "c": qx[1:] / self.scale[1:],
               "scale_occupations": occupations}
        if return_hessian:
            out["H_eta"] = 0.5 * (hx / (self.scale[:, None] * self.scale[None, :]) +
                                    (hx / (self.scale[:, None] * self.scale[None, :])).T)
        return out

    def evaluate_batch_eta_hessian(self, eta, chunk=256):
        eta = np.asarray(eta, float)
        pp, qq, hh = [], [], []
        for first in range(0, len(eta), int(chunk)):
            E = eta[first:first + int(chunk)]
            X = (E - self.center) / self.scale
            dx = X[:, None, :] - self.atom_x[None, :, :]
            gx_atom = self.atom_qx[None, :, :] + np.einsum("mij,bmj->bmi", self.atom_Bx, dx)
            quad = self.atom_psi[None, :] + np.einsum("bmi,mi->bm", dx, self.atom_qx)
            quad += 0.5 * np.einsum("bmi,mij,bmj->bm", dx, self.atom_Bx, dx)
            p = np.zeros(len(E)); qx = np.zeros((len(E), self.dim)); hx = np.zeros((len(E), self.dim, self.dim))
            for a, tau, lw in zip(self.scale_weights, self.taus, self.log_weights):
                score = quad / tau + lw[None, :]
                shift = score.max(1, keepdims=True); ex = np.exp(score - shift); w = ex / ex.sum(1, keepdims=True)
                g = np.einsum("bm,bmi->bi", w, gx_atom)
                second = np.einsum("bm,mij->bij", w, self.atom_Bx)
                cov = np.einsum("bm,bmi,bmj->bij", w, gx_atom, gx_atom) - np.einsum("bi,bj->bij", g, g)
                p += a * tau * (shift[:, 0] + np.log(ex.sum(1)))
                qx += a * g; hx += a * (second + cov / tau)
            pp.append(p + self.gauge); qq.append(qx / self.scale[None, :])
            hs = hx / (self.scale[None, :, None] * self.scale[None, None, :])
            hh.append(0.5 * (hs + hs.transpose(0, 2, 1)))
        return np.concatenate(pp), np.vstack(qq), np.concatenate(hh)

    def save(self, path):
        np.savez_compressed(path, atom_eta=self.atom_eta, atom_psi=self.atom_psi,
                            atom_q=self.atom_q, atom_B=self.atom_B, taus=self.taus,
                            log_weights=self.log_weights, scale_weights=self.scale_weights,
                            gauge=np.array([self.gauge]), name=np.array([self.name]),
                            center=self.center, scale=self.scale)

    @classmethod
    def load(cls, path):
        d = np.load(path, allow_pickle=False)
        return cls(d["atom_eta"], d["atom_psi"], d["atom_q"], d["atom_B"], d["taus"],
                   d["log_weights"], d["scale_weights"], float(d["gauge"][0]),
                   str(d["name"][0]), d.get("center"), d.get("scale"))
