"""Teacher-assisted fidelity verification, explicitly not a learned theorem."""
import numpy as np


def verified_partition(candidate,reference,statistical_accept):
    rho,h,beta=[np.asarray(candidate[k]) for k in ['rho','h','beta']]
    rt,ht,bt=[np.asarray(reference[k]) for k in ['rho','h','beta']]
    phase=lambda b:np.where(b<.001,0,np.where(b>1-.001,2,1))
    safe=np.asarray(statistical_accept)&np.isfinite(rho)&(abs(rho-rt)/rt<=.05)&(abs(h-ht)/np.maximum(abs(ht),100)<=.05)&(abs(beta-bt)<=.01)&(phase(beta)==phase(bt))
    outputs={k:np.where(safe,candidate[k],reference[k]) for k in ['rho','h','beta']}
    return outputs,safe
