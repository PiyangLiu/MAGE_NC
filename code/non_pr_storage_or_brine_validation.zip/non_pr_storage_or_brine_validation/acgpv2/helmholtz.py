from __future__ import annotations
import math
import numpy as np
import torch
from .pr import LIB, R

torch.set_default_dtype(torch.float64)

def _component_tensors(names, device='cpu', dtype=torch.float64):
    Tc=torch.tensor([LIB[n]['Tc'] for n in names],dtype=dtype,device=device)
    Pc=torch.tensor([LIB[n]['Pc'] for n in names],dtype=dtype,device=device)
    om=torch.tensor([LIB[n]['omega'] for n in names],dtype=dtype,device=device)
    return Tc,Pc,om

def pr_helmholtz_density_torch(T,c,names,kij=None):
    """Thermodynamically consistent PR Helmholtz free-energy density.

    Ideal reference: f_id = RT sum_i c_i [ln(c_i/c_ref)-1], c_ref=1 mol/m3.
    The arbitrary standard-state convention is internally consistent across T.
    """
    if T.ndim==0: T=T[None]
    if c.ndim==1: c=c[None,:]
    Tc,Pc,om=_component_tensors(names,c.device,c.dtype)
    kap=0.37464+1.54226*om-0.26992*om**2
    alpha=(1+kap*(1-torch.sqrt(T[:,None]/Tc[None,:])))**2
    ai=.45724*R**2*Tc[None,:]**2/Pc[None,:]*alpha
    bi=.07780*R*Tc/Pc
    if kij is None:
        km=torch.zeros((len(names),len(names)),dtype=c.dtype,device=c.device)
    else:
        km=torch.as_tensor(kij,dtype=c.dtype,device=c.device)
    aij=torch.sqrt(ai[:,:,None]*ai[:,None,:])*(1-km[None,:,:])
    ct=c.sum(dim=1)
    x=c/ct[:,None]
    am=torch.einsum('bi,bij,bj->b',x,aij,x)
    bm=torch.einsum('bi,i->b',x,bi)
    v=1/ct
    if torch.any(v<=bm):
        raise ValueError('State violates v>b in PR Helmholtz expression')
    fid=R*T*torch.sum(c*(torch.log(c)-1.0),dim=1)
    s=math.sqrt(2.0)
    ar=-R*T*torch.log(1-bm/v) - am/(2*s*bm)*torch.log((v+(1+s)*bm)/(v+(1-s)*bm))
    return fid+ct*ar

def massieu_teacher_from_c(T,c,names,kij=None):
    """Return a self-consistent Massieu teacher from the same PR Helmholtz potential.

    eta0 = -1/(R T)
    etai = mu_i/(R T)
    Phi = p/(R T)
    grad_eta Phi = [u, c_1, ..., c_N]
    """
    Tarr=torch.as_tensor(np.asarray(T,float).reshape(-1),dtype=torch.float64).clone().requires_grad_(True)
    carr=torch.as_tensor(np.asarray(c,float),dtype=torch.float64)
    if carr.ndim==1: carr=carr[None,:]
    carr=carr.clone().requires_grad_(True)
    f=pr_helmholtz_density_torch(Tarr,carr,names,kij=kij)
    mu=torch.autograd.grad(f.sum(),carr,create_graph=True,retain_graph=True)[0]
    fT=torch.autograd.grad(f.sum(),Tarr,create_graph=False,retain_graph=True)[0]
    p=(mu*carr).sum(dim=1)-f
    u=f-Tarr*fT
    eta0=-1/(R*Tarr)
    etai=mu/(R*Tarr[:,None])
    Phi=p/(R*Tarr)
    eta=torch.cat([eta0[:,None],etai],dim=1)
    q=torch.cat([u[:,None],carr],dim=1)
    return {
        'eta':eta.detach().cpu().numpy(),
        'psi':Phi.detach().cpu().numpy(),
        'q':q.detach().cpu().numpy(),
        'mu':mu.detach().cpu().numpy(),
        'u':u.detach().cpu().numpy(),
        'p':p.detach().cpu().numpy(),
        'c':carr.detach().cpu().numpy(),
    }
