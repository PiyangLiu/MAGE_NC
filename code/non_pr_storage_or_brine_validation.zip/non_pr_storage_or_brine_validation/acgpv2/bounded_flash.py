"""Analytic batched global-mu natural-map equilibrium for arbitrary Nc.

The same residual applies at S=0, 0<S<1 and S=1. Initial guesses use only
stored training supports; no teacher flash occurs in an MM solve.
"""
from __future__ import annotations
import numpy as np
import torch
from scipy.spatial import cKDTree
from .pr import R


class BoundedFlash:
    def __init__(self,L,V,atlas):
        self.L=L;self.V=V;self.device=L.scale.device;self.dtype=L.scale.dtype
        self.nc=L.dim-1;self.es=L.scale[1:].detach().cpu().numpy()
        E=np.asarray(atlas['eta']);T=np.asarray(atlas['T']);P=np.asarray(atlas['P'])
        self.Tscale=max(np.ptp(T),1);self.Pscale=max(np.ptp(np.log(P)),1)
        self.atlas=atlas;self.tree=cKDTree(np.column_stack([T/self.Tscale,np.log(P)/self.Pscale]))
        self.e_low=np.minimum(L.center.detach().cpu().numpy()[1:]-5*self.es,V.center.detach().cpu().numpy()[1:]-5*V.scale.detach().cpu().numpy()[1:])
        self.e_high=np.maximum(L.center.detach().cpu().numpy()[1:]+5*self.es,V.center.detach().cpu().numpy()[1:]+5*V.scale.detach().cpu().numpy()[1:])

    def initial(self,T,P,z):
        _,ii=self.tree.query(np.column_stack([T/self.Tscale,np.log(P)/self.Pscale]))
        x=self.atlas['x'][ii];y=self.atlas['y'][ii]
        delta=y-x;beta=np.sum((z-x)*delta,1)/np.maximum(np.sum(delta*delta,1),1e-20);beta=np.clip(beta,0,1)
        rl=self.atlas['rhoL'][ii];rv=self.atlas['rhoV'][ii]
        S=(beta/rv)/((1-beta)/rl+beta/rv)
        E=self.atlas['eta'][ii,1:].copy()
        # Ideal component correction is only an initialization, never a
        # thermodynamic formula used in the production residual.
        active=np.where((beta<.5)[:,None],x,y)
        pure=(beta<1e-8)|(beta>1-1e-8)
        E[pure]+=np.log(np.maximum(z[pure],1e-10)/np.maximum(active[pure],1e-10))
        return np.column_stack([E/self.es,S])

    def residual(self,w,T,P,z,jac=True):
        n=len(T);nc=self.nc;eta=torch.cat([(-1/(R*T))[:,None],w[:,:nc]*self.L.scale[None,1:]],1)
        pL,qL,HL=self.L(eta,order=2 if jac else 1);pV,qV,HV=self.V(eta,order=2 if jac else 1);target=P/(R*T);S=w[:,nc]
        C=(1-S[:,None])*qL[:,1:]+S[:,None]*qV[:,1:];rho=C.sum(1);zz=C/rho[:,None]
        dp=(pV-pL)/target;sig=S+dp
        phase=S-torch.clamp(sig,0,1)
        pressure=((1-S)*pL+S*pV-target)/target
        f=torch.cat([pressure[:,None],zz[:,:nc-1]-z[:,:nc-1],phase[:,None]],1)
        fields=dict(eta=eta,S=S,pL=pL,pV=pV,qL=qL,qV=qV,HL=HL,HV=HV,C=C,rho=rho)
        if not jac:return f,None,fields
        es=self.L.scale[1:];J=torch.zeros((n,nc+1,nc+1),device=w.device,dtype=w.dtype)
        J[:,0,:nc]=C*es/target[:,None];J[:,0,nc]=dp
        dC=((1-S[:,None,None])*HL[:,1:,1:]+S[:,None,None]*HV[:,1:,1:])*es[None,None,:]
        dcS=qV[:,1:]-qL[:,1:];drho=dC.sum(1);drhoS=dcS.sum(1)
        J[:,1:nc,:nc]=(dC[:,:nc-1,:]-zz[:,:nc-1,None]*drho[:,None,:])/rho[:,None,None]
        J[:,1:nc,nc]=(dcS[:,:nc-1]-zz[:,:nc-1]*drhoS[:,None])/rho[:,None]
        interior=(sig>0)&(sig<1)
        J[:,nc,:nc]=torch.where(interior[:,None],-(qV[:,1:]-qL[:,1:])*es/target[:,None],torch.zeros_like(C))
        J[:,nc,nc]=(~interior).to(w.dtype)
        return f,J,fields

    def solve(self,T,P,z,initial=None,max_iter=60,tol=1e-8,chunk=128,retry=True):
        T=np.atleast_1d(T).astype(float);P=np.atleast_1d(P).astype(float);z=np.asarray(z,float).reshape(len(T),self.nc)
        start=self.initial(T,P,z) if initial is None else np.asarray(initial)
        accum={};es=self.es
        with torch.no_grad():
            for first in range(0,len(T),chunk):
                sl=slice(first,first+chunk);tt=torch.tensor(T[sl],device=self.device,dtype=self.dtype);pp=torch.tensor(P[sl],device=self.device,dtype=self.dtype);zz=torch.tensor(z[sl],device=self.device,dtype=self.dtype);w=torch.tensor(start[sl],device=self.device,dtype=self.dtype)
                iterations=torch.zeros(len(tt),device=self.device,dtype=torch.int64);backs=torch.zeros_like(iterations)
                for it in range(max_iter):
                    f,J,st=self.residual(w,tt,pp,zz);norm=f.abs().amax(1);done=norm<tol
                    if done.all():break
                    sol,info=torch.linalg.solve_ex(J,-f.unsqueeze(-1));dw=sol.squeeze(-1)
                    invalid=(info!=0)|(~torch.isfinite(dw).all(1));dw[invalid]=0
                    dw[done]=0;iterations[~done]+=1
                    bound=(dw[:,:self.nc]*self.L.scale[None,1:]).abs().amax(1)
                    a=torch.minimum(torch.ones_like(bound),.5/bound.clamp_min(1e-20));accepted=done.clone();merit=f.square().sum(1)
                    for ls in range(14):
                        trial=w+a[:,None]*dw;ft=self.residual(trial,tt,pp,zz,False)[0]
                        ok=(ft.square().sum(1)<=(1-1e-4*a)*merit)&torch.isfinite(ft).all(1)
                        new=ok&(~accepted);w[new]=trial[new];backs[new]+=ls;accepted|=ok
                        a[~accepted]*=.5
                        if accepted.all():break
                    if not accepted[~done].any():break
                f,J,st=self.residual(w,tt,pp,zz);S=st['S'];qL=st['qL'];qV=st['qV'];rho=st['rho'];rl=qL[:,1:].sum(1);rv=qV[:,1:].sum(1)
                U=(1-S)*qL[:,0]+S*qV[:,0];beta=S*rv/rho
                physical=(S>=-1e-7)&(S<=1+1e-7)&(st['C']>0).all(1)&((qL[:,1:]>0).all(1)|(S>1-1e-7))&((qV[:,1:]>0).all(1)|(S<1e-7))
                values=dict(w=w,S=S,beta=beta,x=qL[:,1:]/rl[:,None],y=qV[:,1:]/rv[:,None],rho=rho,h=(U+pp)/rho,residual=f.abs().amax(1),success=(f.abs().amax(1)<tol)&physical,iterations=iterations,backtracks=backs,condition=torch.linalg.cond(J),pL=st['pL']*R*tt,pV=st['pV']*R*tt)
                for k,v in values.items():accum.setdefault(k,[]).append(v.cpu().numpy())
        result={k:np.concatenate(v) for k,v in accum.items()}
        result['restarts']=np.zeros(len(T),int)
        if retry and (~result['success']).any():
            # A kink can trap a merit line search. Restart the SAME KKT
            # equations from both saturation endpoints, without a phase flash.
            for saturation in (0.,1.):
                bad=np.where(~result['success'])[0]
                if not len(bad):break
                guess=start[bad].copy();guess[:,-1]=saturation
                trial=self.solve(T[bad],P[bad],z[bad],guess,max_iter,tol,chunk,retry=False)
                improve=trial['success']|(trial['residual']<result['residual'][bad]);take=bad[improve]
                oldit=result['iterations'][take].copy();oldback=result['backtracks'][take].copy()
                for key in result:
                    if key!='restarts':result[key][take]=trial[key][improve]
                result['iterations'][take]+=oldit;result['backtracks'][take]+=oldback;result['restarts'][bad]+=1
        return result
