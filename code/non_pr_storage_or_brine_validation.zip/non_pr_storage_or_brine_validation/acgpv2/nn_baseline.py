from __future__ import annotations
import copy, time
import numpy as np
import torch
from torch import nn

torch.set_default_dtype(torch.float64)

class ScalarPotentialNet(nn.Module):
    """Thermodynamic-potential NN baseline (NNEoS-style, not exact NNEoS reproduction).

    It predicts one scalar potential. Thermodynamic derivatives are obtained by
    automatic differentiation, following the same organizing principle as
    potential-based neural EOS methods such as NNEoS.
    """
    def __init__(self,dim,width=128,depth=4):
        super().__init__()
        layers=[]; d=dim
        for _ in range(depth):
            layers += [nn.Linear(d,width), nn.SiLU()]; d=width
        layers += [nn.Linear(d,1)]
        self.net=nn.Sequential(*layers)
        # normalization stored as buffers
        self.register_buffer('x_mean',torch.zeros(dim))
        self.register_buffer('x_scale',torch.ones(dim))
        self.register_buffer('y_mean',torch.zeros(()))
        self.register_buffer('y_scale',torch.ones(()))
        self.register_buffer('q_scale',torch.ones(dim))

    def set_normalization(self,eta,psi,q):
        self.x_mean.copy_(torch.as_tensor(eta.mean(0)))
        self.x_scale.copy_(torch.as_tensor(eta.std(0)+1e-12))
        self.y_mean.copy_(torch.as_tensor(float(np.mean(psi))))
        self.y_scale.copy_(torch.as_tensor(float(np.std(psi)+1e-12)))
        self.q_scale.copy_(torch.as_tensor(np.std(q,axis=0)+1e-8))

    def potential_normalized(self,xn):
        return self.net(xn).squeeze(-1)

    def potential(self,eta):
        xn=(eta-self.x_mean)/self.x_scale
        return self.y_mean+self.y_scale*self.potential_normalized(xn)

    def potential_and_gradient(self,eta,create_graph=False):
        if not eta.requires_grad:
            eta=eta.clone().detach().requires_grad_(True)
        y=self.potential(eta)
        g=torch.autograd.grad(y.sum(),eta,create_graph=create_graph,retain_graph=create_graph)[0]
        return y,g

class DirectPropertyNet(nn.Module):
    def __init__(self,dim,width=128,depth=4):
        super().__init__(); layers=[]; d=dim
        for _ in range(depth): layers += [nn.Linear(d,width),nn.SiLU()]; d=width
        layers += [nn.Linear(d,1+dim)]; self.net=nn.Sequential(*layers)
        self.register_buffer('x_mean',torch.zeros(dim)); self.register_buffer('x_scale',torch.ones(dim))
        self.register_buffer('y_mean',torch.zeros(1+dim)); self.register_buffer('y_scale',torch.ones(1+dim))
    def set_normalization(self,eta,psi,q):
        Y=np.c_[psi,q]; self.x_mean.copy_(torch.as_tensor(eta.mean(0))); self.x_scale.copy_(torch.as_tensor(eta.std(0)+1e-12))
        self.y_mean.copy_(torch.as_tensor(Y.mean(0))); self.y_scale.copy_(torch.as_tensor(Y.std(0)+1e-12))
    def forward(self,eta):
        x=(eta-self.x_mean)/self.x_scale; z=self.net(x); return self.y_mean+self.y_scale*z

def _to_torch(D,device='cpu'):
    return (torch.as_tensor(D['eta'],dtype=torch.float64,device=device),
            torch.as_tensor(D['psi'],dtype=torch.float64,device=device),
            torch.as_tensor(D['q'],dtype=torch.float64,device=device))

def train_potential_nn(train,val,width=128,depth=4,epochs=900,batch_size=256,lr=2e-3,
                       w_psi=1.0,w_q=2.0,patience=100,device='cpu',seed=0):
    torch.manual_seed(seed); model=ScalarPotentialNet(train['eta'].shape[1],width,depth).to(device)
    model.set_normalization(train['eta'],train['psi'],train['q'])
    X,Y,Q=_to_torch(train,device); Xv,Yv,Qv=_to_torch(val,device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-7)
    sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=max(epochs,1),eta_min=lr*0.03)
    rng=np.random.default_rng(seed); best=None; best_state=None; bad=0; hist=[]
    # normalized loss scales
    yscale=float(np.std(train['psi'])+1e-12); qscale=torch.as_tensor(np.std(train['q'],axis=0)+1e-8,device=device)
    for ep in range(1,epochs+1):
        ids=rng.permutation(len(X)); model.train(); losses=[]
        for s in range(0,len(ids),batch_size):
            j=torch.as_tensor(ids[s:s+batch_size],device=device)
            xb=X[j].clone().detach().requires_grad_(True); yb=Y[j]; qb=Q[j]
            yp,gp=model.potential_and_gradient(xb,create_graph=True)
            lp=torch.mean(((yp-yb)/yscale)**2)
            lq=torch.mean(((gp-qb)/qscale)**2)
            loss=w_psi*lp+w_q*lq
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),10.0); opt.step(); losses.append(float(loss.detach()))
        sched.step()
        # validation with graph only for first derivative
        model.eval(); xv=Xv.clone().detach().requires_grad_(True)
        pv,gv=model.potential_and_gradient(xv,create_graph=False)
        vpsi=float(torch.mean(torch.abs(pv-Yv)/(torch.abs(Yv)+1e-12)))
        vq=float(torch.mean(torch.linalg.norm(gv-Qv,dim=1)/(torch.linalg.norm(Qv,dim=1)+1e-12)))
        score=vpsi+vq
        hist.append({'epoch':ep,'train_loss':float(np.mean(losses)),'val_psi_rel':vpsi,'val_q_rel':vq,'score':score})
        if best is None or score<best-1e-6:
            best=score; best_state=copy.deepcopy(model.state_dict()); bad=0
        else: bad+=1
        if bad>=patience and ep>200: break
    model.load_state_dict(best_state)
    return model,hist

def train_direct_nn(train,val,width=128,depth=4,epochs=700,batch_size=256,lr=2e-3,patience=100,device='cpu',seed=1):
    torch.manual_seed(seed); model=DirectPropertyNet(train['eta'].shape[1],width,depth).to(device)
    model.set_normalization(train['eta'],train['psi'],train['q'])
    X,Y,Q=_to_torch(train,device); Xv,Yv,Qv=_to_torch(val,device); Yall=torch.cat([Y[:,None],Q],1); Yvall=torch.cat([Yv[:,None],Qv],1)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-7); sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=max(epochs,1),eta_min=lr*.03)
    rng=np.random.default_rng(seed); best=None;state=None;bad=0;hist=[]
    scale=torch.as_tensor(np.std(np.c_[train['psi'],train['q']],axis=0)+1e-8,device=device)
    for ep in range(1,epochs+1):
        ids=rng.permutation(len(X)); losses=[]; model.train()
        for s in range(0,len(ids),batch_size):
            j=torch.as_tensor(ids[s:s+batch_size],device=device); pred=model(X[j]); loss=torch.mean(((pred-Yall[j])/scale)**2)
            opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10.0);opt.step();losses.append(float(loss.detach()))
        sched.step(); model.eval()
        with torch.no_grad(): pred=model(Xv); p=pred[:,0]; q=pred[:,1:]
        vp=float(torch.mean(torch.abs(p-Yv)/(torch.abs(Yv)+1e-12))); vq=float(torch.mean(torch.linalg.norm(q-Qv,dim=1)/(torch.linalg.norm(Qv,dim=1)+1e-12)));score=vp+vq
        hist.append({'epoch':ep,'train_loss':float(np.mean(losses)),'val_psi_rel':vp,'val_q_rel':vq,'score':score})
        if best is None or score<best-1e-6:best=score;state=copy.deepcopy(model.state_dict());bad=0
        else:bad+=1
        if bad>=patience and ep>200:break
    model.load_state_dict(state);return model,hist

def evaluate_potential_nn(model,D,device='cpu'):
    X,Y,Q=_to_torch(D,device); X=X.clone().detach().requires_grad_(True); model.eval(); p,q=model.potential_and_gradient(X,create_graph=False)
    ep=torch.abs(p-Y)/(torch.abs(Y)+1e-12); eq=torch.linalg.norm(q-Q,dim=1)/(torch.linalg.norm(Q,dim=1)+1e-12)
    return p.detach().cpu().numpy(),q.detach().cpu().numpy(),ep.detach().cpu().numpy(),eq.detach().cpu().numpy()

def evaluate_direct_nn(model,D,device='cpu'):
    X,Y,Q=_to_torch(D,device); model.eval()
    with torch.no_grad(): z=model(X);p=z[:,0];q=z[:,1:]
    ep=torch.abs(p-Y)/(torch.abs(Y)+1e-12);eq=torch.linalg.norm(q-Q,dim=1)/(torch.linalg.norm(Q,dim=1)+1e-12)
    return p.cpu().numpy(),q.cpu().numpy(),ep.cpu().numpy(),eq.cpu().numpy()
