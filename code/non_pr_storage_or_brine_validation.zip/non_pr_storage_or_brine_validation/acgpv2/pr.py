from __future__ import annotations
import numpy as np
from scipy.optimize import brentq, least_squares

R = 8.31446261815324
P_REF = 1.0e5

LIB = {
    'H2':  {'Tc':33.145,  'Pc':1.2964e6, 'omega':-0.216,  'MW':2.01588e-3},
    'N2':  {'Tc':126.192, 'Pc':3.3958e6, 'omega':0.0372,  'MW':28.0134e-3},
    'CH4': {'Tc':190.564, 'Pc':4.5992e6, 'omega':0.01142, 'MW':16.0425e-3},
    'CO2': {'Tc':304.1282,'Pc':7.3773e6, 'omega':0.22394, 'MW':44.0095e-3},
    'C2':  {'Tc':305.322, 'Pc':4.872e6,  'omega':0.0995,  'MW':30.069e-3},
    'C3':  {'Tc':369.83,  'Pc':4.248e6,  'omega':0.1523,  'MW':44.0956e-3},
    'nC4': {'Tc':425.125, 'Pc':3.796e6,  'omega':0.2002,  'MW':58.1222e-3},
    'nC5': {'Tc':469.70,  'Pc':3.370e6,  'omega':0.2511,  'MW':72.1488e-3},
    'nC6': {'Tc':507.82,  'Pc':3.034e6,  'omega':0.3003,  'MW':86.1754e-3},
    'nC8': {'Tc':568.74,  'Pc':2.486e6,  'omega':0.3996,  'MW':114.2285e-3},
}

class PREOS:
    def __init__(self, names, kij=None):
        self.names=list(names)
        vals=[LIB[n] for n in self.names]
        self.Tc=np.array([v['Tc'] for v in vals],float)
        self.Pc=np.array([v['Pc'] for v in vals],float)
        self.omega=np.array([v['omega'] for v in vals],float)
        self.MW=np.array([v['MW'] for v in vals],float)
        n=len(vals)
        self.kij=np.zeros((n,n),float) if kij is None else np.asarray(kij,float)

    def parameters(self,T):
        kap=0.37464+1.54226*self.omega-0.26992*self.omega**2
        alpha=(1+kap*(1-np.sqrt(T/self.Tc)))**2
        ai=0.45724*R**2*self.Tc**2/self.Pc*alpha
        bi=0.07780*R*self.Tc/self.Pc
        aij=np.sqrt(ai[:,None]*ai[None,:])*(1-self.kij)
        return ai,bi,aij

    def z_roots(self,T,P,x):
        x=np.asarray(x,float)
        _,bi,aij=self.parameters(T)
        am=x@aij@x; bm=x@bi
        A=am*P/(R**2*T**2); B=bm*P/(R*T)
        coeff=[1.0, -(1-B), A-3*B*B-2*B, -(A*B-B*B-B**3)]
        roots=np.roots(coeff)
        rr=np.sort(roots.real[np.abs(roots.imag)<1e-8])
        if len(rr)==0:
            raise RuntimeError('PR returned no real root')
        return rr,A,B,am,bm,bi,aij

    def lnphi(self,T,P,x,phase='vapor'):
        x=np.asarray(x,float)
        rr,A,B,am,bm,bi,aij=self.z_roots(T,P,x)
        Z=rr[-1] if phase=='vapor' else rr[0]
        suma=aij@x; s=np.sqrt(2.0)
        logterm=np.log((Z+(1+s)*B)/(Z+(1-s)*B))
        ln=(bi/bm*(Z-1)-np.log(Z-B)
            -A/(2*s*B)*(2*suma/am-bi/bm)*logterm)
        return ln,Z,len(rr)

    def state(self,T,P,x,phase='vapor'):
        x=np.asarray(x,float)
        ln,Z,nr=self.lnphi(T,P,x,phase)
        f=x*np.exp(ln)*P
        c=x*P/(Z*R*T)
        return {
            'nu_fugacity':np.log(f/P_REF),
            'psi':P/(R*T),
            'c':c,'Z':float(Z),'rho_molar':float(c.sum()),
            'rho_mass':float(c@self.MW),'nroots':nr,'fugacity':f,
        }

    def wilson_K(self,T,P):
        return (self.Pc/P)*np.exp(5.373*(1+self.omega)*(1-self.Tc/T))

    @staticmethod
    def rachford_rice(z,K):
        z=np.asarray(z,float); K=np.asarray(K,float)
        fun=lambda b: np.sum(z*(K-1)/(1+b*(K-1)))
        f0,f1=fun(0.),fun(1.)
        if f0<0:return 0.,'liquid'
        if f1>0:return 1.,'vapor'
        return brentq(fun,0.,1.,xtol=1e-13),'two-phase'

    def flash(self,T,P,z,tol=1e-10,maxiter=120,damping=.6):
        z=np.asarray(z,float); K=self.wilson_K(T,P); ne=0
        for it in range(1,maxiter+1):
            beta,state=self.rachford_rice(z,K)
            den=1+beta*(K-1); x=z/den; y=K*x
            x/=x.sum(); y/=y.sum()
            lnl,_,_=self.lnphi(T,P,x,'liquid'); lnv,_,_=self.lnphi(T,P,y,'vapor'); ne+=2
            target=lnl-lnv; err=float(np.max(np.abs(np.log(K)-target)))
            if err<tol:
                return {'success':True,'beta':float(beta),'phase':state,'x':x,'y':y,'iterations':it,'eos_evals':ne,'residual':err}
            K=np.exp((1-damping)*np.log(K)+damping*target)
        return {'success':False,'beta':float(beta),'phase':state,'x':x,'y':y,'iterations':maxiter,'eos_evals':ne,'residual':err}

    def binary_vle(self,T,P,guess=(.05,.8)):
        if len(self.names)!=2: raise ValueError('binary only')
        g=np.clip(np.asarray(guess,float),1e-7,1-1e-7)
        # Parameterize y=x+(1-x)r.  Solving directly for independent x and y
        # admits the nonphysical identity root x=y at every T,P.
        x0=min(g[0],g[1]-1e-5)
        r0=np.clip((g[1]-x0)/(1-x0),1e-5,1-1e-7)
        u0=np.array([np.log(x0/(1-x0)),np.log(r0/(1-r0))])
        def residual(u):
            a=1/(1+np.exp(-np.clip(u,-30,30)))
            xv=np.clip(a[0],1e-10,1-1e-10)
            rv=np.clip(a[1],1e-5,1-1e-10)
            yv=xv+(1-xv)*rv
            x=np.array([xv,1-xv]); y=np.array([yv,1-yv])
            try:
                l,_,_=self.lnphi(T,P,x,'liquid'); v,_,_=self.lnphi(T,P,y,'vapor')
                r=np.log(x)+l-np.log(y)-v
                if not np.all(np.isfinite(r)): raise FloatingPointError
                return r
            except Exception:
                return np.array([1e3,1e3])
        sol=least_squares(residual,u0,max_nfev=200,xtol=1e-12,ftol=1e-12,gtol=1e-12)
        a=1/(1+np.exp(-np.clip(sol.x,-30,30)))
        xv=np.clip(a[0],1e-10,1-1e-10);rv=np.clip(a[1],1e-5,1-1e-10);yv=xv+(1-xv)*rv
        return {'success':bool(sol.success and np.max(np.abs(sol.fun))<1e-7 and yv-xv>1e-5),
                'x':np.array([xv,1-xv]),'y':np.array([yv,1-yv]),
                'nfev':int(sol.nfev),'residual':float(np.max(np.abs(sol.fun)))}
