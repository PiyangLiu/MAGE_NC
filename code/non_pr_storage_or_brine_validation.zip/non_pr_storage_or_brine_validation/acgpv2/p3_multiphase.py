"""Any-phase-number natural-map KKT: one global mu and phase saturations."""
import numpy as np
import torch
from scipy.optimize import least_squares
from .pr import R


class MultiphaseKKT:
    def __init__(self,branches):
        self.branches=branches;self.np=len(branches);self.nc=branches[0].dim-1
        self.device=branches[0].scale.device;self.dtype=branches[0].scale.dtype
        self.es=branches[0].scale[1:]

    def coexistence_seed(self,T,P,eta):
        """Active-set initialization from MM branch pressures, never teacher."""
        if self.np!=self.nc:return np.asarray(eta),None
        t=torch.tensor([T],device=self.device,dtype=self.dtype);target=P/(R*T)
        w=torch.tensor(np.asarray(eta)[1:]/self.es.cpu().numpy(),device=self.device,dtype=self.dtype)[None]
        with torch.no_grad():
            for iteration in range(60):
                e=torch.cat([-1/(R*t[:,None]),w*self.es],1)
                vals=[b(e,order=1) for b in self.branches]
                p=torch.stack([v[0][0] for v in vals]);c=torch.stack([v[1][0,1:] for v in vals]);f=(p-target)/target
                if float(f.abs().max())<1e-9:
                    if bool((c>=-1e-8).all()) and bool((c.sum(1)>0).all()):return e[0].cpu().numpy(),c.cpu().numpy()
                    break
                J=c*self.es/target;step,info=torch.linalg.solve_ex(J,-f)
                if int(info) or not torch.isfinite(step).all():break
                alpha=min(1.,.5/max(float((step*self.es).abs().max()),1e-20));good=False
                for ls in range(14):
                    trial=w+alpha*step;e1=torch.cat([-1/(R*t[:,None]),trial*self.es],1)
                    pp=torch.stack([b(e1,order=1)[0][0] for b in self.branches]);f1=(pp-target)/target
                    if float(f1@f1)<float(f@f):w=trial;good=True;break
                    alpha*=.5
                if not good:break
        return np.asarray(eta),None

    def residual(self,w,T,P,z,jac=True):
        nc=self.nc;np_=self.np;S=w[:,nc:];E=torch.cat([(-1/(R*T))[:,None],w[:,:nc]*self.es],1)
        outputs=[b(E,order=2 if jac else 1) for b in self.branches]
        psi=torch.stack([a[0] for a in outputs],1);q=torch.stack([a[1] for a in outputs],1)
        c=q[:,:,1:];C=(S[:,:,None]*c).sum(1);rho=C.sum(1);x=C/rho[:,None]
        target=P/(R*T);sig=S+(psi-target[:,None])/target[:,None]
        comp=S-torch.clamp_min(sig,0)
        # Exclude the largest feed component, not an arbitrarily fixed solvent.
        # This prevents trace salt from disappearing through cancellation of
        # two almost-one concentrations near a vapor endpoint.
        indices=torch.topk(z,nc-1,largest=False).indices
        composition_scale=torch.gather(z,1,indices).clamp_min(1e-10)
        selected_x=torch.gather(x,1,indices)
        f=torch.cat([(selected_x-torch.gather(z,1,indices))/composition_scale,(S.sum(1)-1)[:,None],comp],1)
        fields=dict(E=E,psi=psi,q=q,S=S,C=C,rho=rho)
        if not jac:return f,None,fields
        H=torch.stack([a[2] for a in outputs],1);n=len(w)
        J=torch.zeros((n,nc+np_,nc+np_),device=self.device,dtype=self.dtype)
        dC=(S[:,:,None,None]*H[:,:,1:,1:]).sum(1)*self.es[None,None,:]
        selected_dC=torch.gather(dC,1,indices[:,:,None].expand(-1,-1,nc))
        selected_c=torch.gather(c,2,indices[:,None,:].expand(-1,np_,-1))
        J[:,:nc-1,:nc]=(selected_dC-selected_x[:,:,None]*dC.sum(1)[:,None,:])/rho[:,None,None]
        J[:,:nc-1,nc:]=(selected_c-selected_x[:,None,:]*c.sum(2)[:,:,None]).transpose(1,2)/rho[:,None,None]
        J[:,:nc-1,:]/=composition_scale[:,:,None]
        J[:,nc-1,nc:]=1
        active=sig>0
        J[:,nc:,:nc]=torch.where(active[:,:,None],-c*self.es/target[:,None,None],torch.zeros_like(c))
        J[:,nc:,nc:]=torch.diag_embed((~active).to(w.dtype))
        fields['H']=H
        return f,J,fields

    def solve_one(self,T,P,z,eta,initial_S=None,recover=True):
        nc=self.nc;tt=torch.tensor([T],device=self.device,dtype=self.dtype);pp=torch.tensor([P],device=self.device,dtype=self.dtype);zz=torch.tensor(np.asarray(z)[None],device=self.device,dtype=self.dtype)
        x0=np.r_[np.asarray(eta)[1:]/self.es.cpu().numpy(),np.full(self.np,1/self.np) if initial_S is None else initial_S]
        calls=[0];cache={}
        def fg(v):
            key=v.tobytes()
            if key in cache:return cache[key]
            with torch.no_grad():f,J,st=self.residual(torch.tensor(v[None],device=self.device,dtype=self.dtype),tt,pp,zz)
            calls[0]+=1;cache.clear();cache[key]=(f[0].cpu().numpy(),J[0].cpu().numpy());return cache[key]
        centers=[b.center.detach().cpu().numpy()[1:] for b in self.branches if hasattr(b,'center')]
        scales=[b.scale.detach().cpu().numpy()[1:] for b in self.branches if hasattr(b,'center')]
        lo=np.r_[np.min([c-5*s for c,s in zip(centers,scales)],axis=0)/self.es.cpu().numpy(),np.full(self.np,-.02)]
        hi=np.r_[np.max([c+5*s for c,s in zip(centers,scales)],axis=0)/self.es.cpu().numpy(),np.full(self.np,1.02)]
        x0=np.clip(x0,lo+1e-9,hi-1e-9)
        trial=least_squares(lambda v:fg(v)[0],x0,jac=lambda v:fg(v)[1],bounds=(lo,hi),max_nfev=200,xtol=1e-11,ftol=1e-11,gtol=1e-11,x_scale='jac')
        with torch.no_grad():f,J,st=self.residual(torch.tensor(trial.x[None],device=self.device,dtype=self.dtype),tt,pp,zz)
        q=st['q'][0].cpu().numpy();S=trial.x[nc:];rho=q[:,1:].sum(1);C=S@q[:,1:];total=C.sum();beta=S*rho/total
        pressure=st['psi'][0].cpu().numpy()*R*T
        physical=(S>=-1e-7).all() and (S<=1+1e-7).all() and (C>0).all() and all((q[k,1:]>=-1e-8).all() for k in range(self.np) if S[k]>1e-7)
        out=dict(success=bool(max(abs(trial.fun))<1e-7 and physical),residual=float(max(abs(trial.fun))),S=S,beta=beta,x=q[:,1:]/rho[:,None],rho=1/(beta/rho).sum(),phase_rho=rho,h=(S@q[:,0]+P)/total,phase_h=(q[:,0]+pressure)/rho,eta=st['E'][0].cpu().numpy(),phase_pressure=pressure,condition=float(torch.linalg.cond(J)[0]),w=trial.x,evaluations=calls[0])
        if not out['success'] and recover:
            attempts=out['evaluations']
            for phase in range(self.np):
                guess=np.asarray(eta).copy()
                with torch.no_grad():p0,q0,_=self.branches[phase](torch.tensor(guess[None],device=self.device,dtype=self.dtype),order=1)
                c0=q0[0,1:].cpu().numpy();xphase=np.maximum(c0,1e-15);xphase/=xphase.sum()
                if c0.sum()<15000:guess[1:]+=np.log(np.maximum(z,1e-15)/xphase)
                seed=np.zeros(self.np);seed[phase]=1.
                candidate=self.solve_one(T,P,z,guess,seed,recover=False);attempts+=candidate['evaluations']
                if candidate['success'] or candidate['residual']<out['residual']:out=candidate
                if out['success']:break
            out['evaluations']=attempts
        return out

    def solve_many(self,T,P,z,eta,max_iter=80,chunk=128,initial_S=None,recover=True):
        T=np.atleast_1d(T);P=np.broadcast_to(P,T.shape);z=np.asarray(z);eta=np.broadcast_to(eta,(len(T),self.nc+1));result=[]
        if initial_S is None and self.np==self.nc:
            eta=eta.copy();initial_S=np.full((len(T),self.np),1/self.np);cache={}
            for i in range(len(T)):
                key=(float(T[i]),float(P[i]),tuple(eta[i]))
                if key not in cache:cache[key]=self.coexistence_seed(T[i],P[i],eta[i])
                ei,c=cache[key]
                if c is None:continue
                A=np.vstack([(c[:,:self.nc-1]-z[i,:self.nc-1]*c.sum(1)[:,None]).T,np.ones(self.np)])
                try:S=np.linalg.solve(A,np.r_[np.zeros(self.nc-1),1.])
                except np.linalg.LinAlgError:continue
                if min(S)>-1e-7:eta[i]=ei;initial_S[i]=S
        for first in range(0,len(T),chunk):
            sl=slice(first,first+chunk);tt=torch.tensor(T[sl],device=self.device,dtype=self.dtype);pp=torch.tensor(P[sl],device=self.device,dtype=self.dtype);zz=torch.tensor(z[sl],device=self.device,dtype=self.dtype)
            ss=np.full((len(tt),self.np),1/self.np) if initial_S is None else np.asarray(initial_S)[sl]
            w=torch.tensor(np.column_stack([eta[sl,1:]/self.es.cpu().numpy(),ss]),device=self.device,dtype=self.dtype);evaluations=torch.zeros(len(tt),device=self.device,dtype=torch.int64)
            with torch.no_grad():
                for iteration in range(max_iter):
                    f,J,st=self.residual(w,tt,pp,zz);done=f.abs().amax(1)<1e-8;evaluations+=1
                    if done.all():break
                    dw,info=torch.linalg.solve_ex(J,-f[:,:,None]);dw=dw[:,:,0];bad=(info!=0)|(~torch.isfinite(dw).all(1))
                    if bad.any():
                        A=J[bad];rhs=f[bad];eye=torch.eye(self.nc+self.np,device=w.device,dtype=w.dtype)
                        dw[bad]=torch.linalg.solve(A.transpose(1,2)@A+1e-7*eye,-(A.transpose(1,2)@rhs[:,:,None]))[:,:,0]
                    dw[done]=0
                    amount=(dw[:,:self.nc]*self.es).abs().amax(1);a=torch.minimum(torch.ones_like(amount),.5/amount.clamp_min(1e-20));accepted=done.clone();merit=f.square().sum(1)
                    for ls in range(14):
                        trial=w+a[:,None]*dw;ft=self.residual(trial,tt,pp,zz,False)[0];evaluations+=1
                        good=torch.isfinite(ft).all(1)&(ft.square().sum(1)<=(1-1e-4*a)*merit);take=good&(~accepted);w[take]=trial[take];accepted|=good;a[~accepted]*=.5
                        if accepted.all():break
                    if not accepted[~done].any():break
                f,J,st=self.residual(w,tt,pp,zz);qa=st['q'].cpu().numpy();sa=st['S'].cpu().numpy();ea=st['E'].cpu().numpy();ra=f.abs().amax(1).cpu().numpy();condition=torch.linalg.cond(J).cpu().numpy();pressure=st['psi'].cpu().numpy()*R*T[sl,None];wa=w.cpu().numpy()
            for j in range(len(tt)):
                q=qa[j];S=sa[j];rho=q[:,1:].sum(1);C=S@q[:,1:];total=C.sum();beta=S*rho/total
                physical=(S>=-1e-7).all() and (S<=1+1e-7).all() and (C>0).all() and all((q[k,1:]>=-1e-8).all() for k in range(self.np) if S[k]>1e-7)
                out=dict(success=bool(ra[j]<1e-7 and physical),residual=float(ra[j]),S=S,beta=beta,x=q[:,1:]/rho[:,None],rho=total,phase_rho=rho,h=(S@q[:,0]+P[first+j])/total,phase_h=(q[:,0]+pressure[j])/rho,eta=ea[j],phase_pressure=pressure[j],condition=float(condition[j]),w=wa[j],evaluations=int(evaluations[j]),recovered=False)
                if not out['success'] and recover:
                    trial=self.solve_one(float(T[first+j]),float(P[first+j]),z[first+j],ea[j],S)
                    if trial['success'] or trial['residual']<out['residual']:trial['evaluations']+=out['evaluations'];trial['recovered']=True;out=trial
                result.append(out)
        return result
