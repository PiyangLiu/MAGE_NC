"""Conserved H2/water/NaCl + energy Darcy with convex capillary energy."""
import time
import numpy as np
import torch
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import LinearOperator,gmres,spilu
from .pr import R


class CapillaryGrandThermo:
    def __init__(self,liquid,gas,Pcbase=2000.,Pcscale=50000.):
        self.L=liquid;self.V=gas;self.scale=liquid.scale.detach().cpu().numpy()[1:]
        self.Pcbase=Pcbase;self.Pcscale=Pcscale;self.calls=0;self.wall=0.
    def coordinates(self,E):return np.column_stack([-1/(R*E[:,0])/323.15,E[:,1:]/self.scale])
    def state(self,w,jac=True):
        start=time.perf_counter();n=len(w);self.calls+=n;parts=[]
        with torch.no_grad():
            for first in range(0,n,128):
                a=w[first:first+128];T=323.15*a[:,0];E=np.column_stack([-1/(R*T),a[:,1:]*self.scale]);e=torch.tensor(E,device=self.L.scale.device,dtype=self.L.scale.dtype)
                pL,qL,HL=self.L(e);pV,qV,HV=self.V(e)
                tt=torch.tensor(T,device=e.device,dtype=e.dtype);stiff=self.Pcscale/(R*tt)
                S=torch.clamp((pV-pL-self.Pcbase/(R*tt))/stiff,0,1);interior=(S>0)&(S<1)
                pc=self.Pcbase+self.Pcscale*S;F=self.Pcbase*S+.5*self.Pcscale*S*S
                v=qV-qL;v=v.clone();v[:,0]+=pc
                dS=torch.where(interior[:,None],v/stiff[:,None],torch.zeros_like(v))
                q=(1-S[:,None])*qL+S[:,None]*qV;q=q.clone();q[:,0]+=F
                H=(1-S[:,None,None])*HL+S[:,None,None]*HV+torch.where(interior[:,None,None],v[:,:,None]*v[:,None,:]/stiff[:,None,None],torch.zeros_like(HL))
                de=np.zeros((len(T),4,4));de[:,0,0]=1/(R*T*T)*323.15;de[:,1:,1:]=np.diag(self.scale)
                D=torch.tensor(de,device=e.device,dtype=e.dtype)
                dqq=(H@D);dss=torch.einsum('bi,bij->bj',dS,D)
                dql=HL@D;dqv=HV@D;dt=torch.zeros((len(T),4),device=e.device,dtype=e.dtype);dt[:,0]=323.15
                dpL=R*tt[:,None]*torch.einsum('bi,bij->bj',qL,D)+R*pL[:,None]*dt
                dpV=R*tt[:,None]*torch.einsum('bi,bij->bj',qV,D)+R*pV[:,None]*dt
                st=dict(T=tt,S=S,C=q[:,1:],U=q[:,0],dT=dt,dS=dss,dC=dqq[:,1:],dU=dqq[:,0],pL=pL*R*tt,pV=pV*R*tt,dpL=dpL,dpV=dpV,cL=qL[:,1:],cV=qV[:,1:],dcL=dql[:,1:],dcV=dqv[:,1:],hL=qL[:,0]+pL*R*tt,hV=qV[:,0]+pV*R*tt,dhL=dql[:,0]+dpL,dhV=dqv[:,0]+dpV,capillary_energy=F)
                parts.append({k:v.cpu().numpy() for k,v in st.items()})
        out={k:np.concatenate([p[k] for p in parts]) for k in parts[0]}
        activeL=out['S']<1-1e-8;activeV=out['S']>1e-8
        if (out['cL'][activeL]<=0).any() or (out['cV'][activeV,:2]<=0).any():raise ValueError('nonpositive active MM species; reject, do not clip concentrations')
        self.wall+=time.perf_counter()-start;return out


class UHSBrineDarcy:
    def __init__(self,ny,nx,K,thermo,dx=1.,dy=1.):
        self.ny=ny;self.nx=nx;self.n=ny*nx;self.K=K.ravel();self.thermo=thermo;self.dx=dx;self.dy=dy;self.vol=dx*dy;self.phi=.22
        grid=np.arange(self.n).reshape(ny,nx);self.i=np.r_[grid[:,:-1].ravel(),grid[:-1,:].ravel()];self.j=np.r_[grid[:,1:].ravel(),grid[1:,:].ravel()]
        self.ad=np.r_[np.full(ny*(nx-1),dy/dx),np.full((ny-1)*nx,dx/dy)];i,j=self.i,self.j
        self.trans=2*self.K[i]*self.K[j]/(self.K[i]+self.K[j])*self.ad;self.height=np.repeat(np.arange(ny)*dy,nx)
        self.M=np.array([.00201588,.018015268,.05844277]);self.inj=(ny-1)*nx+nx//2;self.prod=nx//2;self.wells='closed';self.inlet=None

    def inventory_fields(self,st):
        rho=st['C']@self.M;dr=st['dC'].transpose(0,2,1)@self.M
        U=st['U']+rho*9.80665*self.height+2e6/self.phi*(st['T']-323.15)
        dU=st['dU']+dr*9.80665*self.height[:,None]+2e6/self.phi*st['dT']
        return np.column_stack([st['C'],U]),np.concatenate([st['dC'],dU[:,None,:]],1)

    @staticmethod
    def take(st,index,fixed=False):
        out={k:v[index].copy() for k,v in st.items()}
        if fixed:
            for k in out:
                if k.startswith('d'):out[k][:]=0
        return out

    def face(self,a,b,trans,ad,za,zb,gas_only=False):
        n=len(trans);f=np.zeros((n,4));da=np.zeros((n,4,4));db=da.copy()
        for tag,vis in [('L',1e-3),('V',1e-5)]:
            if gas_only and tag=='L':continue
            ra=a['c'+tag]@self.M;rb=b['c'+tag]@self.M
            dra=a['dc'+tag].transpose(0,2,1)@self.M;drb=b['dc'+tag].transpose(0,2,1)@self.M
            dz=za-zb;dp=a['p'+tag]-b['p'+tag]-.5*(ra+rb)*9.80665*dz
            dpa=a['dp'+tag]-.5*dra*9.80665*dz[:,None];dpb=-b['dp'+tag]-.5*drb*9.80665*dz[:,None]
            left=dp>=0
            def choose(k):return np.where(left.reshape((-1,)+(1,)*(a[k].ndim-1)),a[k],b[k])
            S=choose('S');dS=choose('dS');kr=S*S if tag=='V' else (1-S)**2;dk=2*S if tag=='V' else -2*(1-S)
            fac=trans/vis;velocity=fac*kr*dp;va=(fac*kr)[:,None]*dpa+(fac*dp*dk*left)[:,None]*dS;vb=(fac*kr)[:,None]*dpb+(fac*dp*dk*(~left))[:,None]*dS
            c=choose('c'+tag);dc=choose('dc'+tag);h=choose('h'+tag);dh=choose('dh'+tag);zup=np.where(left,za,zb)
            transport=np.column_stack([c,h+(c@self.M)*9.80665*zup]);der=np.concatenate([dc,(dh+(dc.transpose(0,2,1)@self.M)*9.80665*zup[:,None])[:,None,:]],1)
            f+=velocity[:,None]*transport;da+=transport[:,:,None]*va[:,None,:]+(velocity*left)[:,None,None]*der;db+=transport[:,:,None]*vb[:,None,:]+(velocity*(~left))[:,None,None]*der
        f[:,3]+=2*ad*(a['T']-b['T']);da[:,3]+=2*ad[:,None]*a['dT'];db[:,3]-=2*ad[:,None]*b['dT']
        return f,da,db

    def residual(self,w,old,dt,jac=True):
        st=self.thermo.state(w,jac);fields,df=self.inventory_fields(st);i,j=self.i,self.j
        f,di,dj=self.face(self.take(st,i),self.take(st,j),self.trans,self.ad,self.height[i],self.height[j]);div=np.zeros_like(fields)
        np.add.at(div,i,f/self.vol);np.add.at(div,j,-f/self.vol)
        ii=[i,i,j,j];jj=[i,j,i,j];vv=[di,dj,-di,-dj];boundary=np.zeros(4)
        if self.wells=='inject':
            at=self.inj;ff,_,der=self.face(self.take(self.inlet,[0],True),self.take(st,[at]),np.array([2*self.K[at]]),np.array([0.]),np.array([self.height[at]]),np.array([self.height[at]]),gas_only=True)
            if ff[0,0]<0:ff[:]=0;der[:]=0
            # Injected gas is selected by the actual capillary branch, not by
            # dropping a salt flux after computing a liquid injection.
            div[at]-=ff[0]/self.vol;boundary-=ff[0];ii.append(np.array([at]));jj.append(np.array([at]));vv.append(-der)
        elif self.wells=='withdraw':
            at=self.prod;ff,der,_=self.face(self.take(st,[at]),self.take(self.inlet,[0],True),np.array([2*self.K[at]]),np.array([0.]),np.array([self.height[at]]),np.array([self.height[at]]))
            div[at]+=ff[0]/self.vol;boundary+=ff[0];ii.append(np.array([at]));jj.append(np.array([at]));vv.append(der)
        oldf=self.inventory_fields(old)[0];scale=np.r_[np.maximum(np.median(abs(oldf[:,:3]),axis=0),1.),2e7]
        acc=fields-oldf;r=(acc+dt/self.phi*div)/scale
        meta=dict(state=st,balance=self.phi*self.vol*acc.sum(0)+dt*boundary,boundary=boundary,inventory=self.phi*self.vol*fields.sum(0))
        if not jac:return r.ravel(),None,meta
        B=np.concatenate(vv)*dt/(self.phi*self.vol)/scale[None,:,None];ir=np.concatenate(ii);ic=np.concatenate(jj)
        ir=np.r_[ir,np.arange(self.n)];ic=np.r_[ic,np.arange(self.n)];B=np.concatenate([B,df/scale[None,:,None]])
        row=(4*ir[:,None,None]+np.arange(4)[None,:,None]+np.zeros((1,1,4),int)).ravel();col=(4*ic[:,None,None]+np.arange(4)[None,None,:]+np.zeros((1,4,1),int)).ravel()
        J=coo_matrix((B.ravel(),(row,col)),shape=(4*self.n,4*self.n)).tocsr();return r.ravel(),J,meta

    def solve(self,w,dt,tol=2e-7):
        start=time.perf_counter();old=self.thermo.state(w);x=w.copy();backs=0;krylov=0
        for it in range(25):
            r,J,meta=self.residual(x,old,dt);norm=max(abs(r))
            if norm<tol:break
            ilu=spilu(J.tocsc(),drop_tol=1e-6,fill_factor=20);count=[0]
            def cb(v):count[0]+=1
            dw,info=gmres(J,-r,M=LinearOperator(J.shape,matvec=ilu.solve),rtol=1e-8,atol=0,maxiter=200,callback=cb,callback_type='pr_norm');krylov+=count[0]
            if info:break
            dw=dw.reshape(-1,4);a=min(1.,.01/max(abs(dw[:,0]).max(),1e-30),.1/max(abs(dw[:,1:]).max(),1e-30));merit=r@r;good=False
            for ls in range(15):
                try:
                    rt=self.residual(x+a*dw,old,dt,False)[0]
                    if np.isfinite(rt).all() and rt@rt<=(1-1e-4*a)*merit:x+=a*dw;good=True;break
                except (ValueError,RuntimeError,np.linalg.LinAlgError):pass
                a*=.5;backs+=1
            if not good:break
        r,_,meta=self.residual(x,old,dt,False)
        return x,meta,dict(accepted=bool(max(abs(r))<tol),iterations=it,residual=float(max(abs(r))),backtracks=backs,krylov=krylov,wall_s=time.perf_counter()-start)
