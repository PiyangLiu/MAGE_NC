from __future__ import annotations
import numpy as np
from scipy.optimize import least_squares
from .pr import R

def solve_binary_vle_massieu(T,P,bL,bV,guess_etai=None,max_nfev=120):
    eta0=-1/(R*T); target=P/(R*T)
    if guess_etai is None:
        # supports give a good scale-independent center
        guess_etai=.5*(bL.center[1:]+bV.center[1:])
    def f(etai):
        eta=np.r_[eta0,etai]
        return np.array([(bL.evaluate_eta(eta)['psi']-target)/target,
                         (bV.evaluate_eta(eta)['psi']-target)/target])
    sol=least_squares(f,np.asarray(guess_etai,float),xtol=1e-12,ftol=1e-12,gtol=1e-12,max_nfev=max_nfev)
    eta=np.r_[eta0,sol.x]; qL=bL.evaluate_eta(eta); qV=bV.evaluate_eta(eta)
    x=qL['c']/qL['c'].sum(); y=qV['c']/qV['c'].sum()
    return {'success':bool(sol.success),'etai':sol.x,'x':x,'y':y,'nfev':int(sol.nfev),
            'residual':float(np.max(np.abs(sol.fun))),'pL':qL['psi']*R*T,'pV':qV['psi']*R*T}

def massieu_phase_state(T,etai,S,bL,bV):
    eta0=-1/(R*T); eta=np.r_[eta0,np.asarray(etai,float)]
    L=bL.evaluate_eta(eta); V=bV.evaluate_eta(eta)
    pL=L['psi']*R*T; pV=V['psi']*R*T
    C=(1-S)*L['c']+S*V['c']
    return {'etai':np.asarray(etai,float),'S':float(S),'cL':L['c'],'cV':V['c'],
            'C':C,'z':C/C.sum(),'pL':pL,'pV':pV,
            'Pthermo':(1-S)*pL+S*pV,'uL':L['u'],'uV':V['u']}

def natural_map(S,pV,pL,Pscale=2e6,gamma=1.0):
    F=(pV-pL)/Pscale
    return S-np.clip(S+gamma*F,0.,1.)
