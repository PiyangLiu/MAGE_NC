"""Analytic natural-map recovery without changing phase potentials mid-solve."""
import numpy as np
import torch
from scipy.optimize import least_squares
from .bounded_flash import BoundedFlash


class RecoveringBoundedFlash(BoundedFlash):
    def solve(self,T,P,z,initial=None,max_iter=60,tol=1e-8,chunk=512,retry=True):
        result=super().solve(T,P,z,initial,max_iter,tol,chunk,retry=retry)
        if not retry:return result
        T=np.atleast_1d(T);P=np.atleast_1d(P);z=np.asarray(z).reshape(len(T),self.nc)
        result['recovery_evaluations']=np.zeros(len(T),int)
        result['recovery_level']=np.zeros(len(T),int)
        bad=np.where(~result['success'])[0]
        for i in bad:
            tt=torch.as_tensor(T[i:i+1],device=self.device,dtype=self.dtype)
            pp=torch.as_tensor(P[i:i+1],device=self.device,dtype=self.dtype)
            zz=torch.as_tensor(z[i:i+1],device=self.device,dtype=self.dtype)
            count=[0]
            def fg(x):
                with torch.no_grad():
                    f,J,st=self.residual(torch.as_tensor(x[None],device=self.device,dtype=self.dtype),tt,pp,zz)
                count[0]+=1
                return f[0].cpu().numpy(),J[0].cpu().numpy()
            guess=result['w'][i].copy()
            # Trust region acts on the identical analytic KKT residual. The
            # narrow extension allows saturation active-set crossings.
            lo=np.r_[self.e_low/self.es,-.05];hi=np.r_[self.e_high/self.es,1.05]
            guess=np.clip(guess,lo+1e-8,hi-1e-8)
            trust=least_squares(lambda x:fg(x)[0],guess,jac=lambda x:fg(x)[1],bounds=(lo,hi),method='trf',x_scale='jac',max_nfev=100,ftol=1e-12,xtol=1e-12,gtol=1e-12)
            probe=super().solve(T[i:i+1],P[i:i+1],z[i:i+1],trust.x[None],max_iter=4,tol=tol,chunk=1,retry=False)
            level=1
            if not probe['success'][0]:
                # Pseudo-transient normal-equation regularization, with an
                # adaptive shift and monotone residual decrease.
                x=trust.x.copy();shift=1e-2
                for step in range(80):
                    f,J=fg(x)
                    dx=np.linalg.solve(J.T@J+shift*np.eye(self.nc+1),-J.T@f)
                    trial=np.clip(x+dx,lo+1e-8,hi-1e-8);ft=fg(trial)[0]
                    if np.dot(ft,ft)<np.dot(f,f):x=trial;shift=max(shift*.3,1e-12)
                    else:shift=min(shift*5,1e8)
                    if max(abs(ft))<tol:break
                probe=super().solve(T[i:i+1],P[i:i+1],z[i:i+1],x[None],max_iter=10,tol=tol,chunk=1,retry=False);level=2
            if not probe['success'][0]:
                _,j=self.tree.query([[T[i]/self.Tscale,np.log(P[i])/self.Pscale]])
                j=int(j[0]);Ta=float(self.atlas['T'][j]);Pa=float(self.atlas['P'][j]);za=.5*(self.atlas['x'][j]+self.atlas['y'][j])
                path=self.initial([Ta],[Pa],za[None]);okay=True
                for fraction in np.linspace(0,1,17):
                    t=[Ta+fraction*(T[i]-Ta)];p=[np.exp(np.log(Pa)+fraction*np.log(P[i]/Pa))];feed=(za+fraction*(z[i]-za))[None]
                    q=super().solve(t,p,feed,path,max_iter=60,tol=tol,chunk=1,retry=False)
                    count[0]+=int(q['iterations'][0])+1;path=q['w']
                    if not q['success'][0]:okay=False;break
                if okay:probe=q
                level=3
            old_it=int(result['iterations'][i]);old_back=int(result['backtracks'][i])
            if probe['success'][0] or probe['residual'][0]<result['residual'][i]:
                for key in probe:
                    if key in result:result[key][i]=probe[key][0]
                result['iterations'][i]+=old_it;result['backtracks'][i]+=old_back
            result['recovery_evaluations'][i]=count[0];result['recovery_level'][i]=level
        return result
