from __future__ import annotations
import numpy as np
from .massieu import MassieuACGP, farthest_point_indices

def _kmeans_labels(X,k,seed=0,iterations=40):
    X=np.asarray(X,float); k=min(int(k),len(X)); ids=np.linspace(0,len(X)-1,k).round().astype(int)
    centers=X[ids].copy()
    for _ in range(iterations):
        labels=((X[:,None,:]-centers[None,:,:])**2).sum(2).argmin(1); new=centers.copy()
        for j in range(k):
            if np.any(labels==j): new[j]=X[labels==j].mean(0)
        if np.allclose(new,centers): break
        centers=new
    return labels,centers

def _pca(X,rank):
    X=np.asarray(X,float); mean=X.mean(0); _,s,Vt=np.linalg.svd(X-mean,full_matrices=False)
    r=min(int(rank),Vt.shape[0]); return mean,Vt[:r],s[:r]

class LocalChartCompressedACGP:
    """Manifold/local-chart compression while retaining one global convex LSE.

    1. Partition teacher states in normalized eta-space.
    2. In each chart, use local PCA only for *selection and gradient storage
       compression*.
    3. Selected/projected support gradients are reconstructed as full-space
       affine supports.
    4. All supports enter ONE global MassieuACGP log-sum-exp.

    Hence chart boundaries do not blend nonlinear potentials and global convexity
    is preserved exactly.
    """
    def __init__(self,base_model,chart_info):
        self.base_model=base_model; self.chart_info=chart_info
    @property
    def n_atoms(self): return self.base_model.n_atoms
    def evaluate_eta(self,*a,**k): return self.base_model.evaluate_eta(*a,**k)
    def evaluate_batch_eta(self,*a,**k): return self.base_model.evaluate_batch_eta(*a,**k)
    def isothermal_view(self,T): return self.base_model.isothermal_view(T)

def build_local_chart_acgp(data,n_charts=4,rank=2,atoms_per_chart=8,tau=1.0,
                           project_gradients=True,random_state=0):
    eta=np.asarray(data['eta']); psi=np.asarray(data['psi']); q=np.asarray(data['q'])
    center=eta.mean(0); scale=eta.std(0); scale=np.where(scale<1e-14,1.,scale)
    X=(eta-center)/scale
    k=min(n_charts,len(X))
    labels,_=_kmeans_labels(X,k,random_state)
    chosen_eta=[]; chosen_psi=[]; chosen_q=[]; infos=[]
    for r in range(k):
        I=np.where(labels==r)[0]
        if len(I)==0: continue
        Xr=X[I]; qr=q[I]
        # intrinsic coordinates used for representative selection
        d=min(rank,Xr.shape[1],max(1,len(I)-1))
        mx,cx,sx=_pca(Xr,d); Z=(Xr-mx)@cx.T
        eta_explained=float(np.sum(sx*sx)/(np.sum(np.linalg.svd(Xr-mx,compute_uv=False)**2)+1e-30))
        loc=farthest_point_indices(Z,min(atoms_per_chart,len(I)))
        J=I[loc]
        qsel=q[J].copy()
        explained_q=1.0
        if project_gradients and len(I)>d+1:
            q0=qr.mean(0)
            dq=qr-q0
            # Low-rank gradient manifold. Reconstructed gradients still define
            # full-space affine supports, so convexity is retained.
            mq,cq,sq=_pca(dq,d)
            qsel=q0+(q[J]-mq)@cq.T@cq+mq
            explained_q=float(np.sum(sq*sq)/(np.sum(np.linalg.svd(dq,compute_uv=False)**2)+1e-30))
        chosen_eta.append(eta[J]); chosen_psi.append(psi[J]); chosen_q.append(qsel)
        infos.append({'chart':r,'n_states':len(I),'rank':d,'n_atoms':len(J),
                      'eta_explained':eta_explained,
                      'q_explained':explained_q})
    E=np.vstack(chosen_eta); P=np.concatenate(chosen_psi); Q=np.vstack(chosen_q)
    model=MassieuACGP(E,P,Q,tau=tau,center=center,scale=scale,name='local-chart')
    return LocalChartCompressedACGP(model,infos)

def intrinsic_rank(X,variance=0.995):
    X=np.asarray(X,float); X=X-X.mean(0)
    s=np.linalg.svd(X,compute_uv=False)
    v=s*s; cs=np.cumsum(v)/(v.sum()+1e-30)
    return int(np.searchsorted(cs,variance)+1)

class QuadraticChartACGP:
    """Low-rank convex quadratic local-chart ACGP.

    Each chart is a convex quadratic support function
        Q_r(x)=psi_r + gx_r^T dx + 0.5 dx^T H_r dx,
    H_r PSD and low-rank.  The global potential is tau*logsumexp(Q_r/tau).
    Therefore global convexity is exact.  Curvature scaling is calibrated so
    the quadratic remains below teacher values at all supplied training states
    (up to tolerance), turning it into a sampled-domain quadratic support.
    """
    def __init__(self,center,scale,x0,psi0,gx0,Hx,tau=1.0,name='quadratic-chart'):
        self.center=np.asarray(center,float); self.scale=np.asarray(scale,float)
        self.x0=np.asarray(x0,float); self.psi0=np.asarray(psi0,float); self.gx0=np.asarray(gx0,float)
        self.Hx=np.asarray(Hx,float); self.tau=float(tau); self.name=name
    @property
    def n_atoms(self): return len(self.psi0)
    @property
    def ranks(self): return np.array([np.linalg.matrix_rank(H,tol=1e-10) for H in self.Hx])
    def evaluate_eta(self,eta,return_hessian=False):
        x=(np.asarray(eta,float)-self.center)/self.scale
        d=x[None,:]-self.x0
        Q=self.psi0+np.einsum('ij,ij->i',self.gx0,d)+.5*np.einsum('ij,ijk,ik->i',d,self.Hx,d)
        G=self.gx0+np.einsum('ijk,ik->ij',self.Hx,d)
        s=Q/self.tau; a=s.max(); e=np.exp(s-a); w=e/e.sum(); psi=self.tau*(a+np.log(e.sum()))
        gx=w@G; q=gx/self.scale
        out={'psi':float(psi),'q':q,'u':float(q[0]),'c':q[1:],'weights':w}
        if return_hessian:
            Hmean=np.einsum('i,ijk->jk',w,self.Hx)
            second=(G.T*w)@G
            Hx=Hmean+(second-np.outer(gx,gx))/self.tau
            H=Hx/(self.scale[:,None]*self.scale[None,:]); out['H_eta']=.5*(H+H.T)
        return out
    def evaluate_batch_eta(self,E):
        E=np.asarray(E,float)
        X=(E-self.center[None,:])/self.scale[None,:]
        # N x K x D displacement
        d=X[:,None,:]-self.x0[None,:,:]
        Q=self.psi0[None,:]+np.einsum('nkd,kd->nk',d,self.gx0)+.5*np.einsum('nkd,kde,nke->nk',d,self.Hx,d)
        G=self.gx0[None,:,:]+np.einsum('kde,nke->nkd',self.Hx,d)
        s=Q/self.tau
        a=s.max(axis=1,keepdims=True); ex=np.exp(s-a); w=ex/ex.sum(axis=1,keepdims=True)
        psi=self.tau*(a[:,0]+np.log(ex.sum(axis=1)))
        gx=np.einsum('nk,nkd->nd',w,G)
        q=gx/self.scale[None,:]
        return psi,q
    def isothermal_view(self,T):
        from .massieu import IsothermalMassieuView
        return IsothermalMassieuView(self,T)


def build_quadratic_chart_acgp(data,n_charts=16,rank=3,tau=.5,random_state=0,safety=.98):
    eta=np.asarray(data['eta']); psi=np.asarray(data['psi']); q=np.asarray(data['q'])
    center=eta.mean(0); scale=eta.std(0); scale=np.where(scale<1e-14,1.,scale)
    X=(eta-center)/scale; Qx=q*scale[None,:]
    labels,centers=_kmeans_labels(X,min(n_charts,len(X)),random_state)
    x0s=[];p0s=[];g0s=[];Hs=[];infos=[]
    for r in range(centers.shape[0]):
        I=np.where(labels==r)[0]; xc=centers[r]
        j=I[np.argmin(np.sum((X[I]-xc)**2,axis=1))]
        x0=X[j]; p0=psi[j]; g0=Qx[j]
        DE=X[I]-x0; DG=Qx[I]-g0
        # local least-squares Hessian: DG ~= DE H^T
        if len(I)>=3:
            H=np.linalg.lstsq(DE,DG,rcond=1e-8)[0].T
            H=.5*(H+H.T)
            lam,U=np.linalg.eigh(H); order=np.argsort(lam)[::-1]
            lam=lam[order];U=U[:,order]; lam=np.maximum(lam,0.)
            rr=min(rank,np.count_nonzero(lam>1e-10))
            if rr>0: H=(U[:,:rr]*lam[:rr])@U[:,:rr].T
            else: H=np.zeros_like(H)
        else: H=np.zeros((X.shape[1],X.shape[1]))
        # Calibrate a global lower-support scale on all training samples.
        Dall=X-x0
        tangent=p0+Dall@g0
        quad=.5*np.einsum('ij,jk,ik->i',Dall,H,Dall)
        slack=psi-tangent
        mask=quad>1e-12
        if np.any(mask):
            ratios=slack[mask]/quad[mask]
            # negative slack only from finite/noisy teacher/convex-branch mismatch: do not add curvature there.
            positive=ratios[ratios>0]
            alpha=min(1.0,safety*float(np.quantile(positive,.01))) if len(positive) else 0.0
        else: alpha=0.0
        alpha=max(alpha,0.0); H=alpha*H
        x0s.append(x0);p0s.append(p0);g0s.append(g0);Hs.append(H)
        infos.append({'chart':r,'n_states':len(I),'rank':int(np.linalg.matrix_rank(H,tol=1e-10)),'curvature_scale':alpha})
    model=QuadraticChartACGP(center,scale,np.array(x0s),np.array(p0s),np.array(g0s),np.array(Hs),tau=tau)
    return model,infos

class FactorizedChartACGP:
    """Low-rank factorization of a standard ACGP support set.

    For atom m in chart r:
        g_m ~= gbar_r + U_r a_m
    in normalized Massieu coordinates.  The global model is still a single LSE
    over affine functions, so convexity is exact.  This changes the cost/storage
    from O(M*D) gradient coefficients toward O(K*D*r + M*r).
    """
    def __init__(self,center,scale,tau,chart_base,chart_U,atom_chart,atom_a,intercept,atom_psi,atom_x):
        self.center=np.asarray(center);self.scale=np.asarray(scale);self.tau=float(tau)
        self.chart_base=[np.asarray(x) for x in chart_base];self.chart_U=[np.asarray(x) for x in chart_U]
        self.atom_chart=np.asarray(atom_chart,int);self.atom_a=[np.asarray(x) for x in atom_a]
        self.intercept=np.asarray(intercept);self.atom_psi=np.asarray(atom_psi);self.atom_x=np.asarray(atom_x)
    @property
    def n_atoms(self):return len(self.intercept)
    @property
    def dim(self):return len(self.center)
    @property
    def stored_scalars(self):
        return int(sum(b.size+U.size for b,U in zip(self.chart_base,self.chart_U)) + sum(a.size for a in self.atom_a)+len(self.intercept))
    @property
    def dense_equivalent_scalars(self):return int(self.n_atoms*(self.dim+1))
    def _reconstructed_g(self):
        G=[]
        for r,a in zip(self.atom_chart,self.atom_a): G.append(self.chart_base[r]+self.chart_U[r]@a)
        return np.asarray(G)
    def evaluate_eta(self,eta,return_hessian=False):
        x=(np.asarray(eta)-self.center)/self.scale
        L=np.empty(self.n_atoms); G=np.empty((self.n_atoms,self.dim))
        for r in range(len(self.chart_base)):
            ids=np.where(self.atom_chart==r)[0]
            if not len(ids):continue
            U=self.chart_U[r]; base=self.chart_base[r]; z=U.T@x if U.size else np.zeros(0); baseval=base@x
            for m in ids:
                a=self.atom_a[m]; L[m]=baseval+(a@z if a.size else 0.0)+self.intercept[m]; G[m]=base+(U@a if a.size else 0.0)
        s=L/self.tau;a0=s.max();e=np.exp(s-a0);w=e/e.sum();psi=self.tau*(a0+np.log(e.sum()));gx=w@G;q=gx/self.scale
        out={'psi':float(psi),'q':q,'u':float(q[0]),'c':q[1:],'weights':w}
        if return_hessian:
            second=(G.T*w)@G;Hx=(second-np.outer(gx,gx))/self.tau;H=Hx/(self.scale[:,None]*self.scale[None,:]);out['H_eta']=.5*(H+H.T)
        return out
    def evaluate_batch_eta(self,E):
        # Reconstruct once per batch; BLAS dominates and remains faster than Python atom loops.
        G=self._reconstructed_g();X=(np.asarray(E)-self.center)/self.scale;L=X@G.T+self.intercept[None,:]
        s=L/self.tau;a=s.max(1,keepdims=True);e=np.exp(s-a);w=e/e.sum(1,keepdims=True);psi=self.tau*(a[:,0]+np.log(e.sum(1)));gx=w@G;q=gx/self.scale[None,:]
        return psi,q
    def isothermal_view(self,T):
        from .massieu import IsothermalMassieuView
        return IsothermalMassieuView(self,T)

def factorize_acgp_by_local_charts(model,n_charts=4,rank=3,random_state=0):
    X=model.atom_x; G=model.atom_qx
    labels,_=_kmeans_labels(X,min(n_charts,len(X)),random_state)
    bases=[];Us=[]; coeff=[None]*len(X); projected=np.empty_like(G)
    for r in range(labels.max()+1):
        I=np.where(labels==r)[0]; base=G[I].mean(0);D=G[I]-base
        rr=min(rank,D.shape[1],max(0,len(I)-1))
        if rr>0:
            _,U0,_=_pca(D,rr);U=U0.T
            A=D@U; projected[I]=base+A@U.T
        else:
            U=np.zeros((G.shape[1],0));A=np.zeros((len(I),0));projected[I]=base
        bases.append(base);Us.append(U)
        for j,a in zip(I,A):coeff[j]=a
    # Re-anchor every affine atom at its original support potential.
    intercept=model.atom_psi-np.einsum('ij,ij->i',projected,model.atom_x)
    return FactorizedChartACGP(model.center,model.scale,model.tau,bases,Us,labels,coeff,intercept,model.atom_psi,model.atom_x)
