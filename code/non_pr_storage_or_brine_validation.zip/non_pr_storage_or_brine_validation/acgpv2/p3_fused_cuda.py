"""Fused FP64 bounded Massieu inference; no change to the trained potential."""
import numpy as np
import torch

SOURCE=r'''
#define D DIMENSION
#define M ATOMS
#define K SCALES
#define NT 128
#define NH (1+D+D*D)
__device__ void atom(const double* E,const double* center,const double* scale,
 const double* ax,const double* B,const double* r,const double* qa,
 const double* height,int m,double &Q,double* g,double* h,int order) {
 double dx[D],bd[D],v=0.;
 for(int j=0;j<D;j++) dx[j]=(E[j]-center[j])/scale[j]-ax[m*D+j];
 for(int i=0;i<D;i++) { bd[i]=0.;for(int j=0;j<D;j++)bd[i]+=B[(m*D+i)*D+j]*dx[j];v+=bd[i]*dx[i]; }
 v=fmax(v,0.);double rm=r[m],s=sqrt(1.+v/(rm*rm));Q=height[m]+v/(s+1.);
 for(int i=0;i<D;i++){Q+=dx[i]*qa[m*D+i];g[i]=qa[m*D+i]+bd[i]/s;}
 if(order==2)for(int i=0;i<D;i++)for(int j=0;j<D;j++)h[i*D+j]=B[(m*D+i)*D+j]/s-bd[i]*bd[j]/(rm*rm*s*s*s);
}
extern "C" __global__ void bounded(const double* E,const double* center,
 const double* scale,const double* ax,const double* B,const double* r,
 const double* qa,const double* height,const double* tau,const double* lw,
 const double* alpha,const double* gauge,double* p,double* q,double* H,int order){
 int b=blockIdx.x,t=threadIdx.x;const double* e=E+b*D;
 __shared__ double buf[NH*NT];__shared__ double g0[D];
 if(t==0){double Q,h[D*D];atom(e,center,scale,ax,B,r,qa,height,0,Q,g0,h,1);}
 __syncthreads();
 double pp=0.,qq[D],hh[D*D];for(int i=0;i<D;i++)qq[i]=0.;for(int j=0;j<D*D;j++)hh[j]=0.;
 for(int k=0;k<K;k++) {
   double maxval=-1.e300;
   for(int m=t;m<M;m+=NT){double Q,g[D],h[D*D];atom(e,center,scale,ax,B,r,qa,height,m,Q,g,h,1);maxval=fmax(maxval,Q/tau[k]+lw[k*M+m]);}
   buf[t]=maxval;__syncthreads();
   for(int off=NT/2;off>0;off/=2){if(t<off)buf[t]=fmax(buf[t],buf[t+off]);__syncthreads();}
   double mx=buf[0];double sums[NH];for(int j=0;j<NH;j++)sums[j]=0.;__syncthreads();
   for(int m=t;m<M;m+=NT){
     double Q,g[D],h[D*D];atom(e,center,scale,ax,B,r,qa,height,m,Q,g,h,order);
     double w=exp(Q/tau[k]+lw[k*M+m]-mx);sums[0]+=w;
     for(int i=0;i<D;i++){g[i]-=g0[i];sums[1+i]+=w*g[i];}
     if(order==2)for(int i=0;i<D;i++)for(int j=0;j<D;j++)sums[1+D+i*D+j]+=w*(h[i*D+j]+g[i]*g[j]/tau[k]);
   }
   int nsum=order==2?NH:1+D;
   for(int j=0;j<nsum;j++)buf[j*NT+t]=sums[j];__syncthreads();
   for(int off=NT/2;off>0;off/=2){if(t<off)for(int j=0;j<nsum;j++)buf[j*NT+t]+=buf[j*NT+t+off];__syncthreads();}
   double total=buf[0],mu[D];
   for(int i=0;i<D;i++){mu[i]=buf[(1+i)*NT]/total;qq[i]+=alpha[k]*(g0[i]+mu[i]);}
   pp+=alpha[k]*tau[k]*(mx+log(total));
   if(order==2)for(int i=0;i<D;i++)for(int j=0;j<D;j++)hh[i*D+j]+=alpha[k]*(buf[(1+D+i*D+j)*NT]/total-mu[i]*mu[j]/tau[k]);
   __syncthreads();
 }
 if(t==0){p[b]=pp+gauge[0];for(int i=0;i<D;i++)q[b*D+i]=qq[i]/scale[i];
 if(order==2)for(int i=0;i<D;i++)for(int j=0;j<D;j++)H[(b*D+i)*D+j]=hh[i*D+j]/(scale[i]*scale[j]);}
}
'''


class FusedBounded(torch.nn.Module):
    def __init__(self,frozen):
        super().__init__()
        import cupy as cp
        if frozen.scale.device.type!='cuda' or frozen.scale.dtype!=torch.float64:raise ValueError('Fused kernel requires CUDA FP64')
        if frozen.dim>4:raise ValueError('Use the reference kernel for dimension >4')
        self.cp=cp;self.dim=frozen.dim;self.net=frozen
        for key in ['scale','center','atom_x','B','r','qa','target_p','taus','lw','alpha','gauge']:
            self.register_buffer(key,getattr(frozen,key).detach().contiguous().clone())
        source=SOURCE.replace('DIMENSION',str(self.dim)).replace('ATOMS',str(len(self.r))).replace('SCALES',str(len(self.taus)))
        self.kernel=cp.RawKernel(source,'bounded',options=('--std=c++11',))
        self.arrays=[cp.from_dlpack(getattr(self,k)) for k in ['center','scale','atom_x','B','r','qa','target_p','taus','lw','alpha','gauge']]

    def forward(self,E,order=2):
        if torch.is_grad_enabled():raise RuntimeError('FusedBounded is inference only')
        E=E.contiguous();p=torch.empty(len(E),device=E.device,dtype=E.dtype);q=torch.empty_like(E)
        H=torch.empty((len(E),self.dim,self.dim),device=E.device,dtype=E.dtype) if order==2 else torch.empty(1,device=E.device,dtype=E.dtype)
        # Match the active PyTorch stream; DLPack retains zero-copy ownership.
        stream=self.cp.cuda.ExternalStream(torch.cuda.current_stream().cuda_stream)
        with stream:
            args=[self.cp.from_dlpack(E)]+self.arrays+[self.cp.from_dlpack(p),self.cp.from_dlpack(q),self.cp.from_dlpack(H),np.int32(order)]
            self.kernel((len(E),),(128,),tuple(args))
        return p,q,H if order==2 else None
