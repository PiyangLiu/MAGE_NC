"""P3-11: shared-gauge gas/brine bounded MM, independent partition tests."""
from pathlib import Path
import argparse,copy,json,sys,time,os
import numpy as np
import pandas as pd
import torch
from scipy.interpolate import RBFInterpolator
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import benchmark_common
from acgpv2.p3_brine import BrineGibbs,make_reference,R
from acgpv2.bounded_study import geometry,BoundedNet,tensors,loss,restore,evaluate
from acgpv2.massieu import farthest_point_indices
from acgpv2.bounded_curvature import BoundedCurvatureMassieuACGP
from acgpv2.p3_multiphase import MultiphaseKKT
OUT=ROOT/'results/p3/brine/mm';OUT.mkdir(parents=True,exist_ok=True)
BLOCK='none'


class NonvolatileSalt(torch.nn.Module):
    def __init__(self,net,scale):
        super().__init__();self.net=net;self.dim=4
        self.register_buffer('scale',scale.clone())
    def forward(self,E,order=2):
        p,q,H=self.net(E[:,:3],order=order)
        qq=torch.cat([q,torch.zeros_like(p[:,None])],1)
        HH=None
        if order==2:
            HH=torch.zeros((len(E),4,4),device=E.device,dtype=E.dtype);HH[:,:3,:3]=H
        return p,qq,HH


def dataset(teacher,name,count,seed):
    file=OUT/f'{name}_ties.npz'
    if file.exists():return dict(np.load(file))
    rng=np.random.default_rng(seed);rows=[];rejected=[];attempt=0
    while len(rows)<count:
        attempt+=1;T=rng.uniform(295,423);P=np.exp(rng.uniform(np.log(1e6),np.log(45e6)));m=rng.uniform(.05,5.)
        blocked={'T':330<T<355,'P':8e6<P<15e6,'m':2<m<3}.get(BLOCK,False)
        if BLOCK!='none' and blocked!=(name=='test'):continue
        try:
            tie=teacher.coexist(T,P,m)
            for label in ['liquid','gas']:
                H=tie[label]['H'][0];idx=list(range(4)) if label=='liquid' else [0,1,2];s=np.array([1e-4]+[1.]*(len(idx)-1))
                if np.linalg.eigvalsh(H[np.ix_(idx,idx)]*s[:,None]*s[None,:]).min()<=0:raise ValueError('unstable Gibbs Hessian')
            rows.append(tie)
        except Exception as exc:rejected.append(dict(T=T,P=P,m=m,error=str(exc)))
        if len(rows) and len(rows)%128==0:print(name,len(rows),'attempts',attempt,flush=True)
        if attempt>count*50:raise RuntimeError('teacher rejection exceeds allowed rate')
    d={k:np.array([r[k] for r in rows]) for k in ['T','P','m','b','ywater','eta','residual']}
    for label in ['liquid','gas']:
        dlabel={k:np.concatenate([r[label][k] for r in rows]) for k in ['T','P','eta','psi','q','H','rho','h','cp','x']}
        # Tube data perturb homogeneous b, salt, T and P, not just tie contacts.
        if name=='train':
            T=d['T']+rng.uniform(-1,1,count);P=d['P']*np.exp(rng.uniform(-.025,.025,count))
            if label=='liquid':extra=teacher.state(T,P,d['b']*np.exp(rng.uniform(-.3,.3,count)),d['m']*np.exp(rng.uniform(-.1,.1,count)))
            else:extra=teacher.state(T,P,d['ywater']/(1-d['ywater'])*np.exp(rng.uniform(-.2,.2,count)),0.,'gas')
            for k in dlabel:dlabel[k]=np.concatenate([dlabel[k],extra[k]])
        if label=='gas':
            dlabel['eta']=dlabel['eta'][:,:3];dlabel['q']=dlabel['q'][:,:3];dlabel['H']=dlabel['H'][:,:3,:3];dlabel['x']=dlabel['x'][:,:2]
        np.savez_compressed(OUT/f'{name}_{label}.npz',**dlabel)
    np.savez_compressed(file,**d);pd.DataFrame(rejected).to_csv(OUT/f'{name}_rejections.csv',index=False);return d


def train(tr,mo,M=1024,steps=2000):
    files=[OUT/f'{label}_M{M}.npz' for label in ['liquid','gas']]
    if all(p.exists() for p in files):return [restore(BoundedCurvatureMassieuACGP.load(p)) for p in files]
    ds=[dict(np.load(OUT/f'train_{l}.npz')) for l in ['liquid','gas']];ms=[dict(np.load(OUT/f'monitor_{l}.npz')) for l in ['liquid','gas']]
    gauge=torch.nn.Parameter(torch.zeros((),device='cuda',dtype=torch.float64));nets=[]
    for d in ds:
        g=geometry(d);nets.append(BoundedNet(d,g,farthest_point_indices(g['X'],min(M,len(d['T']))),gauge=gauge))
    ts=[tensors(d,'cuda') for d in ds];mt=[tensors(d,'cuda') for d in ms]
    params=list({id(p):p for n in nets for p in n.parameters()}.values());opt=torch.optim.Adam(params,lr=.01)
    rng=np.random.default_rng(46061);history=[];best=None
    def interface(ties):
        e=torch.tensor(ties['eta'],device='cuda');target=torch.tensor(ties['P']/(R*ties['T']),device='cuda')
        p=torch.stack([nets[0](e,1)[0],nets[1](e[:,:3],1)[0]])
        return 3000*((p-target)/target).square().mean()+30000*((p[0]-p[1])/target).square().mean()
    for step in range(1,steps+1):
        val=sum(loss(n,t,torch.tensor(rng.choice(len(t['T']),96,replace=False),device='cuda')) for n,t in zip(nets,ts))+interface(tr)
        opt.zero_grad();val.backward();torch.nn.utils.clip_grad_norm_(params,30);opt.step()
        if step%100==0:
            with torch.no_grad():score=float(sum(loss(n,t,torch.arange(len(t['T']),device='cuda')) for n,t in zip(nets,mt))+interface(mo))
            history.append(dict(step=step,training=float(val.detach()),monitor=score))
            if np.isfinite(score) and (best is None or score<best[0]):best=(score,[copy.deepcopy(n.state_dict()) for n in nets])
            if step%400==0:print('gas-brine',step,score,flush=True)
    for n,s,d,file in zip(nets,best[1],ds,files):n.load_state_dict(s);n.export(d).save(file)
    pd.DataFrame(history).to_csv(OUT/'training.csv',index=False);return nets


def main(args):
    global OUT,BLOCK
    BLOCK=args.block
    if BLOCK!='none':OUT=OUT.parent/'blocked'/BLOCK;OUT.mkdir(parents=True,exist_ok=True)
    ref=ROOT/'results/p3/brine';teacher=BrineGibbs(make_reference(ref/'gibbs_reference.npz',ref/'pitzer_dense.csv'))
    tr=dataset(teacher,'train',512,46061);mo=dataset(teacher,'monitor',128,246061);te=dataset(teacher,'test',512,946061)
    nets=train(tr,mo)
    from acgpv2.p3_cuda_graph import FrozenBounded
    frozen=[FrozenBounded(n) for n in nets]
    if os.environ.get('ACGP_CUDA_KERNEL')=='fused':
        from acgpv2.p3_fused_cuda import FusedBounded
        frozen=[FusedBounded(n) for n in frozen]
    branches=[frozen[0],NonvolatileSalt(frozen[1],nets[0].scale)]
    solver=MultiphaseKKT(branches);rows=[];rng=np.random.default_rng(946062)
    result_file=OUT/'independent_KKT_trace_scaled.csv'
    if result_file.exists():rows=pd.read_csv(result_file).to_dict('records')
    done={int(r['mother']) for r in rows}
    ld=dict(np.load(OUT/'test_liquid.npz'));vd=dict(np.load(OUT/'test_gas.npz'));lt=dict(np.load(OUT/'train_liquid.npz'));vt=dict(np.load(OUT/'train_gas.npz'))
    center=np.array([1/360,np.log(1e7),np.log(2.)]);scale=np.array([.001,.9,1.])
    coordinates=np.column_stack([1/tr['T'],np.log(tr['P']),np.log(tr['m'])])
    interpolation=RBFInterpolator((coordinates-center)/scale,tr['eta'][:,1:],neighbors=32,kernel='thin_plate_spline',smoothing=1e-9)
    for i in range(len(te['T'])):
        if i in done:continue
        l={k:v[i] for k,v in ld.items()};v={k:v[i] for k,v in vd.items()}
        vx=np.r_[v['x'],0.]
        distance=((tr['T']-te['T'][i])/128)**2+np.log(tr['P']/te['P'][i])**2+((tr['m']-te['m'][i])/5)**2;j=int(np.argmin(distance))
        fractions=np.array([.00001,.01,.1,.5,.9,.99,.99999]);feeds=(1-fractions[:,None])*l['x']+fractions[:,None]*vx
        beta0=np.clip((feeds[:,0]-lt['x'][j,0])/(vt['x'][j,0]-lt['x'][j,0]),1e-7,1-1e-7)
        gas_volume=beta0/vt['rho'][j];liquid_volume=(1-beta0)/lt['rho'][j];sg=gas_volume/(gas_volume+liquid_volume)
        guesses=np.column_stack([1-sg,sg])
        water_liquid=np.maximum(feeds[:,1]-beta0*vt['x'][j,1],1e-7)
        mguess=np.clip(feeds[:,2]/(.018015268*water_liquid),.05,5.)
        co=np.column_stack([np.full(len(fractions),1/te['T'][i]),np.full(len(fractions),np.log(te['P'][i])),np.log(mguess)])
        eguess=np.column_stack([np.full(len(fractions),-1/(R*te['T'][i])),interpolation((co-center)/scale)])
        predictions=solver.solve_many(np.full(len(fractions),te['T'][i]),np.full(len(fractions),te['P'][i]),feeds,eguess,initial_S=guesses)
        for beta,out in zip(fractions,predictions):
            rho=1/((1-beta)/l['rho']+beta/v['rho']);h=(1-beta)*l['h']+beta*v['h']
            rows.append(dict(mother=i,T=te['T'][i],P=te['P'][i],m=te['m'][i],beta_teacher=beta,success=out['success'],residual=out['residual'],condition=out['condition'],evaluations=out['evaluations'],beta_error=float(abs(out['beta'][1]-beta)),rho_rel=float(abs(out['rho']-rho)/rho),h_rel=float(abs(out['h']-h)/max(abs(h),100)),liquid_H2_rel=float(abs(out['x'][0,0]-l['x'][0])/l['x'][0]),gas_salt=float(out['x'][1,2])))
        if (i+1)%32==0:
            pd.DataFrame(rows).to_csv(result_file,index=False);print('gas-brine test mothers',i+1,flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(result_file,index=False)
    result=dict(states=len(rows),independent_mothers=512,shared_gauge=[float(50*n.raw_gauge.detach()) for n in nets],gas_salt_max=float(abs(frame.gas_salt).max()),KKT_success=float(frame.success.mean()),beta_MAE=float(frame.beta_error.mean()),rho_mean_rel=float(frame.rho_rel.mean()),h_mean_rel=float(frame.h_rel.mean()),liquid_H2_mean_rel=float(frame.liquid_H2_rel.mean()),teacher='Single extensive Gibbs: HEOS references, Pitzer activities, published hydrogen Henry/salt/partial-volume correlation',limitations='Neutral conserved NaCl formula unit. Gas H2 is virial approximation, not full mixture HEOS; salt caloric reference unvalidated. Independent experimental validation is separate script 45.')
    (OUT/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--block',choices=['none','T','P','m'],default='none');main(ap.parse_args())
