# Non-PR gas--brine validation

This folder is a bounded validation example for the organization used by MAGE. The reference model is one extensive Gibbs potential. Its derivatives provide pressure, chemical potentials, internal energy, and the state-response tensors used by the finite-support branches. A separate gas--brine coexistence solve enforces the shared chemical-potential conditions.

The model is intentionally scoped. It uses a neutral conserved NaCl formula unit, Pitzer activity data, HEOS water/H2 reference fits, and a low-density H2 gas approximation. It is therefore not a complete reactive electrolyte CPA, Pitzer geochemical simulator, or salt-precipitation model. The package does not claim those effects. The retained KKT summary is included to show the existing finite-support branch calculation; `run_brine_validation.py` independently checks the derivative chain and representative coexistence residuals.

Run with:

```text
python run_brine_validation.py
```

The output `brine_validation_summary.json` reports the direct finite-difference derivative audit, coexistence residuals, and the retained independent KKT metrics.
