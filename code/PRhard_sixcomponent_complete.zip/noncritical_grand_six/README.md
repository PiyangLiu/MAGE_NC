# Independent noncritical PR-hard equilibrium benchmark (MAGE vs PR)

This package contains a **new** thermodynamic test case, unrelated to the
user's six-cell ternary porous-medium flow example. It benchmarks two
independently implemented compiled **equilibrium solvers with identical inputs
and outputs**. It is a fixed-temperature, fixed-component-chemical-potential
(*grand-canonical*, or prescribed fugacity) test, **not** a conventional `TPz`
flash. The challenge for the PR EOS is that it must invert both liquid and
vapour thermodynamic branches numerically; the MAGE branch representation
evaluates both pressures and gradients directly.

## Thermodynamics and noncriticality

Mixture at **300 K**: `CH4 / C2H6 / C3H8 / nC4 / nC5 / nC6` with the
identical classical Peng–Robinson EOS and **zero** binary interaction
parameters in both solvers. Critical temperatures, pressures and acentric
factors are explicit in `pr_six.py` and `pr_six.cpp`.

Input to **both** programs: six dimensionless chemical coordinates

\[
\eta_i=\log(x_i p/p^\circ)+\log\phi_i^{\rm PR}(T,p,\mathbf{x}),\qquad
p^\circ=10^5\ {\rm Pa}.
\]

Output from **both** programs: liquid and vapour branch pressures
`p_L,p_V`, all six component number densities on each branch, their two PR
compressibility factors `Z_L,Z_V`, and stable phase. The stable phase at
fixed fugacities is the branch with **higher pressure**, because the grand
potential is `-pV`. PR directly solves **two 6×6 nonlinear inverse EOS
problems** per query; no PR EOS is altered or handicapped. MAGE evaluates
two learned branches, selecting the higher pressure without a local flash.

Queries are sampled from a prescribed, two-intrinsic-parameter manifold:

- Select a pressure on a genuine six-component PR coexistence tie-line at
  1.95–2.75 MPa, using anchor overall composition
  `(0.46,0.12,0.08,0.12,0.11,0.11)`.
- Perturb only the *n-hexane chemical coordinate* by a positive or negative
  magnitude 0.012–0.030. Both stability labels are represented.
- At all 1,000 confirmatory test points, the exact PR liquid compressibility
  root is between **0.0733 and 0.1161**; the vapour root between **0.8873
  and 0.9120**. The smallest absolute branch-pressure gap is **0.06927 MPa**.
  The test uses neither critical nor nearly coincident phase roots.

The restriction to a two-parameter chemical-potential manifold is part of
the declared benchmark; these results **do not** establish accuracy or a
fixed support count over the entire six-dimensional composition space.

## Model selection and independent confirmation

Three originally separate pseudo-random streams plus a new confirmatory
stream are included:

| Split | Count | Seed | Role |
|---|---:|---:|---|
| Candidate | 1,200 | 880101 | PR tangent support pool |
| Validation | 360 | 880102 | Greedy support index selection |
| Pilot held-out | 800 | 880103 | Development implementation checks |
| **Confirmatory held-out** | **1,000** | **880104** | **Only population for final headline metrics** |

The model stores **128 exact PR tangent supports per phase**, selected by a
frozen deterministic validation-greedy rule. The two phases share a common
thermodynamic gauge and identical potential normalisation. No phase-specific
offset is calibrated from the test data. The dimensionless smoothing parameter
is `0.00004`, equivalent to a physical Massieu smoothing scale of
`0.04 mol/m3` given the specified potential scale.

## Audited confirmatory results

All 1,000 confirmatory points passed the independent PR–MAGE state checks:

| Metric | Verified value |
|---|---:|
| Confirmatory liquid / vapour stable queries | 499 / 501 |
| **MAGE exact stable-phase labels** | **1,000/1,000 (100%)** |
| PR analytical-Jacobian exact stable-phase labels | 1,000/1,000 |
| Mean / maximum MAGE branch-pressure relative error | 0.0181% / 0.0514% |
| Mean / maximum relative component number-density error | 0.2590% / 5.413% |
| Maximum MAGE compressibility-factor absolute error | 0.00502 |
| PR compiled analytic vs Python PR maximum pressure relative error | 4.94e-10 |
| PR compiled analytic vs Python PR maximum relative density error | 6.28e-11 |
| PR analytic Jacobian finite-difference audit | 48 points, relative Frobenius discrepancy at most 1.86e-9 |
| Compiled MAGE vs Python potential-pressure discrepancy | less than 6e-16 |

The maximum density *relative* error occurs in the **dilute vapour n-hexane
component**; the maximum mean error is much smaller. The test does not claim
machine-exact pressure/density agreement from finite supports.

### Compilation and repeated timings

Four PR variants are evaluated: warm-start continuation or cold-start
independent inversions, each with either a local numerical Jacobian or a
hand-implemented **analytic PR fugacity Jacobian** (the latter differentiates
the cubic EOS roots implicitly). For fairness the best-performing
independently measured PR variant is used in the headline ratio. Both PR and
MAGE are C++17 `-O3` code with the same query input and exact output contract.

| Compiled solver | Median of 5 repeats, µs/query |
|---|---:|
| **MAGE direct dual-branch evaluation** | **1.901** |
| PR analytic Jacobian, independent cold start (fastest PR) | 7.246 |
| PR analytic Jacobian, warm continuation | 7.326 |
| PR finite-difference Jacobian, independent cold start | 13.513 |
| PR finite-difference Jacobian, warm continuation | 14.065 |

**Speed advantage MAGE over the fastest measured PR: 3.81×** at 100% phase
classification agreement. The PR analytical method required a median of
seven Newton steps total across both phases, with **16 actual PR EOS
evaluations** per query, compared with a direct evaluation of 128 MAGE
tangent supports on each phase. Every query converged to the independent
reference state to the published numerical tolerances.

The five complete timing vectors and every confirmed physical state are in
`results/verified_benchmark.json` and `results/heldout_all_states.csv`.
Wall times are hardware- and load-dependent; the raw timing vectors have
noticeable variation. The observed speedup applies **only** to this native
grand-canonical task, not to industrial `TPz` flash speed in general.

### Offline cost

Generating the PR coexistence anchors plus **candidate and validation
reference states** consumed **12.39 seconds**; validation-greedy support
selection consumed another **0.27 seconds**. From the five-repeat median
per-query difference, amortising these model-construction costs requires
approximately **2.37 million queries**. The separate pilot and confirmatory
populations required additional time; generating *all four* independent
streams and the coexistence anchors took **24.50 seconds**, giving a more
conservative whole-experiment-equivalent break-even of **4.64 million queries**.
Independent evaluation data generation is not a necessary recurring model
construction cost. Model design and deployment/data-management overheads are
also not included. The benchmark demonstrates an online advantage, not an
automatic end-to-end speed advantage for one-off or short calculations.

## Reproduction (all source and inputs included)

Python 3.12, `numpy`, `scipy`, `pandas`, `matplotlib`, and a C++17 compiler
(archived compiler GCC 14.2.0). Run from this folder:

```bash
python -m pip install -r requirements.txt

g++ -std=c++17 -O3 -fPIC -shared pr_six.cpp -o libpr_six.so
g++ -std=c++17 -O3 -DANALYTIC_JAC -fPIC -shared pr_six.cpp -o libpr_six_analytic.so
g++ -std=c++17 -O3 -fPIC -shared mage_six.cpp -o libmage_six.so

export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python generate.py
python fit.py --supports 128
python audit.py
python benchmark.py
python plot.py
```

`benchmark.py` terminates with a nonzero exit if **any** of the 1,000
confirmatory phase labels disagrees, if the compiled PR result fails parity
with independent Python PR, or if specified continuous-state error bounds
are not met. The C++ binaries can be recompiled; included `.so` files are
only a convenience for the original Linux x86-64 environment.

## Scientific limits (please retain when submitting)

1. The PR solver here is substantially more optimized than a naive Python
   flash: analytic cubic roots, damped Newton, line search, fugacity root
   derivatives, tested continuation, and fully compiled EOS. **It has not
   been externally validated against proprietary industrial PR software.**
2. The challenge is the **six-dimensional fugacity/chemical-potential inverse
   specification** and the need to recover two physical EOS branches; it is
   not a manufactured near-critical ill-conditioning or an assertion that PR
   is generally slow for ordinary `TPz` inputs.
3. The MAGE supports approximate only the sampled two-parameter state
   manifold. Changing the physical domain or adding independent mixture
   dimensions may require support reconstruction and greater cost.
4. A 100% finite held-out label agreement is not a proof of phase-margin
   correctness at every possible point, particularly arbitrarily close to
   coexistence where the phase-pressure gap vanishes.
5. Benchmark CPU variation, cache effects, and hardware portability require
   additional studies if the manuscript makes broad performance claims.

