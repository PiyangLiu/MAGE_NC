"""Build and run the unified-support ternary fully implicit benchmark.

The first 512 atoms are an explicit physical-coverage bootstrap inherited
from the validated teacher representation. The remaining atoms are appended
from the common validation-error greedy order. All outputs stay below this
directory.
"""
from pathlib import Path
import json, sys
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
AUTH = HERE.parent / "figure5_ternary_fully_implicit"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(AUTH / "src"))
from unified_support_selection import save_json
from run_benchmark import compare
from solvers import MAGEGlobalSolver, PRGlobalSolver


def _shared_offset(pool, orders, tau):
    diffs = []
    for ph in ("liquid", "vapor"):
        eta = pool[f"{ph}_eta"]; phi = pool[f"{ph}_phi"]; q = pool[f"{ph}_q"]; ids = orders[ph]
        se, sf, sq = eta[ids], phi[ids], q[ids]
        vals = []
        for first in range(0, len(phi), 256):
            E = eta[first:first + 256]
            logits = sf[None, :] + np.einsum("nmd,md->nm", E[:, None, :] - se[None, :, :], sq)
            scaled = logits / tau
            m = np.max(scaled, axis=1, keepdims=True)
            vals.append(tau * (m[:, 0] + np.log(np.exp(scaled - m).sum(1)) - np.log(len(ids))))
        diffs.append(phi - np.concatenate(vals))
    return float(np.mean(np.concatenate(diffs)))


def _legacy_gap_order(pool, ph, base, count):
    eta=pool[f"{ph}_eta"]; phi=pool[f"{ph}_phi"]; q=pool[f"{ph}_q"]
    order=list(map(int,base[f"support_order_{ph}"])); chosen=np.zeros(len(phi),bool); chosen[order]=True
    max_line=np.full(len(phi),-np.inf)
    for j in order: max_line=np.maximum(max_line,phi[j]+(eta-eta[j])@q[j])
    while len(order)<min(count,len(phi)):
        gap=phi-max_line; gap[chosen]=-np.inf; j=int(np.argmax(gap)); order.append(j); chosen[j]=True
        max_line=np.maximum(max_line,phi[j]+(eta-eta[j])@q[j])
    return order


def build_model(order_data, tau=0.5, bootstrap_prefix=1024):
    pool = np.load(AUTH / "teacher" / "ternary_branch_pools.npz")
    base = json.loads((AUTH / "teacher" / "original_ternary_summary.json").read_text())
    orders = {}
    for ph in ("liquid", "vapor"):
        raw = list(map(int, order_data[ph]["support_order"]))
        prefix = _legacy_gap_order(pool, ph, base, bootstrap_prefix)
        seen = set(prefix)
        orders[ph] = np.asarray((prefix + [j for j in raw if j not in seen])[:1280], int)
    offset = _shared_offset(pool, orders, tau)
    model_dir = HERE / "ternary_model"
    result_dir = HERE / "results" / "ternary_flow_authoritative"
    model_dir.mkdir(parents=True, exist_ok=True); result_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(model_dir / "mage_ternary_1280.npz",
                        liquid_eta=pool["liquid_eta"][orders["liquid"]],
                        liquid_phi=pool["liquid_phi"][orders["liquid"]],
                        liquid_q=pool["liquid_q"][orders["liquid"]],
                        vapor_eta=pool["vapor_eta"][orders["vapor"]],
                        vapor_phi=pool["vapor_phi"][orders["vapor"]],
                        vapor_q=pool["vapor_q"][orders["vapor"]])
    save_json(model_dir / "mage_model_summary.json", {
        "supports_per_phase": 1280, "tau": tau, "shared_phi_offset": offset,
        "support_selection": f"{bootstrap_prefix}-point physical-coverage bootstrap plus unified validation-error greedy extension",
        "bootstrap_prefix": bootstrap_prefix, "flow_trajectory_used_for_support_selection": False,
        "support_order_liquid": orders["liquid"].tolist(),
        "support_order_vapor": orders["vapor"].tolist()})
    return orders, model_dir, result_dir, offset


def main():
    selected = json.loads((HERE / "results" / "ternary_flow_selection.json").read_text())
    bootstrap = int(__import__("os").environ.get("UNIFIED_TERNARY_BOOTSTRAP", "1024"))
    orders, model_dir, result_dir, offset = build_model(selected["branches"], bootstrap_prefix=bootstrap)
    grid = pd.read_csv(AUTH / "time_grid.csv")
    mage = MAGEGlobalSolver(AUTH / "benchmark_config.json", model_dir)
    pr = PRGlobalSolver(AUTH / "benchmark_config.json")
    M, ME, MM, MS = mage.run(grid, result_dir)
    P, PE, PM, PS = pr.run(grid, result_dir)
    C, CS = compare(M, P, ME, PE)
    C.to_csv(result_dir / "combined_global_states.csv", index=False)
    evcols = ["accepted_step", "cell", "from_phase", "to_phase"]
    ME.merge(PE, on=evcols, how="outer", suffixes=("_mage", "_pr"), indicator=True).to_csv(result_dir / "combined_phase_events.csv", index=False)
    summary = {"benchmark": json.loads((AUTH / "benchmark_config.json").read_text()),
               "support_selection": {"algorithm": "validation-controlled thermodynamic-error greedy", "bootstrap_prefix": bootstrap, "supports_per_phase": 1280, "tau": 0.5, "shared_phi_offset": offset, "flow_trajectory_used": False, "orders": {k: v.tolist() for k, v in orders.items()}},
               "MAGE_solver": MS, "PR_solver": PS, "comparison": CS}
    save_json(result_dir / "summary.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
