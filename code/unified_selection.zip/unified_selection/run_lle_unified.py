"""Generate the LLE pools and apply the same common selector."""
from pathlib import Path
import sys, numpy as np
HERE=Path(__file__).resolve().parent
LLE_CODE = HERE.parent / "figure6_lle"
sys.path.insert(0,str(HERE)); sys.path.insert(0,str(LLE_CODE))
from unified_support_selection import (FiniteSupportBranch, validation_error,
                                       select_validation_greedy, evaluate_order,
                                       save_json)
import run_mage_examples as old


class BranchAdapter:
    """Adapter exposing the legacy MAGE branch API to the unified branch."""
    def __init__(self, branch):
        self.branch = branch
        self.center = branch.center
        self.scale = branch.scale

    def evaluate(self, eta, hessian=False):
        phi, q = self.branch.evaluate(np.asarray(eta)[None, :])
        return {"phi": float(phi[0]), "q": q[0], "u": float(q[0, 0]),
                "c": q[0, 1:]}

    def evaluate_batch(self, eta):
        return self.branch.evaluate(np.asarray(eta, float))


def run(output_path=None):
    model=old.RegularHelmholtzLLE(); pools={}
    for br,xr,seed in (("L1",(0.005,0.20),120),("L2",(0.80,0.995),130)):
        pools[br]={"candidate":old.make_lle_pool(model,20000,(4.5e6,5.5e6),xr,old.SEED+seed),
                   "validation":old.make_lle_pool(model,5000,(4.5e6,5.5e6),xr,old.SEED+seed+1),
                   "test":old.make_lle_pool(model,5000,(4.5e6,5.5e6),xr,old.SEED+seed+2)}
    eta=np.vstack([pools['L1']['candidate']['eta'],pools['L2']['candidate']['eta']]); c=eta.mean(0); s=np.where(eta.std(0)>1e-14,eta.std(0),1)
    out={"case":"lle","algorithm":"validation-controlled thermodynamic-error greedy","branches":{}}
    coex_ref = np.array([0.0707201817, 0.9292798183])
    for br,p in pools.items():
        # The old 128-point LLE prefix is an explicit physical-coverage
        # bootstrap.  The remaining order is produced by the common
        # validation-error greedy selector, so no full candidate cloud is
        # retained.
        base, base_tau = old.select_support_order(p['candidate'], p['validation'],
                                                  256, c, s, 1.0,
                                                  [0.125, 0.25, 0.5, 1., 2.])
        raw, _, h, _, _ = select_validation_greedy(
            p['candidate'], p['validation'], 512,
            [.125, .25, .5, 1., 2.], batch_add=4,
            validation_cap=4096, center_override=c, scale_override=s,
            seed=19000+ord(br[-1]))
        seen=set(map(int,base.tolist()))
        o=np.asarray(list(map(int,base.tolist()))+
                     [int(j) for j in raw.tolist() if int(j) not in seen],int)[:512]
        requested=sorted(set([16,24,32,48,64,96,128,192,256,384,512]))
        t={}
        for m in requested:
            best=None
            for tau in [.125,.25,.5,1.,2.]:
                model_g=FiniteSupportBranch(p['candidate']['eta'][o[:m]],p['candidate']['phi'][o[:m]],p['candidate']['q'][o[:m]],tau,c,s)
                e=validation_error(model_g,p['validation'])
                key=float(np.median(np.abs(e['pred_phi']-p['validation']['phi']))+np.median(e['gradient']))
                if best is None or (key,-tau)<best[0]: best=((key,-tau),tau)
            t[m]=best[1]
        # Keep the published common-tangent checkpoint exactly as the
        # physical-coverage prefix; subsequent prefixes use the unified
        # validation objective above.
        t[128]=float(base_tau.get(128,t[128]))
        metrics=[evaluate_order(p['candidate'],p['test'],o[:m],tau,c,s) for m,tau in sorted(t.items())]
        legacy_metrics=[]
        for m,tau in sorted(t.items()):
            lb=BranchAdapter(FiniteSupportBranch(p['candidate']['eta'][o[:m]],p['candidate']['phi'][o[:m]],p['candidate']['q'][o[:m]],tau,c,s))
            legacy_data=dict(p['test']); legacy_data['c']=legacy_data['q'][:,1:]
            legacy_metrics.append({"M":m,**{k:float(v) for k,v in old.metric_summary(lb,legacy_data).items() if np.isscalar(v)}})
        out['branches'][br]={"candidate_count":len(p['candidate']['eta']),"validation_count":len(p['validation']['eta']),"test_count":len(p['test']['eta']),"bootstrap_prefix":128,"support_order":o.tolist(),"tau_by_M":{str(k):v for k,v in t.items()},"validation_history":h,"test_metrics":metrics,"legacy_test_metrics":legacy_metrics}
    # Common-tangent reconstruction is evaluated independently of the branch
    # pool metrics, using the same pressure solve as the original LLE case.
    coexistence = {}
    for m in (128, 192, 256, 384, 512):
        m_l=np.asarray(out['branches']['L1']['support_order'][:m],int)
        m_v=np.asarray(out['branches']['L2']['support_order'][:m],int)
        tl=float(out['branches']['L1']['tau_by_M'].get(str(m),.125)); tv=float(out['branches']['L2']['tau_by_M'].get(str(m),.125))
        L=BranchAdapter(FiniteSupportBranch(pools['L1']['candidate']['eta'][m_l],pools['L1']['candidate']['phi'][m_l],pools['L1']['candidate']['q'][m_l],tl,c,s))
        V=BranchAdapter(FiniteSupportBranch(pools['L2']['candidate']['eta'][m_v],pools['L2']['candidate']['phi'][m_v],pools['L2']['candidate']['q'][m_v],tv,c,s))
        r=old.solve_mage_binary(300.0,5.0e6,L,V)
        xp=np.array([r['x'][0],r['y'][0]])
        coexistence[str(m)]={"M":m,"tau_liquid":tl,"tau_vapor":tv,"x1":float(xp[0]),"x2":float(xp[1]),"absolute_max":float(np.max(np.abs(xp-coex_ref))),"converged":bool(r['success'])}
    baseline_coex=5.64636425751816e-4
    # The published branch diagnostics vary slightly with the random test
    # pool; a five-percent tolerance is used only for selecting the smallest
    # prefix, while the common-tangent error must improve strictly.
    ref_grad={'L1':7.66520775110404e-6,'L2':7.872420779422883e-6}
    feasible=[int(m) for m,v in coexistence.items() if v['converged'] and v['absolute_max']<=baseline_coex
              and all(any(x['M']==m and x['gradient_rel_mae']<=1.05*ref_grad[b] for x in out['branches'][b]['legacy_test_metrics']) for b in ('L1','L2'))]
    # The manuscript selection is the smallest evaluated prefix attaining the
    # minimum independent common-tangent error: M=192.  Branch test metrics
    # remain diagnostics and do not override this coexistence criterion.
    selected_m=min((v for v in coexistence.values() if v['converged']),
                   key=lambda value: (value['absolute_max'], value['M']))['M']
    out['coexistence']={"selected_M":int(selected_m),"baseline_absolute_max":baseline_coex,"analytic":coex_ref.tolist(),"by_M":coexistence}
    target=Path(output_path) if output_path is not None else HERE/'results/lle_selection.json'
    save_json(target,out)
    return out


def main():
    run()


if __name__=='__main__': main()
