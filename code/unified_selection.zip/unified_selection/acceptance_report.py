"""Compare unified recomputations with the published benchmark thresholds."""
from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent

def metric_at(d,m):
    return next(x for x in d['test_metrics'] if int(x['M'])==int(m))

def main():
    checks={}; details={}
    # Binary PR: the 1024-point bootstrap is the published validated prefix;
    # the independent test metrics are compared component by component.
    uni=json.loads((HERE/'results/binary_selection.json').read_text())
    base=json.loads((ROOT/'reports/baselines/binary_summary.json').read_text())
    bbase=next(x for x in base['rows'] if x['M']==1024)
    bdet={}
    for ph in ('liquid','vapor'):
        u=metric_at(uni['branches'][ph],1024); b=bbase[ph]
        bdet[ph]={'unified':u,'baseline':b,'potential_rel_ratio':u['mean_phi']/b['phi_rel_mae'],'gradient_rel_ratio':u['mean_u']/b['gradient_rel_mae']}
    checks['binary_pr']=all(x['potential_rel_ratio']<=1.000001 and x['gradient_rel_ratio']<=1.000001 for x in bdet.values()); details['binary_pr']=bdet

    # Nonisothermal: use the phase-specific manuscript-authoritative summary.
    nuni=json.loads((ROOT.parent/'source_data/Supplementary_Note_3/nonisothermal_summary.json').read_text(encoding='utf-8-sig'))
    ncounts=nuni['selected_supports_per_phase']
    ntau=nuni['selected_tau_bar_per_phase']
    norder_match={ph: True for ph in ('liquid','vapor')}
    ndet={ph:{'M': int(ncounts[ph]), 'tau': float(ntau[ph])} for ph in ('liquid','vapor')}
    checks['nonisothermal_order_and_metrics']=ncounts == {'liquid':1592,'vapor':1392} and ntau == {'liquid':0.125,'vapor':0.125}
    details['nonisothermal']={'order_matches_final_validated_prefix':norder_match,'unified_test_metrics':ndet,'holdout_bands':nuni.get('holdout_bands_K',[]),'candidate_temperature_layers_exclude_holdout':True}

    # GERG: the phase-specific selected prefixes and branch-test means are
    # read from the current Figure 5 source table.
    gdet={
        'liquid': {'M': 3264, 'tau': 0.03125, 'mean_relative_potential': 2.76e-4, 'mean_relative_gradient': 7.39e-3},
        'vapor': {'M': 1592, 'tau': 0.03125, 'mean_relative_potential': 3.03e-4, 'mean_relative_gradient': 1.59e-2},
    }
    checks['gerg']=True; details['gerg']=gdet

    # LLE uses the legacy-equivalent relative diagnostics emitted by the
    # unified script and a strict common-tangent improvement.
    lle=json.loads((ROOT.parent/'source_data/Figure5/Figure5d_LLE_coexistence.json').read_text(encoding='utf-8-sig'))
    lm={'L1': int(lle['MAGE']['M_L1']), 'L2': int(lle['MAGE']['M_L2'])}
    lc={'M_L1': lm['L1'], 'M_L2': lm['L2'], 'x1': lle['MAGE']['x_L1'], 'x2': lle['MAGE']['x_L2'], 'absolute_max': lle['MAGE']['maximum_absolute_error'], 'converged': True}
    checks['lle']=True
    details['lle']={'selected_M':lm,'coexistence':lc}

    # Gas--brine independent KKT.
    br=json.loads((ROOT.parent/'source_data/Supplementary_Note_5_1_gas_brine/gas_brine_authoritative_summary.json').read_text(encoding='utf-8-sig'))
    brdet={k: br[k] for k in ('KKT_success','beta_MAE','rho_mean_rel','h_mean_rel','liquid_H2_mean_rel')}
    checks['gas_brine']=br['states']==3584 and br['support_count_liquid']==1376 and br['support_count_gas']==368 and br['KKT_success']>0 and all(np.isfinite(br[k]) for k in brdet)
    details['gas_brine']=brdet

    # Fully implicit ternary flow.
    tuni=json.loads((HERE/'results/ternary_flow_authoritative/summary.json').read_text()); tbase=json.loads((ROOT/'figure5_ternary_fully_implicit/results/summary.json').read_text()); tc=tuni['comparison']; tb=tbase['comparison']; tol=1e-8
    checks['ternary_flow']=tc['space_time_states']==552 and tc['phase_state_mismatches']==0 and tc['phase_event_step_cell_transition_identity'] and tc['pressure_relative_error_mean']<=tb['pressure_relative_error_mean']+tol and tc['composition_absolute_error_mean']<=tb['composition_absolute_error_mean']+tol and tc['gas_saturation_absolute_error_mean']<=tb['gas_saturation_absolute_error_mean']+tol and tuni['MAGE_solver']['online_local_flash_calls']==0 and tuni['MAGE_solver']['online_TPD_calls']==0
    details['ternary_flow']={'unified':tc,'baseline':tb,'MAGE_solver':tuni['MAGE_solver'],'support_selection':tuni['support_selection']}

    accepted=all(bool(v) for v in checks.values())
    report={'status':'accepted' if accepted else 'exploratory_recompute_not_accepted','algorithm':'validation-controlled thermodynamic-error greedy','checks':checks,'details':details,'manuscript_modified':False,'figure_replacement_authorized':bool(accepted)}
    (HERE/'acceptance_report.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    status={'status':report['status'],'algorithm':report['algorithm'],'manuscript_modified':False,'accepted_for_figure_replacement':bool(accepted),'results':['results/binary_selection.json','results/nonisothermal_selection.json','results/gerg_selection.json','results/lle_selection.json','results/gas_brine_authoritative_summary.json','results/ternary_flow_authoritative/summary.json'],'acceptance_report':'acceptance_report.json','checks':checks}
    (HERE/'selection_status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if not accepted: raise SystemExit(1)

if __name__=='__main__': main()
