"""One support-selection algorithm for all MAGE benchmark branches.

The selector is deliberately independent of the reference EOS.  A case only
has to provide candidate and validation arrays with ``eta``, ``phi`` and
``q`` fields.  Supports are selected branch by branch using the largest
normalized validation thermodynamic error, while optional strata protect
coexistence and other narrow manifolds from being overwhelmed by bulk states.
"""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np


class FiniteSupportBranch:
    def __init__(self, eta, phi, q, tau, center, scale, offset=0.0):
        self.eta = np.asarray(eta, float)
        self.phi = np.asarray(phi, float)
        self.q = np.asarray(q, float)
        self.tau = float(tau)
        self.center = np.asarray(center, float)
        self.scale = np.where(np.abs(np.asarray(scale, float)) > 1e-14,
                              np.asarray(scale, float), 1.0)
        self.offset = float(offset)
        z = (self.eta - self.center) / self.scale
        self.qx = self.q * self.scale[None, :]
        self.intercept = self.phi - np.sum(self.qx * z, axis=1)

    def evaluate(self, eta):
        E = np.asarray(eta, float)
        out_phi, out_q = [], []
        chunk = max(1, int(4_000_000 // max(len(self.phi), 1)))
        for i in range(0, len(E), chunk):
            z = (E[i:i + chunk] - self.center) / self.scale
            s = (z @ self.qx.T + self.intercept[None, :]) / self.tau
            m = np.max(s, axis=1, keepdims=True)
            w = np.exp(s - m)
            den = np.sum(w, axis=1, keepdims=True)
            w /= den
            out_phi.append((self.tau * (m[:, 0] + np.log(den[:, 0])
                             - np.log(len(self.phi))) + self.offset))
            out_q.append((w @ self.qx) / self.scale[None, :])
        return np.concatenate(out_phi), np.vstack(out_q)


def _relative(pred, ref, floor=1e-12):
    return np.abs(pred - ref) / np.maximum(np.abs(ref), floor)


def validation_error(model, data, weights=(1.0, 1.0, 1.0)):
    phi, q = model.evaluate(data["eta"])
    ep = _relative(phi, data["phi"], 1e-12)
    # Scale each derivative component by its validation range.  This prevents
    # density magnitude from hiding composition or caloric errors.
    qr = np.ptp(data["q"], axis=0)
    qr = np.where(qr > 1e-14, qr, 1.0)
    eq = np.linalg.norm((q - data["q"]) / qr[None, :], axis=1)
    eu = _relative(q[:, 0], data["q"][:, 0], 1e-8)
    ec = np.linalg.norm((q[:, 1:] - data["q"][:, 1:]) /
                        qr[None, 1:], axis=1) if q.shape[1] > 1 else eq
    # Selection score follows the same physical normalization for every case:
    # absolute potential error in the declared Phi scale plus range-scaled
    # derivative errors.  The relative diagnostics above remain available for
    # reporting, but are not allowed to over-weight near-zero components.
    score = weights[0] * ((phi - data["phi"]) ** 2) + weights[1] * ((q[:, 0] - data["q"][:, 0]) / qr[0]) ** 2
    if q.shape[1] > 1:
        score += weights[2] * np.mean(((q[:, 1:] - data["q"][:, 1:]) /
                                       qr[None, 1:]) ** 2, axis=1)
    return {"score": score, "phi": ep, "gradient": eq, "u": eu,
            "composition": ec, "pred_phi": phi, "pred_q": q}


def _initial_indices(candidate, protected=None, strata=None, center=None, scale=None,
                     protected_limit=16):
    # Use the common coordinate scaling for distances, but use the current
    # branch cloud centroid for the central seed.  This preserves one shared
    # representation while avoiding a branch-dependent shift of the first
    # support when the two phase clouds have different compositions.
    c = candidate["eta"].mean(0)
    s = np.where(candidate["eta"].std(0) > 1e-14, candidate["eta"].std(0), 1.0) if scale is None else scale
    X = (candidate["eta"] - c) / s
    ids = []
    for j in range(X.shape[1]):
        ids.extend([int(np.argmin(X[:, j])), int(np.argmax(X[:, j]))])
    ids.append(int(np.argmin(np.sum(X * X, axis=1))))
    if protected is not None:
        p = np.asarray(protected, bool)
        members = np.flatnonzero(p)
        # Protection is a coverage seed, not a request to retain the whole
        # manifold.  Keeping every protected point would silently reproduce
        # the old uncompressed nonisothermal construction.
        if len(members):
            # The caller controls the number of mandatory manifold coverage
            # seeds.  The previous hard-coded 16-point cap silently discarded
            # the complete 45-point binary VLE curve even when the requested
            # protection limit was 45.
            take = min(max(int(protected_limit), 0), len(members))
            ids.extend(members[np.linspace(0, len(members) - 1, take).round().astype(int)].tolist())
    if strata is not None:
        s = np.asarray(strata)
        for label in np.unique(s):
            members = np.flatnonzero(s == label)
            if len(members):
                ids.append(int(members[0]))
                if len(members) > 1:
                    ids.append(int(members[len(members) // 2]))
    return list(dict.fromkeys(ids))


def select_validation_greedy(candidate, validation, max_m, tau_grid,
                             protected=None, strata=None, weights=(1., 1., 1.),
                             batch_add=1, validation_cap=4096, seed=0,
                             center_override=None, scale_override=None,
                             protected_limit=16, coverage_seed_count=0,
                             candidate_error_weight=0.0, candidate_probe=256):
    """Return one nested validation-error support order and tau choices.

    The same routine is used for PR, GERG, LLE, nonisothermal and gas--brine
    branches.  For large validation pools a deterministic subset is used only
    to make the offline search tractable; final metrics always use the full
    independent pools.
    """
    rng = np.random.default_rng(seed)
    val = validation
    if len(val["eta"]) > validation_cap:
        ix = np.sort(rng.choice(len(val["eta"]), validation_cap, replace=False))
        val = {k: (v[ix] if isinstance(v, np.ndarray) and len(v) == len(validation["eta"]) else v)
               for k, v in validation.items()}
    center = np.asarray(candidate["eta"].mean(0) if center_override is None else center_override, float)
    scale = np.where(candidate["eta"].std(0) > 1e-14, candidate["eta"].std(0), 1.0) if scale_override is None else np.asarray(scale_override, float)
    # Limit the protected prefix without retaining an entire narrow manifold.
    if protected is not None and protected_limit is not None:
        p = np.flatnonzero(np.asarray(protected, bool))
        limited = np.zeros(len(protected), bool)
        if len(p):
            take = min(int(protected_limit), len(p))
            if take == len(p):
                limited[p] = True
            else:
                limited[p[np.linspace(0, len(p) - 1, take).round().astype(int)]] = True
        protected = limited
    order = _initial_indices(candidate, protected, strata, center, scale,
                             protected_limit=protected_limit)
    if coverage_seed_count:
        X = (candidate["eta"] - center) / scale
        chosen = set(order)
        if order:
            d = np.sum((X - X[order[0]]) ** 2, axis=1)
        else:
            d = np.sum((X - X.mean(0)) ** 2, axis=1)
        for _ in range(min(int(coverage_seed_count), len(X) - len(order))):
            d[list(chosen)] = -np.inf
            j = int(np.argmax(d)); order.append(j); chosen.add(j)
            d = np.minimum(d, np.sum((X - X[j]) ** 2, axis=1))
    order = order[:min(max_m, len(candidate["eta"]))]
    selected = set(order)

    # A narrow phase-boundary stratum needs a prescribed share of the nested
    # order.  The same error-greedy rule is retained inside the selected
    # stratum; the quota only prevents a large homogeneous cloud from
    # starving a physically essential manifold.  Fractions are interpreted as
    # target fractions of the current prefix and are optional for ordinary
    # single-phase clouds.
    candidate_labels = candidate.get("stratum")
    if candidate_labels is None and strata is not None:
        candidate_labels = np.asarray(strata)
    if candidate_labels is not None:
        candidate_labels = np.asarray(candidate_labels)
    stratum_fractions = None
    if candidate_labels is not None:
        unique_labels = list(np.unique(candidate_labels))
        if len(unique_labels) > 1:
            # Keep the equilibrium/coexistence label first when present; this
            # makes serialized histories deterministic across branches.
            unique_labels = sorted(unique_labels, key=lambda x: (str(x) != "coexistence", str(x)))
            raw = {label: 1.0 / len(unique_labels) for label in unique_labels}
            # A caller may attach explicit fractions in the candidate dict.
            raw.update(candidate.get("stratum_fraction", {}))
            total = sum(max(float(raw.get(label, 0.0)), 0.0) for label in unique_labels)
            if total > 0:
                stratum_fractions = {label: max(float(raw.get(label, 0.0)), 0.0) / total
                                     for label in unique_labels}

    def target_label(prefix_len):
        if not stratum_fractions:
            return None
        counts = {label: int(np.sum(candidate_labels[np.asarray(order, int)] == label))
                  for label in stratum_fractions}
        next_len = prefix_len + 1
        deficits = [(stratum_fractions[label] * next_len - counts[label], label)
                    for label in stratum_fractions]
        return max(deficits, key=lambda x: (x[0], str(x[1])))[1]

    tau_choices, history = {}, []

    def best_tau(ids):
        best = None
        for tau in tau_grid:
            model = FiniteSupportBranch(candidate["eta"][ids], candidate["phi"][ids],
                                        candidate["q"][ids], tau, center, scale)
            e = validation_error(model, val, weights)
            # Smoothing is selected with the robust validation objective used
            # by the original benchmark; support locations still use the
            # squared thermodynamic error score above.
            # Tune smoothing against an absolute potential error in the
            # declared Massieu units, matching the benchmark objective.  A
            # relative potential error over-weights low-|Phi| states and can
            # select an over-smoothed tau even when the absolute thermodynamic
            # reconstruction is worse.
            phi_objective = np.median(np.abs(e["pred_phi"] - val["phi"]))
            key = (float(phi_objective) +
                   float(np.median(e["gradient"])) / np.sqrt(max(val["q"].shape[1], 1)),
                   -float(tau))
            if best is None or key < best[0]:
                best = (key, float(tau), e)
        return best

    requested = sorted(set([min(max_m, x) for x in
                            (16, 24, 32, 48, 64, 96, 128, 192, 256, 384,
                             512, 768, 1024, 1280, 1536, 2048, 3072, 4096, 6144, 8192)
                            if x <= max_m]))
    # Coverage seeding may already reach the requested maximum (as in the
    # large GERG pool).  Record the complete nested validation curve for every
    # prefix before entering the extension loop.
    for m in requested:
        if m <= len(order) and m not in tau_choices:
            best_now = best_tau(order[:m])
            tau_choices[m] = best_now[1]
            history.append({"M": m, "tau": best_now[1],
                            "validation_mean_score": float(np.mean(best_now[2]["score"])),
                            "validation_max_score": float(np.max(best_now[2]["score"]))})
    current = best_tau(order)
    current_tau, current_e = current[1], current[2]
    while len(order) < min(max_m, len(candidate["eta"])):
        tau = current_tau
        e = current_e
        # Treat narrow strata as first-class validation subsets.  The largest
        # stratum-mean error is used to choose the next worst state, so a
        # coexistence manifold cannot disappear merely because homogeneous
        # states are more numerous.
        forced_label = target_label(len(order))
        if "stratum" in val:
            labels = np.asarray(val["stratum"])
            if forced_label is not None and np.any(labels == forced_label):
                target = forced_label
            else:
                means = [(float(np.mean(e["score"][labels == s])), s)
                         for s in np.unique(labels) if np.any(labels == s)]
                target = max(means)[1]
            members = np.flatnonzero(labels == target)
            worst = int(members[np.argmax(e["score"][members])])
        else:
            worst = int(np.argmax(e["score"]))
        X = (candidate["eta"] - center) / scale
        xv = (val["eta"][worst] - center) / scale
        d = np.sum((X - xv[None, :]) ** 2, axis=1)
        if forced_label is not None:
            d[candidate_labels != forced_label] = np.inf
        if selected:
            d[np.fromiter(selected, dtype=int)] = np.inf
        # Add a small batch only after identifying the same worst validation
        # state.  When requested, candidate residuals refine the geometric
        # nearest-neighbour proposal; this retains the validation-controlled
        # target while choosing a thermodynamically informative candidate.
        take = min(batch_add, min(max_m, len(candidate["eta"])) - len(order))
        if candidate_error_weight > 0.0:
            probe = np.flatnonzero(np.isfinite(d))
            if candidate_probe is not None and len(probe) > int(candidate_probe):
                probe = probe[np.argsort(d[probe])[:int(candidate_probe)]]
            model = FiniteSupportBranch(candidate["eta"][order],
                                        candidate["phi"][order],
                                        candidate["q"][order], tau,
                                        center, scale)
            cphi, cq = model.evaluate(candidate["eta"][probe])
            cqr = np.ptp(val["q"], axis=0)
            cqr = np.where(cqr > 1.0e-14, cqr, 1.0)
            cscore = (cphi - candidate["phi"][probe]) ** 2
            cscore += ((cq[:, 0] - candidate["q"][probe, 0]) / cqr[0]) ** 2
            if cq.shape[1] > 1:
                cscore += np.mean(((cq[:, 1:] - candidate["q"][probe, 1:]) /
                                    cqr[None, 1:]) ** 2, axis=1)
            finite = np.isfinite(d[probe])
            if np.any(finite):
                # Normalize both proposals before blending so coordinate
                # magnitudes cannot dominate the thermodynamic residual.
                dd = d[probe].copy()
                dd[finite] /= max(float(np.max(dd[finite])), 1.0e-30)
                cs = cscore.copy()
                cs[~finite] = -np.inf
                finite_cs = np.isfinite(cs)
                if np.any(finite_cs):
                    cs[finite_cs] /= max(float(np.max(cs[finite_cs])), 1.0e-30)
                    proposal = -dd + float(candidate_error_weight) * cs
                    proposal[~finite] = -np.inf
                    d_probe = -proposal
                    d[probe] = d_probe
        for _ in range(take):
            j = int(np.argmin(d)); order.append(j); selected.add(j); d[j] = np.inf
        # A batch may jump over several requested counts.  Evaluate every
        # crossed count on its exact nested prefix so the final report contains
        # a genuine support-count curve rather than only the largest M.
        for m in requested:
            if m <= len(order) and m not in tau_choices:
                best_now = best_tau(order[:m])
                tau_choices[m] = best_now[1]
                history.append({"M": m, "tau": best_now[1],
                                "validation_mean_score": float(np.mean(best_now[2]["score"])),
                                "validation_max_score": float(np.max(best_now[2]["score"]))})
                if m == len(order):
                    current_tau, current_e = best_now[1], best_now[2]
    if len(order) not in tau_choices:
        best = best_tau(order); tau_choices[len(order)] = best[1]
        history.append({"M": len(order), "tau": best[1],
                        "validation_mean_score": float(np.mean(best[2]["score"])),
                        "validation_max_score": float(np.max(best[2]["score"]))})
    return np.asarray(order, int), tau_choices, history, center, scale


def evaluate_order(candidate, test, order, tau, center, scale, weights=(1., 1., 1.)):
    model = FiniteSupportBranch(candidate["eta"][order], candidate["phi"][order],
                                candidate["q"][order], tau, center, scale)
    e = validation_error(model, test, weights)
    return {"M": int(len(order)), "tau": float(tau),
            "mean_score": float(np.mean(e["score"])),
            "max_score": float(np.max(e["score"])),
            "mean_phi": float(np.mean(e["phi"])),
            "mean_gradient": float(np.mean(e["gradient"])),
            "mean_u": float(np.mean(e["u"])),
            "mean_composition": float(np.mean(e["composition"]))}


def select_stratified_validation_greedy(candidate, validation, max_m,
                                        tau_grid, fractions, center, scale,
                                        batch_add=1, validation_cap=4096,
                                        seed=0, protected_limit=16):
    """Select source-specific validation-greedy orders and interleave them.

    This is the common selector's manifold-aware mode.  Each declared source
    gets its own validation residual sequence, after which the nested prefixes
    are interleaved at the requested fractions.  It is still one validation
    error greedy procedure; the source quota only prevents a narrow physical
    branch from being overwhelmed by a much larger bulk cloud.
    """
    labels = np.asarray(candidate["stratum"])
    vlabels = np.asarray(validation["stratum"])
    source_orders = {}
    source_histories = {}
    source_taus = {}
    for k, (label, fraction) in enumerate(fractions.items()):
        ci = np.flatnonzero(labels == label)
        vi = np.flatnonzero(vlabels == label)
        if not len(ci) or not len(vi):
            continue
        def sub(d, idx):
            return {key: (value[idx] if isinstance(value, np.ndarray) and len(value) == len(labels) else value)
                    for key, value in d.items() if key not in ("stratum", "stratum_fraction")}
        local_max = min(len(ci), max(8, int(np.ceil(max_m * float(fraction)))))
        local_order, local_tau, hist, _, _ = select_validation_greedy(
            sub(candidate, ci), sub(validation, vi), local_max, [0.03125],
            batch_add=batch_add, validation_cap=validation_cap,
            seed=seed + 7919 * (k + 1), protected_limit=protected_limit)
        source_orders[label] = ci[local_order]
        source_histories[label] = hist
        source_taus[label] = local_tau

    requested = sorted(set(min(max_m, x) for x in
                           (16, 24, 32, 48, 64, 96, 128, 192, 256, 384,
                            512, 768, 1024, 1280, 1536, 2048, 3072,
                            4096, 6144, 8192) if x <= max_m))
    order = []
    positions = {label: 0 for label in source_orders}
    for i in range(max_m):
        n = i + 1
        deficits = [(float(frac) * n - positions.get(label, 0), label)
                    for label, frac in fractions.items() if label in source_orders
                    and positions[label] < len(source_orders[label])]
        if not deficits:
            break
        label = max(deficits, key=lambda x: (x[0], str(x[1])))[1]
        order.append(int(source_orders[label][positions[label]]))
        positions[label] += 1

    def best_tau(ids):
        best = None
        for tau in tau_grid:
            m = FiniteSupportBranch(candidate["eta"][ids], candidate["phi"][ids],
                                    candidate["q"][ids], tau, center, scale)
            e = validation_error(m, validation)
            key = (float(np.median(np.abs(e["pred_phi"] - validation["phi"]))) +
                   float(np.median(e["gradient"])) /
                   np.sqrt(max(validation["q"].shape[1], 1)), -float(tau))
            if best is None or key < best[0]:
                best = (key, float(tau))
        return best[1]

    taus = {m: best_tau(order[:m]) for m in requested if m <= len(order)}
    if len(order) not in taus:
        taus[len(order)] = best_tau(order)
    history = [{"M": int(m), "tau": float(t),
                "source_counts": {str(label): int(np.sum(np.asarray(order[:m])[:, None] == np.asarray(src)[None, :]))
                                   if m else 0 for label, src in source_orders.items()}}
               for m, t in sorted(taus.items())]
    return np.asarray(order, int), taus, history, center, scale


def save_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=lambda x: x.tolist()
                               if isinstance(x, np.ndarray) else x), encoding="utf-8")
