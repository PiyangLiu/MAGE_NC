"""Run the common validation-error greedy selector on the available pools.

This script only writes to this folder.  It never replaces the published
examples.  Existing thermodynamic candidate/validation/test pools are reused
so that the comparison isolates the support-selection rule.
"""
from pathlib import Path
import argparse, json, sys
import numpy as np

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent.parent
CALCULATIONS = PACKAGE / "code"
sys.path.insert(0, str(HERE))
from unified_support_selection import (select_validation_greedy,
                                       select_stratified_validation_greedy,
                                       evaluate_order, save_json)

OUT = HERE / "results"


def load_pool(path, prefix):
    raw = dict(np.load(path, allow_pickle=False))
    out = {}
    for split in ("candidate", "validation", "test"):
        out[split] = {k[len(split) + 1:]: v for k, v in raw.items()
                      if k.startswith(split + "_")}
    return out


def load_direct_triplet(paths):
    out = {}
    for split, path in paths.items():
        raw = dict(np.load(path, allow_pickle=False))
        out[split] = raw
    return out


def branch_case(name, files, max_m, tau_grid, weights=(1., 1., 1.),
                holdout_bands=None, batch_add=1, val_cap=4096,
                protected_limit=16, candidate_error_weight=0.0,
                bootstrap_orders=None, bootstrap_tau=None):
    result = {"case": name, "algorithm": "validation-controlled thermodynamic-error greedy",
              "branches": {}, "holdout_bands": holdout_bands or []}
    # Use one coordinate normalization for the competing physical branches,
    # as required by a common Massieu representation.
    all_eta = []
    preloaded = {}
    for phase, path in files.items():
        pools = load_direct_triplet(path) if isinstance(path, dict) else load_pool(path, phase)
        preloaded[phase] = pools
        all_eta.append(pools["candidate"]["eta"])
    common_eta = np.vstack(all_eta)
    common_center = common_eta.mean(0)
    common_scale = np.where(common_eta.std(0) > 1e-14, common_eta.std(0), 1.0)
    for phase, path in files.items():
        pools = preloaded[phase]
        if holdout_bands:
            def keep(d):
                T = d.get("T")
                if T is None:
                    return np.ones(len(d["eta"]), dtype=bool)
                mask = np.ones(len(T), dtype=bool)
                for lo, hi in holdout_bands:
                    mask &= ~((T >= lo) & (T <= hi))
                return mask
            for split in ("candidate", "validation"):
                m = keep(pools[split])
                pools[split] = {k: (v[m] if isinstance(v, np.ndarray) and len(v) == len(m) else v)
                                for k, v in pools[split].items()}
        protected = None
        if "is_equilibrium" in pools["candidate"]:
            protected = pools["candidate"]["is_equilibrium"] > 0.5
        elif name == "binary":
            protected = np.zeros(len(pools["candidate"]["eta"]), dtype=bool)
            protected[:min(protected_limit, len(protected))] = True
        strata = None
        if "is_equilibrium" in pools["candidate"]:
            strata = np.where(pools["candidate"]["is_equilibrium"] > 0.5, "coexistence", "homogeneous")
            pools["candidate"]["stratum"] = strata
            if name == "nonisothermal":
                # Keep the same stratified validation-greedy rule used for
                # every branch, with an explicit 85/15 manifold/bulk quota.
                # This is a compression constraint, not retention of all
                # coexistence states.
                pools["candidate"]["stratum_fraction"] = {
                    "coexistence": 0.85, "homogeneous": 0.15
                }
            # The independent nonisothermal validation pool is homogeneous by
            # construction.  Add a disjoint-from-test, deterministic subset
            # of candidate coexistence states to the *selection* monitor so
            # the common algorithm cannot spend all supports on the bulk cloud.
            if name == "nonisothermal":
                ce = np.flatnonzero(pools["candidate"]["is_equilibrium"] > 0.5)
                take = ce[np.linspace(0, len(ce) - 1, min(1024, len(ce))).round().astype(int)] if len(ce) else ce
                for k in ("eta", "phi", "q"):
                    pools["validation"][k] = np.concatenate([pools["validation"][k], pools["candidate"][k][take]])
                pools["validation"]["stratum"] = np.concatenate([
                    np.full(len(pools["validation"]["eta"]) - len(take),
                            "homogeneous", dtype="U12"),
                    np.full(len(take), "coexistence", dtype="U12")])
        if name == "nonisothermal":
            order, taus, history, center, scale = select_stratified_validation_greedy(
                pools["candidate"], pools["validation"], max_m, tau_grid,
                {"coexistence": 0.85, "homogeneous": 0.15}, common_center,
                common_scale, batch_add=batch_add, validation_cap=val_cap,
                seed=17031 + sum(map(ord, phase)), protected_limit=protected_limit)
        else:
            order, taus, history, center, scale = select_validation_greedy(
                pools["candidate"], pools["validation"], max_m, tau_grid,
                protected=protected, strata=strata, weights=weights,
                batch_add=batch_add, validation_cap=val_cap,
                seed=17031 + sum(map(ord, phase)), center_override=common_center,
                scale_override=common_scale, protected_limit=protected_limit,
                coverage_seed_count=(4096 if name == "gerg" else 0),
                candidate_error_weight=candidate_error_weight)
        # Preserve a previously validated physical-coverage prefix when one
        # is supplied.  The unified validation-greedy order is then appended
        # after that prefix; the prefix provenance is recorded in the result.
        if bootstrap_orders and phase in bootstrap_orders:
            prefix = np.asarray(bootstrap_orders[phase], int)
            prefix = prefix[(prefix >= 0) & (prefix < len(pools["candidate"]["eta"]))]
            merged = list(dict.fromkeys(prefix.tolist() + order.tolist()))
            order = np.asarray(merged[:max_m], int)
            if bootstrap_tau is not None:
                for m in list(taus):
                    if m <= len(prefix):
                        taus[m] = float(bootstrap_tau)
        rows = []
        for M, tau in sorted(taus.items()):
            rows.append(evaluate_order(pools["candidate"], pools["test"],
                                       order[:M], tau, center, scale, weights))
        result["branches"][phase] = {
            "candidate_count": int(len(pools["candidate"]["eta"])),
            "validation_count": int(len(pools["validation"]["eta"])),
            "test_count": int(len(pools["test"]["eta"])),
            "support_order": order.tolist(), "tau_by_M": {str(k): float(v) for k, v in taus.items()},
            "validation_history": history, "test_metrics": rows,
            "center": center.tolist(), "scale": scale.tolist(),
            "bootstrap_prefix_count": int(min(len(bootstrap_orders.get(phase, [])), max_m)) if bootstrap_orders else 0,
            "bootstrap_tau": float(bootstrap_tau) if bootstrap_tau is not None else None,
        }
    save_json(OUT / f"{name}_selection.json", result)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=["binary", "nonisothermal", "gerg", "all"], default="all")
    ap.add_argument("--batch-add", type=int, default=8)
    ap.add_argument("--validation-cap", type=int, default=2048)
    args = ap.parse_args()
    cases = []
    if args.case in ("binary", "all"):
        cases.append(branch_case("binary", {
            "liquid": CALCULATIONS / "figure2_binary_equilibrium" / "binary_liquid_pools.npz",
            "vapor": CALCULATIONS / "figure2_binary_equilibrium" / "binary_vapor_pools.npz"},
            8192, [0.125, 0.25, 0.5, 1.0], batch_add=args.batch_add,
            val_cap=args.validation_cap, protected_limit=45,
            candidate_error_weight=1.0,
            bootstrap_orders={
                "liquid": json.load(open(CALCULATIONS / "figure2_binary_equilibrium" / "results" / "binary_summary.json"))["support_order_liquid"],
                "vapor": json.load(open(CALCULATIONS / "figure2_binary_equilibrium" / "results" / "binary_summary.json"))["support_order_vapor"],
            }, bootstrap_tau=0.125))
    if args.case in ("nonisothermal", "all"):
        cases.append(branch_case("nonisothermal", {
            "liquid": {"candidate": CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "candidate_liquid.npz",
                       "validation": CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "validation_liquid.npz",
                       "test": CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "test_exact_liquid.npz"},
            "vapor": {"candidate": CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "candidate_vapor.npz",
                      "validation": CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "validation_vapor.npz",
                      "test": CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "test_exact_vapor.npz"}},
            8192, [0.25, 0.5, 1.0], batch_add=args.batch_add,
            val_cap=args.validation_cap,
            holdout_bands=[(304.5, 305.5), (324.5, 325.5), (344.5, 345.5)],
            bootstrap_orders={
                "liquid": np.load(CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "support_selection.npz")["liquid_order"],
                "vapor": np.load(CALCULATIONS / "figure4_nonisothermal" / "strengthened_results" / "support_selection.npz")["vapor_order"],
            }, bootstrap_tau=0.25))
    if args.case in ("gerg", "all"):
        cases.append(branch_case("gerg", {
            "liquid": CALCULATIONS / "figure6_gerg2008" / "gerg_liquid_pools.npz",
            "vapor": CALCULATIONS / "figure6_gerg2008" / "gerg_vapor_pools.npz"},
            4096, [0.125, 0.25, 0.5, 1.0, 2.0], weights=(10., 1., 1.),
            batch_add=args.batch_add, val_cap=args.validation_cap,
            candidate_error_weight=0.0))
    save_json(OUT / "unified_selection_manifest.json", {
        "algorithm": "validation-controlled thermodynamic-error greedy",
        "cases": [x["case"] for x in cases],
        "results": [str(OUT / f'{x["case"]}_selection.json') for x in cases],
        "note": "Candidate, validation and test pools are reused; only support ordering and tau are recomputed."
    })
    print(json.dumps({"cases": [x["case"] for x in cases]}, indent=2))


if __name__ == "__main__":
    main()
