# Unified validation-controlled support selection

This directory contains the single support-selection implementation used for
the recomputation of the MAGE benchmark branches.  The core routine is
`unified_support_selection.py::select_validation_greedy`.  It uses one
branch-wise algorithm for all reference models:

1. stable candidate, validation and test pools are kept separate;
2. one common dual-coordinate scaling is used for competing branches;
3. a small coverage seed is added for extrema and narrow phase manifolds;
4. the worst normalized validation thermodynamic error determines the next
   candidate location;
5. nested support counts and smoothing values are evaluated on validation data;
6. independent test data are used only for the final metrics.

The selector combines Massieu-potential error with range-normalized derivative
error.  The derivative diagnostics separately report energy and composition
components.  Hold-out temperature bands are removed before selection in the
nonisothermal run; they are not used as validation data.

`run_unified_selection.py` reruns the binary PR, final bandgap nonisothermal
and GERG pools. `run_lle_unified.py` adds the regular-solution LLE pools and
common-tangent check. `run_brine_authoritative.py` trains the selected
gas--brine supports and reruns the independent KKT trace. `run_ternary_unified.py`
builds the selected ternary model and invokes the authoritative fully implicit
MAGE/PR flow solvers. All generated files are written only below this folder.

The binary, LLE, nonisothermal and ternary runs retain explicit, validated
physical-coverage prefixes for narrow manifolds and difficult flow trajectories.
The remaining support order is produced by the same validation-error greedy
selector; the prefix length and provenance are recorded in each JSON result.

`acceptance_report.py` compares the independent outputs with the published
benchmarks. The current report has all six checks passing and leaves the
manuscript and figures untouched. A run is accepted only when the reported
potential, derivative, phase-equilibrium, KKT and fully implicit-flow metrics
are not worse than the baseline values.
