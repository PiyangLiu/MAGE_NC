"""Train the selected gas--brine supports and rerun the independent KKT test."""
from pathlib import Path
import copy, json, os, sys
import numpy as np
import pandas as pd
import torch
from scipy.interpolate import RBFInterpolator

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "non_pr_storage_or_brine_validation"
DATA_ROOT = HERE / "brine_training_data"
MODEL_TAG = os.environ.get("UNIFIED_BRINE_MODEL_TAG", "unified5000")
OUTPUT_ROOT = Path(os.environ.get("UNIFIED_BRINE_OUTPUT_DIR", str(HERE / "results")))
sys.path.insert(0, str(SRC))
from acgpv2.p3_brine import R
from acgpv2.bounded_study import geometry, BoundedNet, tensors, loss, restore
from acgpv2.bounded_curvature import BoundedCurvatureMassieuACGP
from acgpv2.p3_multiphase import MultiphaseKKT


class NonvolatileSalt(torch.nn.Module):
    def __init__(self, net):
        super().__init__(); self.net = net; self.dim = 4
    def forward(self, E, order=2):
        p, q, H = self.net(E[:, :3], order=order)
        qq = torch.cat([q, torch.zeros_like(p[:, None])], 1)
        HH = None
        if order == 2:
            HH = torch.zeros((len(E), 4, 4), device=E.device, dtype=E.dtype); HH[:, :3, :3] = H
        return p, qq, HH


def train_selected(ids, steps=None):
    data_root = DATA_ROOT
    if steps is None: steps = int(os.environ.get('UNIFIED_BRINE_STEPS','2000'))
    train = [dict(np.load(data_root / f"train_{p}.npz")) for p in ("liquid", "gas")]
    monitor = [dict(np.load(data_root / f"monitor_{p}.npz")) for p in ("liquid", "gas")]
    device = "cuda" if torch.cuda.is_available() else "cpu"
    existing = [HERE/'brine_model'/f'{p}_M1024_{MODEL_TAG}.npz' for p in ('liquid','gas')]
    if MODEL_TAG == 'published':
        existing = [data_root/f'{p}_M1024.npz' for p in ('liquid','gas')]
    if all(p.exists() for p in existing):
        nets=[restore(BoundedCurvatureMassieuACGP.load(p),device=device) for p in existing]
        return nets, train, monitor, data_root, float('nan')
    gauge = torch.nn.Parameter(torch.zeros((), device=device, dtype=torch.float64)); nets=[]
    for d, idx in zip(train, ids):
        g=geometry(d); nets.append(BoundedNet(d, g, np.asarray(idx, int), device=device, gauge=gauge))
    ts=[tensors(d,device) for d in train]; ms=[tensors(d,device) for d in monitor]
    tr_ties=dict(np.load(data_root/'train_ties.npz')); mo_ties=dict(np.load(data_root/'monitor_ties.npz'))
    def interface(ties, ii):
        e=torch.tensor(ties['eta'][ii],device=device,dtype=torch.float64); target=torch.tensor(ties['P'][ii]/(R*ties['T'][ii]),device=device,dtype=torch.float64)
        p=torch.stack([nets[0](e,1)[0],nets[1](e[:,:3],1)[0]])
        return 3000*((p-target)/target).square().mean()+30000*((p[0]-p[1])/target).square().mean()
    params=list({id(p):p for n in nets for p in n.parameters() if p.requires_grad}.values())
    opt=torch.optim.Adam(params,lr=.01); rng=np.random.default_rng(46061); best=None; history=[]
    for step in range(1,steps+1):
        v=0
        for n,t in zip(nets,ts):
            ii=torch.tensor(rng.choice(len(t['T']),min(96,len(t['T'])),replace=False),device=device); v=v+loss(n,t,ii)
        ii=rng.choice(len(tr_ties['T']),min(96,len(tr_ties['T'])),replace=False); v=v+interface(tr_ties,ii)
        opt.zero_grad(); v.backward(); torch.nn.utils.clip_grad_norm_(params,30); opt.step()
        if step%100==0:
            with torch.no_grad():
                vm=sum(loss(n,t,torch.arange(len(t['T']),device=device)) for n,t in zip(nets,ms))
                vm=vm+interface(mo_ties,np.arange(len(mo_ties['T'])))
                score=float(vm)
            history.append({'step':step,'training':float(v.detach()),'monitor':score})
            if np.isfinite(score) and (best is None or score<best[0]): best=(score,[copy.deepcopy(n.state_dict()) for n in nets])
    if best is None: raise RuntimeError('selected gas-brine training produced no finite checkpoint')
    for n,s in zip(nets,best[1]): n.load_state_dict(s)
    model_dir=HERE/'brine_model'; model_dir.mkdir(exist_ok=True)
    for n,d,p in zip(nets,train,("liquid","gas")): n.export(d).save(model_dir/f"{p}_M1024_{MODEL_TAG}.npz")
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(history).to_csv(OUTPUT_ROOT/'gas_brine_authoritative_training.csv',index=False)
    return nets, train, monitor, data_root, best[0]


def run_kkt(nets, train, data_root, best_monitor):
    from acgpv2.p3_cuda_graph import FrozenBounded
    frozen=[FrozenBounded(nets[0]), FrozenBounded(nets[1])]
    branches=[frozen[0], NonvolatileSalt(frozen[1])]; solver=MultiphaseKKT(branches)
    test_l=dict(np.load(data_root/'test_liquid.npz')); test_v=dict(np.load(data_root/'test_gas.npz')); test_ties=dict(np.load(data_root/'test_ties.npz'))
    train_l=dict(np.load(data_root/'train_liquid.npz')); train_v=dict(np.load(data_root/'train_gas.npz'))
    train_ties=dict(np.load(data_root/'train_ties.npz'))
    center=np.array([1/360,np.log(1e7),np.log(2.)]); scale=np.array([.001,.9,1.])
    coords=np.column_stack([1/train_ties['T'],np.log(train_ties['P']),np.log(train_ties['m'])])
    interpolation=RBFInterpolator((coords-center)/scale,train_ties['eta'][:,1:],neighbors=32,kernel='thin_plate_spline',smoothing=1e-9)
    rows=[]; fractions=np.array([.00001,.01,.1,.5,.9,.99,.99999])
    if os.environ.get('UNIFIED_BRINE_QUICK') == '1':
        fractions = fractions[:3]
    mother_limit = 8 if os.environ.get('UNIFIED_BRINE_QUICK') == '1' else len(test_l['T'])
    for i in range(min(len(test_l['T']), mother_limit)):
        l={k:v[i] for k,v in test_l.items()}; v={k:x[i] for k,x in test_v.items()}; vx=np.r_[v['x'],0.]
        distance=((train_ties['T']-test_ties['T'][i])/128)**2+np.log(train_ties['P']/test_ties['P'][i])**2+((train_ties['m']-test_ties['m'][i])/5)**2; j=int(np.argmin(distance))
        feeds=(1-fractions[:,None])*l['x']+fractions[:,None]*vx
        beta0=np.clip((feeds[:,0]-train_l['x'][j,0])/(train_v['x'][j,0]-train_l['x'][j,0]),1e-7,1-1e-7)
        gas_volume=beta0/train_v['rho'][j]; liquid_volume=(1-beta0)/train_l['rho'][j]; sg=gas_volume/(gas_volume+liquid_volume)
        guesses=np.column_stack([1-sg,sg]); water=np.maximum(feeds[:,1]-beta0*train_v['x'][j,1],1e-7); mguess=np.clip(feeds[:,2]/(.018015268*water),.05,5.)
        co=np.column_stack([np.full(len(fractions),1/test_ties['T'][i]),np.full(len(fractions),np.log(test_ties['P'][i])),np.log(mguess)])
        eguess=np.column_stack([np.full(len(fractions),-1/(R*test_ties['T'][i])),interpolation((co-center)/scale)])
        predictions=solver.solve_many(np.full(len(fractions),test_ties['T'][i]),np.full(len(fractions),test_ties['P'][i]),feeds,eguess,initial_S=guesses)
        for beta,out in zip(fractions,predictions):
            rho=1/((1-beta)/l['rho']+beta/v['rho']); h=(1-beta)*l['h']+beta*v['h']
            rows.append({'mother':i,'T':test_ties['T'][i],'P':test_ties['P'][i],'m':test_ties['m'][i],'beta_teacher':beta,'success':out['success'],'residual':out['residual'],'condition':out['condition'],'evaluations':out['evaluations'],'beta_error':float(abs(out['beta'][1]-beta)),'rho_rel':float(abs(out['rho']-rho)/rho),'h_rel':float(abs(out['h']-h)/max(abs(h),100)),'liquid_H2_rel':float(abs(out['x'][0,0]-l['x'][0])/l['x'][0]),'gas_salt':float(out['x'][1,2])})
        if (i+1)%64==0: print('gas-brine KKT mothers',i+1,flush=True)
    frame=pd.DataFrame(rows); outdir=OUTPUT_ROOT; outdir.mkdir(parents=True, exist_ok=True); frame.to_csv(outdir/'gas_brine_authoritative_KKT.csv',index=False)
    summary={'states':len(frame),'independent_mothers':int(min(len(test_l['T']), mother_limit)),'support_count_liquid':len(nets[0].ids),'support_count_gas':len(nets[1].ids),'training_best_monitor':best_monitor,'training_steps':int(os.environ.get('UNIFIED_BRINE_STEPS','2000')),'model_tag':MODEL_TAG,'KKT_success':float(frame.success.mean()),'beta_MAE':float(frame.beta_error.mean()),'rho_mean_rel':float(frame.rho_rel.mean()),'h_mean_rel':float(frame.h_rel.mean()),'liquid_H2_mean_rel':float(frame.liquid_H2_rel.mean()),'gas_salt_max':float(abs(frame.gas_salt).max()),'algorithm':'validation-controlled thermodynamic-error greedy with 1024 selected supports per branch'}
    (outdir/'gas_brine_authoritative_summary.json').write_text(json.dumps(summary,indent=2))
    return summary


def main():
    selection_path = OUTPUT_ROOT / 'gas_brine_selection.json'
    if not selection_path.exists():
        selection_path = HERE / 'results' / 'gas_brine_selection.json'
    sel=json.loads(selection_path.read_text())
    if MODEL_TAG == 'baseline':
        data_root=DATA_ROOT
        ids=[]
        for p in ('liquid','gas'):
            teacher=np.load(data_root/f'{p}_M1024.npz')['atom_eta']; train=np.load(data_root/f'train_{p}.npz')['eta']
            ids.append(np.asarray([int(np.argmin(np.linalg.norm(train-e,axis=1))) for e in teacher],int))
    else:
        ids=[np.asarray(sel['branches'][p]['support_order'][:1024],int) for p in ('liquid','gas')]
    nets,train,monitor,data_root,best=train_selected(ids)
    print(json.dumps(run_kkt(nets,train,data_root,best),indent=2))


if __name__=='__main__': main()
