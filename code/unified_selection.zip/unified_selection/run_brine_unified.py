"""Apply the common selector to the existing gas--brine teacher pools."""
from pathlib import Path
import numpy as np,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from unified_support_selection import select_validation_greedy,evaluate_order,save_json
ROOT=HERE/'brine_training_data'
def convert(d): return {"eta":d["eta"],"phi":d["psi"],"q":d["q"],"T":d["T"],"P":d["P"]}
def main():
 out={"case":"gas_brine","algorithm":"validation-controlled thermodynamic-error greedy","branches":{}}
 for ph in ("liquid","gas"):
  tr=convert(dict(np.load(ROOT/f"train_{ph}.npz"))); mo=convert(dict(np.load(ROOT/f"monitor_{ph}.npz"))); te=convert(dict(np.load(ROOT/f"test_{ph}.npz")))
  c=np.vstack([tr['eta'],mo['eta']]).mean(0);s=np.where(np.vstack([tr['eta'],mo['eta']]).std(0)>1e-14,np.vstack([tr['eta'],mo['eta']]).std(0),1)
  o,t,h,_,_=select_validation_greedy(tr,mo,1024,[.25,.5,1.,2.],batch_add=8,validation_cap=2048,center_override=c,scale_override=s,coverage_seed_count=64,seed=23000+ord(ph[0]))
  out['branches'][ph]={"candidate_count":len(tr['eta']),"validation_count":len(mo['eta']),"test_count":len(te['eta']),"support_order":o.tolist(),"tau_by_M":{str(k):v for k,v in t.items()},"validation_history":h,"test_metrics":[evaluate_order(tr,te,o[:m],tau,c,s) for m,tau in sorted(t.items())]}
 save_json(HERE/'results/gas_brine_selection.json',out)
if __name__=='__main__':main()
