#!/usr/bin/env python3
"""Run the second flow condition with the frozen unified ternary model."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
AUTH = HERE.parent / "figure5_ternary_fully_implicit"
MODEL_DIR = HERE / "ternary_model"
MODEL_FILE = MODEL_DIR / "mage_ternary_1280.npz"
MODEL_SUMMARY = MODEL_DIR / "mage_model_summary.json"
CONFIG = HERE / "caseB_config.json"
OUT = Path(__import__("os").environ.get(
    "UNIFIED_CASEB_OUTPUT_DIR",
    str(HERE / "results" / "ternary_flow_caseB_authoritative"),
))

sys.path.insert(0, str(AUTH / "src"))
from solvers import MAGEGlobalSolver, PRGlobalSolver  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def compare(mage, pr, mage_events, pr_events):
    expected_states = 92 * 6
    if len(mage) != expected_states or len(pr) != expected_states:
        raise RuntimeError("The second-condition state history is incomplete")
    paired = mage.merge(pr, on=["accepted_step", "cell"],
                        suffixes=("_mage", "_pr"))
    if len(paired) != expected_states:
        raise RuntimeError("The MAGE and PR state keys do not match")
    paired["phase_match"] = paired.phase_mage == paired.phase_pr
    paired["P_relative_error"] = (
        np.abs(paired.P_MPa_mage - paired.P_MPa_pr) /
        np.maximum(np.abs(paired.P_MPa_pr), 1.0e-30)
    )
    zcols = []
    for component in ("CH4", "CO2", "nC4"):
        name = f"z_{component}_abs_error"
        paired[name] = np.abs(paired[f"z_{component}_mage"] -
                              paired[f"z_{component}_pr"])
        zcols.append(name)
    paired["S_abs_error"] = np.abs(paired.S_mage - paired.S_pr)
    event_cols = ["accepted_step", "cell", "from_phase", "to_phase"]
    me = mage_events[event_cols].sort_values(event_cols).reset_index(drop=True)
    pe = pr_events[event_cols].sort_values(event_cols).reset_index(drop=True)
    zerr = paired[zcols].to_numpy()
    summary = {
        "space_time_states": int(len(paired)),
        "phase_state_match_fraction": float(paired.phase_match.mean()),
        "phase_state_mismatches": int((~paired.phase_match).sum()),
        "phase_events_MAGE": int(len(mage_events)),
        "phase_events_PR": int(len(pr_events)),
        "phase_event_step_cell_transition_identity": bool(me.equals(pe)),
        "pressure_relative_error_mean": float(paired.P_relative_error.mean()),
        "pressure_relative_error_max": float(paired.P_relative_error.max()),
        "composition_absolute_error_mean": float(zerr.mean()),
        "composition_absolute_error_max": float(zerr.max()),
        "gas_saturation_absolute_error_mean": float(paired.S_abs_error.mean()),
        "gas_saturation_absolute_error_max": float(paired.S_abs_error.max()),
    }
    return paired, summary


def audit_domain(mage_states, solver, support_eta):
    mapped_rows = []
    mapped = []
    for row in mage_states.itertuples(index=False):
        z = np.array([row.z_CH4, row.z_CO2, row.z_nC4], float)
        state, residual, _ = solver.map_state(row.P_MPa * 1.0e6, z)
        mapped.append(state)
        mapped_rows.append({
            "accepted_step": int(row.accepted_step),
            "cell": int(row.cell),
            "P_MPa": float(row.P_MPa),
            "eta_1": float(state[0]),
            "eta_2": float(state[1]),
            "eta_3": float(state[2]),
            "S": float(state[3]),
            "map_residual": float(residual),
        })
    mapped = np.asarray(mapped)
    dual = mapped[:, :3]
    support_dual = support_eta[:, 1:]
    support_min = support_dual.min(axis=0)
    support_max = support_dual.max(axis=0)
    in_box = bool(np.all(dual >= support_min - 1.0e-10) and
                  np.all(dual <= support_max + 1.0e-10))
    hull_report = {"available": False, "inside_fraction": None,
                   "max_inequality": None}
    try:
        from scipy.spatial import ConvexHull
        hull = ConvexHull(support_dual)
        inequalities = np.c_[dual, np.ones(len(dual))] @ hull.equations.T
        maxima = inequalities.max(axis=1)
        hull_report = {
            "available": True,
            "inside_fraction": float(np.mean(maxima <= 1.0e-9)),
            "max_inequality": float(maxima.max()),
        }
    except Exception as exc:
        hull_report["reason"] = str(exc)

    pressures = mage_states.P_MPa.to_numpy(float)
    eta_lower = np.array([-0.45, -0.2, -0.45])
    eta_upper = np.array([3.35, 3.0, 1.55])
    eta_margin = np.column_stack([dual - eta_lower, eta_upper - dual])
    audit = {
        "state_count": int(len(mapped_rows)),
        "all_map_residuals_finite": bool(np.isfinite(
            [row["map_residual"] for row in mapped_rows]).all()),
        "max_map_residual": float(max(row["map_residual"]
                                      for row in mapped_rows)),
        "online_minimums_eta_1_eta_2_eta_3_S_P_MPa":
            np.r_[dual.min(axis=0), mapped[:, 3].min(), pressures.min()].tolist(),
        "online_maximums_eta_1_eta_2_eta_3_S_P_MPa":
            np.r_[dual.max(axis=0), mapped[:, 3].max(), pressures.max()].tolist(),
        "selected_support_eta_min": support_min.tolist(),
        "selected_support_eta_max": support_max.tolist(),
        "all_online_dual_states_inside_selected_componentwise_support_box": in_box,
        "all_online_pressure_inside_declared_1p25_to_3p25_MPa":
            bool(np.all((pressures >= 1.25 - 1.0e-10) &
                        (pressures <= 3.25 + 1.0e-10))),
        "all_online_S_inside_closed_unit_interval":
            bool(np.all((mapped[:, 3] >= -1.0e-10) &
                        (mapped[:, 3] <= 1.0 + 1.0e-10))),
        "minimum_distance_to_solver_eta_bounds": float(eta_margin.min()),
        "minimum_distance_to_pressure_bounds_MPa": float(np.minimum(
            pressures - 1.25, 3.25 - pressures).min()),
        "selected_support_convex_hull_test_on_eta_1_to_eta_3": hull_report,
    }
    return pd.DataFrame(mapped_rows), audit


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    model = dict(np.load(MODEL_FILE))
    model_summary = json.loads(MODEL_SUMMARY.read_text(encoding="utf-8"))
    for branch in ("liquid", "vapor"):
        if len(model[f"{branch}_eta"]) != 1280:
            raise RuntimeError(f"Unexpected {branch} support count")
    if model_summary["supports_per_phase"] != 1280 or model_summary["tau"] != 0.5:
        raise RuntimeError("The unified model summary does not match Case B")

    grid = pd.read_csv(AUTH / "time_grid.csv")
    mage_solver = MAGEGlobalSolver(CONFIG, MODEL_DIR)
    pr_solver = PRGlobalSolver(CONFIG)
    mage, mage_events, _, mage_summary = mage_solver.run(grid, OUT)
    pr, pr_events, _, pr_summary = pr_solver.run(grid, OUT)
    paired, comparison = compare(mage, pr, mage_events, pr_events)

    if (comparison["space_time_states"] != 552 or
            comparison["phase_state_mismatches"] != 0 or
            not comparison["phase_event_step_cell_transition_identity"]):
        raise RuntimeError("The second-condition phase comparison failed")

    event_cols = ["accepted_step", "cell", "from_phase", "to_phase"]
    paired.to_csv(OUT / "combined_global_states.csv", index=False)
    mage_events.merge(pr_events, on=event_cols, how="outer",
                      suffixes=("_mage", "_pr"), indicator=True).to_csv(
                          OUT / "combined_phase_events.csv", index=False)

    support_eta = np.vstack([model["liquid_eta"], model["vapor_eta"]])
    mapped, domain_audit = audit_domain(mage, mage_solver, support_eta)
    mapped.to_csv(OUT / "mage_dual_state_audit.csv", index=False)

    model_hash = sha256(MODEL_FILE)
    report = {
        "case": "B",
        "thermodynamic_model": {
            "file": "ternary_model/mage_ternary_1280.npz",
            "sha256": model_hash,
            "summary_sha256": sha256(MODEL_SUMMARY),
            "supports_per_phase": 1280,
            "tau": 0.5,
            "same_file_used_by_primary_unified_flow": True,
        },
        "configuration": json.loads(CONFIG.read_text(encoding="utf-8")),
        "MAGE_solver": mage_summary,
        "PR_solver": pr_summary,
        "comparison": comparison,
        "domain_audit": domain_audit,
    }
    (OUT / "caseB_summary.json").write_text(
        json.dumps(report, indent=2, allow_nan=False), encoding="utf-8")
    (OUT / "domain_audit.json").write_text(
        json.dumps(domain_audit, indent=2, allow_nan=False), encoding="utf-8")
    print(json.dumps(report, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
