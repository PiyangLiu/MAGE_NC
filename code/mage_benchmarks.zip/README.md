# MAGE supplementary controlled benchmarks

These scripts reproduce the **new, limited** supplementary controls in the
revised MAGE manuscript. They are original independent implementations: the
source code and support arrays for the manuscript's existing high-fidelity
H2--H2O--NaCl study (Supplementary Note 5.1) were not supplied.

## Requirements and commands

- Python 3.12, NumPy 2.3.5, SciPy 1.17.0 (older versions can work).
- A single-threaded BLAS is recommended to reduce microbenchmark variability.
- From the `mage_benchmarks` directory, run:

```bash
OPENBLAS_NUM_THREADS=1 python brine_closure.py --outdir results
OPENBLAS_NUM_THREADS=1 python pr_embedding.py --outdir results
python verify_results.py --outdir results
```

Outputs:

- `results/brine_results.json`: complete accuracy, timing repeats, Python
  environment and strictly scoped speedup.
- `results/brine_holdout.csv`: all 600 independent reference and MAGE branch
  potentials and phase classifications; no test samples select supports.
- `results/embedding_results.csv`: support counts and test accuracy for two PR
  phases under all five isometric embeddings.
- `results/embedding_trace.json`: complete support index sequences, validation
  traces and two PR analytic-gradient finite-difference audits.

All seeds and model coefficients are in the scripts. Repeated timing should be
interpreted as an implementation-specific pilot, not an industrial throughput
promise. The scripts do not use a GPU.

## Scientific scope and fairness

### `brine_closure.py`

This is a **dimensionless, strictly convex electrolyte-like model** with
explicit gas--salt coupling, not a calibrated H2 solubility prediction, GERG,
full Pitzer, PR+Pitzer or eCPA implementation. The reference directly evaluates
an ideal gas phase and uses SciPy's Newton-type `hybr` root solver with an **exact
analytic Jacobian** to invert a nonlinear aqueous dual potential for each
chemical-potential query. MAGE uses **the identical mathematical generator**,
approximated by 384 liquid and 256 gas supports.

It compares a complete *grand-canonical dual phase-branch closure* (values,
derivatives and branch classification at prescribed chemical potentials). It
does **not** compare two mass-conserving `(T,p,z)` flashes and it does not test
PR's numerical robustness directly. An unextended PR EOS lacks the ionic
interaction terms modeled here, so a speed-only comparison with PR would
conflate accuracy and physical-model fidelity. Its role is to illustrate how
MAGE's online algebraic representation can amortize repeated *nonlinear
reference inversions* when the nonideal constitutive model is costly.

Online timing excludes model fitting, candidate generation and support
construction. The reported tiny offline construction cost includes only
the sampled model and deterministic support coverage selection; it **cannot**
be extrapolated as the offline cost of high-fidelity EOS support generation.
The numerical timing ratio is sensitive to machine load, BLAS threading,
support size and implementation language. `brine_results.json` reports all
five repeat values.

### `pr_embedding.py`

The physical data come from the 300 K Peng--Robinson mixture model for real
CH4/n-C4 component constants and the exact selected liquid/gas cubic root.
The physical dual variables are chemical potentials divided by RT; potential
`p/(RT)`; gradient component molar densities. The analytic Legendre gradient
is checked by finite differences with respect to `(p,x)`.

The **same binary states**, not zero-concentration third--tenth species, are
linearly embedded by an orthonormal `N x 2` matrix into `N=2,3,5,8,10`.
Because the map preserves inner products, every tangent plane, normalized
log-sum-exp evaluation and normalized error is mathematically identical.
The selected support indices are therefore provably invariant; the script
asserts this property. The experiment demonstrates the lack of an ambient-
dimension effect *when the intrinsic thermodynamic degrees remain fixed*.

It does not establish that real five- or ten-component mixtures are easy:
their independently varying compositions can increase intrinsic dimension,
curvature, covering number, and model complexity. Raw `N`-space storage and
matrix evaluation may still scale with `N`; a chart representation would
preserve the two-coordinate online representation.

For the control, support selection is one-at-a-time, with a declared maximum
validation error of `0.05`, `tau=0.0006` and a stop at the first acceptable
prefix. This selector is intentionally *not* described as the eight-at-a-time
production greedy rule used in the manuscript's original benchmarks.

## Result interpretation

The observed 13/27 supports (liquid/gas) for every ambient dimension are
genuine results of this model, data domain, seed and selection threshold. They
should not be changed to 22,18,18,22,22: different counts from an exactly
isometric control would require changed geometry/selection or roundoff effects.

Before a submission-level runtime comparison to PR+Pitzer/eCPA/GERG, use the
original calibrated EOS and matching support database, a common `(T,p,z)`
benchmark with identical convergence criteria and error budgets, optimized
baseline solvers, hardware-controlled runs, and explicit amortization and GPU
measurements. Those are not established by this package.
