# Supplementary Note 6 source data

This directory contains the numerical source data for the six-component
noncritical PR benchmark and Supplementary Tables 12--14.

`data/reference_summary.json` describes the six-component thermodynamic domain
and independent state splits. The NPZ files in `data/` contain candidate,
validation, pilot-held-out and confirmatory states. `model/` contains the
128-support-per-phase MAGE representation and its selection summary.

`results/verified_benchmark.json` is the authoritative accuracy and timing
summary. `results/compiled_implementation_audit.json` records compiled-versus-
Python parity and the analytic-Jacobian audit. `results/heldout_all_states.csv`
contains the complete recorded confirmatory state table; the two figure files
are provided for direct inspection.

The confirmatory metrics are 1,000/1,000 exact phase labels, pressure relative
error mean/max `1.81e-4`/`5.14e-4`, and component number-density relative error
mean/max `2.59e-3`/`5.41e-2`. Units and column definitions are stated in the
JSON summary and in the companion code README.

The table-level mapping is:

| Supplementary table | Source files |
| --- | --- |
| Table 12 | `data/reference_summary.json`, `model/model_summary.json` |
| Table 13 | `results/verified_benchmark.json` |
| Table 14 | `results/compiled_implementation_audit.json`, `results/heldout_all_states.csv` |
