# Fresh greedy-selection source data

This directory contains the machine-readable outputs from the common
validation-error greedy support selector used for the current manuscript
calculations. It is supplementary to the figure-specific source tables in the
parent `source_data` directory. Figure 2 was not changed by this update.

The five `*_selection.json` files contain the candidate, validation and test
pool sizes, selected support order, smoothing parameter `tau`, standardisation
centre and scale, validation thresholds, validation history and independent
test metrics. The matching `*_validation_curve.csv` files contain one row per
nested support prefix with columns `M`, `tau`, validation mean/max score and
the gate flag. The `*_support_orders.npz` files contain zero-based candidate
indices in selection order, with one array per phase branch.

Selected support counts are: nonisothermal liquid/vapour 1592/1392;
GERG-2008 liquid/vapour 3264/1592; liquid-liquid L1/L2 192/184; gas-brine
liquid/gas 1376/368; and ternary flow liquid/vapour 1280/1280. The ternary
candidate databases contain 1331 liquid and 1572 vapor states; these are not
the selected support counts. The dimensionless
`tau` values are 0.125, 0.03125, 0.125, 0.25 and 0.65, respectively.

`ternary_flow_evaluation/` and `ternary_second_flow_evaluation/` contain the
downstream MAGE and Peng-Robinson histories. Pressures are in MPa, time is in
seconds, compositions and saturations are dimensionless, and residual/error
columns are dimensionless unless their names specify otherwise. The primary
flow has 552 matched space-time states and zero phase-label mismatches; the
second flow has 558 states and no phase-label mismatch. The corresponding
solver and comparison summaries are JSON files in each directory.

`ternary_flow_model/mage_ternary_1280.npz` is the finite-support model used by
both downstream checks. `manifest.json` records the case list and path policy.
`selection_parameters.csv` repeats the branch-specific counts, smoothing
parameters and validation gates in a compact table.
All JSON files are UTF-8, CSV files have header rows and full-precision decimal
values, and NPZ arrays can be read with `numpy.load(..., allow_pickle=False)`.
